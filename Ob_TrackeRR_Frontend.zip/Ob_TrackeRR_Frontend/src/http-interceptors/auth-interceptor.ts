 
import { Injectable } from '@angular/core';
import {
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
    HttpHandler,
    HttpEvent,
    HttpErrorResponse
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

 import { ErrorDialogService } from '../app/error-dialog/error-dialog.service';


  
 
 
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service'; 
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { SwPush } from '@angular/service-worker';
import { CommonService } from 'src/services/api/common.service';


@Injectable()

export class AuthInterceptor implements HttpInterceptor {
  errorData: {};
  url;
  
  constructor( 
    private router: Router,
    private cookieService: CookieService , 
    private errorDialogService: ErrorDialogService,
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
    ) {
     this.url = this.router.url;
    }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> { 
   //debugger
   this.url = this.router.url;
/*
   if (this.commonService.isLoggedIn()) {
    let getCurrent = this.commonService.getCurrentUser(); 
    if(!getCurrent['center_id'] || !getCurrent['role'] || !getCurrent['team_id'] || !getCurrent['token']){
      this.serviceFactory.msgPop('Profile is not updated please contact sales head.','error');
      this.commonService.logout(this.url);  
    }
  }
  */
 
  
      
      return next.handle(req).pipe(
        map((event: HttpEvent<any>) => {
         // debugger
            if (event instanceof HttpResponse) {
              
            }
         
            
            return event;
        }),
        catchError((error: HttpErrorResponse) => { 
          debugger
          if(error.status==401){ 
            this.commonService.logout(this.url);  
           // let link = "./login?returnUrl="+this.url; 
           // this.loginService.logout(this.url);
          }else{
            this.serviceFactory.notification("We're sorry, but something went wrong on our end. Please try again later.",false); 
          }


            // this.errorDialogService.openDialog(error); 
            
            if (error.error instanceof ErrorEvent) { 
              // A client-side or network error occurred. Handle it accordingly.
              console.error('An error occurred:', error.error.message);
            } else {
              // The backend returned an unsuccessful response code.
              // The response body may contain clues as to what went wrong,
              console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
            }
            // return an observable with a user-facing error message
            this.errorData = {
              errorTitle: 'Oops! Request for document failed',
              errorDesc: 'Something bad happened. Please try again later.'
            };
            return throwError(this.errorData);
        }));
}
}