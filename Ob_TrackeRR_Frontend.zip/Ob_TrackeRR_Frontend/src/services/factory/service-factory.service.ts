import { Injectable } from '@angular/core';
import Swal from 'sweetalert2'
 
import * as moment from 'moment'; 

declare let introJs: any;

@Injectable({
  providedIn: 'root'
})
export class ServiceFactory {
  tokenFromUI: string = "0123456789123456";
  activeElm:any;
  intro_JS = introJs();
  constructor() {}

  tourData(option:any){
    this.intro_JS.setOptions(option).start();  
  }
 

 // # Region notification
   // # Region notification
  notification(message: string, type: any,time?:any) {
    //debugger
     this.activeElm = document.activeElement;
    
    let messageType:any
    if(type==true){
      messageType ='success';
    }else if(type==false){
      messageType ='error';
    }else{
       messageType = type
    } 

   // messageType = (type ? 'success' : 'error');   
    Swal.fire({
      toast: true,
      position: 'bottom-end',
      icon: messageType, 
      title: message,
      showConfirmButton: false,
      customClass: {
        container: 'notification',
        popup: messageType,
      },
      timer: time?time:3000
    });
    //debugger
    if(this.activeElm && this.activeElm!=null){
      this.activeElm.focus()
    }
    
    //console.log(this.activeElm);
  }
  //# End - Region notification


  // # Region Loader

  loadingStart(elm: any, msg: string, btn: string) {
   // debugger  
    let ifLoading=document.querySelector('#loading-'+elm.slice(1)+'-overlay');
    if(ifLoading!=null){
      ifLoading.remove();
    }
    let target=document.querySelector(elm);
    if(target!=null){
        target.style.position = "relative";         
        var wrapper = document.createElement('div');
        wrapper.className = 'loading-overlay-wrapper';
        wrapper.id = 'loading-'+elm.slice(1)+'-overlay';    
        
        var container = document.createElement('div');
        container.className = 'loading-container';
        container.innerHTML = msg;
        wrapper.appendChild(container);
        
        var icon = document.createElement('i');
        icon.className = 'loading-spinner'; 
        container.appendChild(icon);    

        target.appendChild(wrapper);  
    }
    
   
  }

  loadingStop(elm: string, btn: string) {
  //  debugger
    let removeElm=document.querySelector('#loading-'+elm.slice(1)+'-overlay');
    if(removeElm!=null){
      removeElm.remove();
    }

  }

  //# End - Region Loader




  msgPop(msg:any,type:any) {  
    debugger  
    Swal.fire({
      buttonsStyling: false, 
      allowOutsideClick:false,
      showCloseButton: false, 
      customClass: { 
        container: 'modal-yes-no swal-msg-type',
        popup: 'modalBG',
        actions: 'modal-btn-yes-no mb-4',
        closeButton: 'btn-modal-dismiss',
        icon: 'modal-icon-top',
        confirmButton: 'mat-raised-button mat-button-base mat-primary', 
      },
        title:type,	
        html: msg,
        icon:type,
      }) 
 }



 getMonthsFromToDate(dateStart:any,dateEnd:any){
   debugger 
   dateStart = moment(dateStart);
   dateEnd = moment(dateEnd)

    var timeValues = [];

    while (dateEnd > dateStart || dateStart.format('M') === dateEnd.format('M')) {
      timeValues.push(dateStart.format('YYYY-MM'));
      dateStart.add(1,'month');
    }

   return timeValues.length
 }

 getStartEndDays(date:any){  
    
  let startOfMonth = moment(date).startOf('month').format('YYYY-MM-DD');
  let endOfMonth   = moment(date).endOf('month').format('YYYY-MM-DD');
  
  let isSame = moment(date).isSame(moment(), 'month');
  if(isSame){
    endOfMonth = moment().format('YYYY-MM-DD');
  }
  return {
    start:startOfMonth,
    end:endOfMonth,
  }
}



fileFalidation(file:any,size:number,exts:any){ 
  debugger 
  let validFile = false;

 var fileSize = file.size/1024/1024;	  
 if(fileSize > size){
     this.msgPop('Maximum file size should be '+size+' MB.','error');
    validFile = false;
    return false
  }

  

  if (file) {
    var get_ext = file.name.split('.'); 
      get_ext = get_ext.reverse();  
      if ( exts.some(function(el: any){ return el === get_ext[0]})){
       // debugger
       validFile = true;
          return true;
          
    }else{
       this.msgPop('File format is not supported. <br>Please select &nbsp; ('+exts.join(', .')+') &nbsp; file  only.','error');
       validFile = false;
       return false
    }
  }
  return validFile
  
}

getFileNameByPath(ngModel:any){
  if(ngModel && ngModel!=''){  
     return ngModel.replace(/^.*[\\\/]/, '')
  }
   return null
}


getFilterAppliedCount(fData:any){
  let fCount:any = 0;
  Object.keys(fData).forEach(function (key) {
    let obVar = fData[key];
    if(Array.isArray(obVar) && obVar.length>0){ 
      fCount=fCount+1; 
    }else if (typeof obVar === 'object' && !Array.isArray(obVar) && obVar !== null && Object.values(obVar).length>0){
       if(Object.values(obVar).filter((v) => v).length>0){
        fCount=fCount+1; 
       } 
    }else if(obVar && obVar!=''){
      fCount=fCount+1; 
    }else{ 
    }  
 });
  
   return fCount
}


localStorageSetWithExpiry(key: string, value: any, ttl: number) {
	const now = new Date() 
	// `item` is an object which contains the original value
	// as well as the time when it's supposed to expire
	const item = {
		value: value,
		expiry: now.getTime() + ttl,
	}
	localStorage.setItem(key, JSON.stringify(item))
}

localStorageGetWithExpiry(key: string) {
	const itemStr = localStorage.getItem(key)
	// if the item doesn't exist, return null
	if (!itemStr) {
		return null
	}
	const item = JSON.parse(itemStr)
	const now = new Date()
	// compare the expiry time of the item with the current time
	if (now.getTime() > item.expiry) {
		// If the item is expired, delete the item from storage
		// and return null
		localStorage.removeItem(key)
		return null
	}
	return item.value
}


}
