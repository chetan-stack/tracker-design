import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs'; 

@Injectable()
export class DataFactoryService {

  all_centerList= {
    1:'Noida',
    2:'Lower Parel',
    3:'Thane',  
    4:'Malad', 
    5:'Bangalore', 
    6:'Lodha',
    7:'Pune'
  }


  all_centerColor= {
    1:"#8C18E2",
    2:"#4A4DE6", 
    3:"#FF6422",  
    4:"#4CAF50", 
    5:"#ff4584",
    6:"#8C18E2",
    7:"#4A4DE6",
  }


  get_salesType_key = {
    1:"retail_new",
    2:"retail_renewal",
    3:"dwn_new",
    4:"dwn_renewal",
    5:"pmp_lt",
    6:"dwn_lt"
   }

   get_salesType_id = {
    "retail_new":1,
    "retail_renewal":2,
    "dwn_new":3,
    "dwn_renewal":4,
    "pmp_lt":5,
    "dwn_lt":6
   }



  salesType_list:any = {
    "retail_new":"Retail Onboarding",
    "retail_renewal":"Retail Renewal",
    "dwn_new":"DWN Onboarding",
    "dwn_renewal":"DWN Renewal",
    "pmp_lt":"Retail PMP",
    "dwn_lt":"DWN PMP",
    }


   

    salesType_Color:any = {
      'retail_new':"#2B87E3",
      'retail_renewal':"#EBA10F",
      'dwn_new':"#0DA663", 
      "dwn_renewal":"#FF6422", 
      'pmp_lt':"#A348C3",
      'dwn_lt':"#A348C3"
      }
 

    salesType_ob_url:any = {
      "retail_new":"",
      "retail_renewal":"renewal/",
      "dwn_new":"dwn/",
      "dwn_renewal":"dwn-renewal/", 
      "pmp_lt":"lt-premium-esign/",
      "dwn_lt":"lt-esign/",
      }
  
 
 

  all_product_label= {
    '[1]':"5 in 5",
    '[12]':"MPO", 
    '[1,12]':"Combo (5in5 + MPO)",     
    '[14]':"DWN", 
    '[14,12]':"DWN + MPO",
    '[3]':"Vision",
   
  }

  all_product_color= {
    '[1]':"#0000ff",
    '[12]':"#800080",
    '[1,12]':"#c71c69",  
    '[14]':"#008000",
    '[14,12]':"#ffa500",
    '[3]':"#0000ff", 
  }
 
  all_team_name_id= {
     1:"Retail Team",
     2:"Renewal Team",
     3:"DWN Team",
     4:"PMP Team", 
  }
  
  all_team_color= {
    1:"#2B87E3",
    2:"#EBA10F",
    3:"#0DA663",  
    4:"#A348C3", 
  }
 
  all_payment_type={
    1:'Online',
    2:'IMPS / NEFT / RTGS',
    3:"UPI",
    4:"Instamojo",
    5:"Razorpay",
    6:"CCAvenue", 
    7:"Cheque Deposit",
    8:"Instamojo-Amex",
    9:"Paytm"
   // 1:'Online( Instamojo/Razorpay/CCAvenue)',
     
   // 5:'Cash Deposit',
   // 6:'Cash Handover',
  }

  
  All_Status_Name = {
    "Assigned":"Assigned",
    "Not Assigned":"Not Assigned",  
    "New":"New", 
    "Not Started":"Not Started",
    "OTP Verified":"OTP Verified",
    "KYC Filled":"KYC Filled",
    "Risk Profile":"Risk Profile",
    "Portfolio Type":"Portfolio",
    "Investment Amount Agreed":"Investment",
    "Signed Agreement":"Agreement",
    "Account Created":"Created",
    "Sales Form Gen":"Sales Gen.",
    "sent":"Sent", // LT 
    "approved":"Approved",// LT 

    "Created":"Created",
    "Pending":"Pending",
    "Reject by Accounts":"Accounts",
    "Accept by Accounts":"Accounts",
    "Reject by Manager":"Manager",
    "Accept by Manager":"Manager",
    "Auto approved by manager":"Manager",
    "Re Execute":"Re Execute",
    "Verified":"Verified",
 
   "Refunded":"Refunded",
   "Rejected":"Rejected",
   "Approved":"Approved",

   "Success":"Success",
   "Failed":"Failed",
   "Not Attempted":"Not Attempted",
   "Skipped":"Skipped",   
   "Skipped Pending":"Skip Pending",
   "Skipped Rejected":"Skip Rejected",
   "Cancelled":"Cancelled", 
   "OPS CR Initiated":"OPS CR Initiated",
   "AC CR Initiated":"A/C CR Initiated",
   "New CR":"New CR Rec.",


   "Due":"Due",
   "Received":"Received", 
   "Off. received":"Off. received",

  }

 

 
 
 
//https://stackblitz.com/edit/key-value-map-object-ngfor-descending-dht3rf?file=src%2Fapp%2Fapp.component.ts
  All_Status_Color:any = {
    "Assigned":"#f7b58c",
    "Not Assigned":"#b2afed",  
    "New":"#1294ff", 
    "Not Started":"#62846b",///**** */
    "OTP Verified":"#9d2f00",
    "KYC Filled":"#fc8600",
    "Risk Profile":"#0096ca",
    "Portfolio Type":"#0863eb",
    "Investment Amount Agreed":"#df00d3",
    "Signed Agreement":"#ff0000",
    "Account Created":"#00c73c",
    "Sales Form Gen":"#8d9cab",
    "sent":"#2dbe62", // LT 
    "approved":"#dfa50a",// LT 

    "Created":"#00c73c", 
    "Pending":"#ffab19",
    "Reject by Accounts":"#ef3e5a",
    "Accept by Accounts":"#4caf50",
    "Reject by Manager":"#ef3e5a",
    "Accept by Manager":"#4caf50",
    "Auto approved by manager":"#0096ca" ,
    "Re Execute":"#182df0",
    "Verified":"#607d8b",

    "InProcess":"#fc8600",
    "Converted":"#00c73c",
    "Pitched":"#62846b",

    "Hot":"#ff0000",
    "Warm":"#ffab19",
    "Cold":"#62846b",
    
    "Refunded":"#00c73c",
    "Rejected":"#ef3e5a", 
    "Approved":"#dfa50a",

    "Success":"#00c73c",
    "Failed":"#df7313",
    "Not Attempted":"#a6b5c2",
    "Skipped":"#FFAC32", 
    "Skipped Pending":"#fff",
    "Skipped Rejected":"#ef3e5a",
    "Cancelled":"#ef3e5a", 
    "OPS CR Initiated":"#d68484",
    "AC CR Initiated":"#d68484",
    "New CR":"#1294ff",

    "Due":"#a6b5c2",
    "Received":"#00c73c", 
    "Off. received":"#0096ca",

  }

  All_Status_Icon:any = {
    "Assigned":null,
    "Not Assigned":null,  
    "New":"star", 
    "Not Started":"progress-close",
    "OTP Verified":"cellphone-check",
    "KYC Filled":"account-search-outline",
    "Risk Profile":"head-question-outline",
    "Portfolio Type":"chart-pie",
    "Investment Amount Agreed":"cash-check",
    "Signed Agreement":"file-sign",
    "Account Created":"check",
    "Sales Form Gen":"text-box-check-outline",
    "sent":"email-send-outline", // LT 
    "approved":"clipboard-check-outline",// LT 

    "Created":"check",
    "Pending":"exclamation-thick",
    "Reject by Accounts":"close",
    "Accept by Accounts":"check",
    "Reject by Manager":"close",
    "Accept by Manager":"check",
    "Auto approved by manager":"cog-outline",
    "Re Execute":"keyboard-return",
    "Verified":"check-decagram",

    "InProcess":"progress-check",
    "Converted":"check",
    "Pitched":"gesture-tap",

    "Refunded":"check",
    "Rejected":"close",
    "Approved":"check",

    "Success":"check",
    "Failed":"close",
    "Not Attempted":"bank-off-outline",
    "Skipped":"bank-remove", 
    "Skipped Pending":"exclamation-thick",
    "Skipped Rejected":"close",
    "Cancelled":"close",
    "OPS CR Initiated":"progress-check",
    "AC CR Initiated":"progress-check",
    "New CR":"star"
  }

 
 
  constructor() {}

  private storeData:any = {};
  private TopFiveList = new BehaviorSubject<any>([]);
  private teamList = new BehaviorSubject<any>([]);
  private accessMasterList = new BehaviorSubject<any>([]);
  private userProfile = new BehaviorSubject<any>({});
  private sales_type =  new BehaviorSubject<any>('');
  private pageTitle = new BehaviorSubject<any>({});
  private headerType = new BehaviorSubject<any>(null);
  private ifVoiceMSG = new BehaviorSubject<any>('');
  private pushIsSubscribed = new BehaviorSubject<any>(null);
 
  set_ifVoicePush(data:any) {
    this.ifVoiceMSG.next(data);
  }

  get_ifVoicePush() {
    return this.ifVoiceMSG.asObservable(); 
  }

  set_TopFiveList(data:any) {
    this.TopFiveList.next(data);
  }

  get_TopFiveList() {
    return this.TopFiveList.asObservable(); 
  }
  
  set_TeamList(data:any) {
    this.teamList.next(data);
  }

  get_TeamList() {
    return this.teamList.asObservable(); 
  }
  set_AccessMasterList(data:any) {
    this.accessMasterList.next(data);
  }

  get_AccessMasterList() {
    return this.accessMasterList.asObservable(); 
  }

  set_Profile(data:any) {
    this.userProfile.next(data);
  }

  get_Profile() {
    return this.userProfile.asObservable(); 
  }

  

  setSalesType(data:any) {
    this.sales_type.next(data);
  }

  getSalesType() {
    return this.sales_type.asObservable(); 
  }



 

  setPageTitle(data:any) {
    this.pageTitle.next(data);
  }

  getPageTitle() {
    return this.pageTitle.asObservable(); 
  }

 

  setHeaderType(data:any) {
    this.headerType.next(data);
  }

  getHeaderType() {
    return this.headerType.asObservable(); 
  }

  set_pushIsSubscribed(data:any) {
    this.pushIsSubscribed.next(data);
  }
  get_pushIsSubscribed() {
    return this.pushIsSubscribed.asObservable(); 
  }

  public set_data(key:any,value:any) {  
    this.storeData[key] = value;
  }

  public get_data(key:any) {  
    return this.storeData[key];
  }

  public delete_key_data(key:any) {  
    return delete this.storeData[key]
  }
  

}