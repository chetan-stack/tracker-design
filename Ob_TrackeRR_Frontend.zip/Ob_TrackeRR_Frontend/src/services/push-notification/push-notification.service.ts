import { Injectable } from '@angular/core';
import { AngularFireMessaging } from '@angular/fire/messaging';
import { BehaviorSubject } from 'rxjs'
import { mergeMapTo } from 'rxjs/operators';
@Injectable()
export class PushNotificationService {
    
currentMessage = new BehaviorSubject(null);
constructor(
    private afMessaging: AngularFireMessaging
) {
 
}
requestPermission() {
    this.afMessaging.requestPermission
      .pipe(mergeMapTo(this.afMessaging.tokenChanges))
      .subscribe(
        (token) => { console.log('Permission granted! Save to the server!', token); },
        (error) => { console.error(error); },  
      );
  }
 

  receiveMessage() {
    this.afMessaging.messages.subscribe(
        (payload) => {
            debugger
          console.log("new message received. ", payload);
          this.currentMessage.next(payload);
        }) 
    }


    listen() {
        debugger
        this.afMessaging.messages
          .subscribe((message) => { 
              debugger
              console.log(message);
           });
      }

}