import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
 
  
@Injectable({
  providedIn: 'root'
})
export class DesignUtilityService {
  public screenSizeObserver = new BehaviorSubject<string>('xl');

  displayNameMap = new Map([
    [Breakpoints.XSmall, 'xs'],
    [Breakpoints.Small, 'sm'],
    [Breakpoints.Medium, 'md'],
    [Breakpoints.Large, 'lg'],
    [Breakpoints.XLarge, 'xl'],
  ]); 
  constructor(private breakpointObserver: BreakpointObserver) {
    
    breakpointObserver.observe([
      Breakpoints.XSmall,
      Breakpoints.Small,
      Breakpoints.Medium,
      Breakpoints.Large,
      Breakpoints.XLarge,
    ]).subscribe(result => { 
      debugger
      for (const query of Object.keys(result.breakpoints)) {
        if (result.breakpoints[query]) { 
         this.screenSizeObserver.next(this.displayNameMap.get(query) ?? 'Unknown');
        }
      }
    });
  }

  public get size(): Observable<string> {
    debugger
    return this.screenSizeObserver;
  }
 
}