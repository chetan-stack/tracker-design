import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { finalize } from 'rxjs/operators';
import { environment } from '../../environments/environment'; 
import { ServiceFactory } from '../factory/service-factory.service'; 
import Swal from 'sweetalert2';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { DataFactoryService } from '../factory/data-factory.service';
import { CommonService } from './common.service';
 

@Injectable({
  providedIn: 'root'
})
export class IncentiveService {

    incentiveServerUrl = environment.incentiveUrl;
    ragisterrUrl = environment.ragisterrUrl;
    getCurrent: any
    requestOptions: any
  
  constructor(
    private http: HttpClient,  
    private serviceFactory: ServiceFactory,  
    private dataFactory: DataFactoryService, 
    private cookieService: CookieService ,
    private router: Router,
    private commonService: CommonService
    ) {
        this.getCurrent = commonService.getCurrentUser()

        const headerDict = {
            'authorization': 'Bearer '+ this.getCurrent['token'],  
        }

        this.requestOptions = {                                                                                                                                                                                 
            headers: new HttpHeaders(headerDict), 
          }

         // console.log(this.getCurrent);
          
    }


    // headerDict = {
    //     'authorization': 'Bearer '+ this.getCurrent,  
    // }

    // requestOptions = {                                                                                                                                                                                 
    //     headers: new HttpHeaders(headerDict), 
    // }

    liveinCentive(data: any) {
        return this.http.post<any>(`${this.incentiveServerUrl}live_incentive_role`, data, this.requestOptions);
    }


    incentive_details(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}role_incentive_calculate`, data, this.requestOptions);
    }


    monthly_incentive_details(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}monthly_incentive_calculate`, data, this.requestOptions);
    }

    counsellor_search(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}counselor_search`, data, this.requestOptions);
    }

    counselor_list(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}counselor_list`, data, this.requestOptions);
    }

    manager_filter(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}manager_account_search`, data, this.requestOptions);
    }

    approve_reject(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}approval_reject`, data, this.requestOptions);
    }

    Account_staging(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}incentive_staging`, data, this.requestOptions);
    }

    manager_edit(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}edit_by_manager`, data, this.requestOptions);
    }
    manager_list(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}manager_list`, data, this.requestOptions);
    }
    lead_management(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}lead_management`, data, this.requestOptions);
    }

    lead_update(data: any){
      return this.http.post<any>(`${this.incentiveServerUrl}update_lead`, data, this.requestOptions);
    }
    // RagisteRR api ------------------------




  /* get request */
  RGet(url:any, params?:any){

    
    const headerDict = {
      'Authorization': 'Bearer '+this.getCurrent.token,
      'user_id': this.getCurrent.id.toString(),  
    }
    const requestOptions = {                                                                                                                                                                                 
      headers: new HttpHeaders(headerDict), 
    };
      return this.http.get<any>(this.ragisterrUrl+url,requestOptions).pipe()
   }


   
 /* post request */
   RPost(url:any, params?:any,wait?:any){ 
    debugger 
     let headerDict = {
      'authorization': 'Bearer '+this.getCurrent.token,
      'user_id': this.getCurrent.id.toString(),
     
    } 

    const requestOptions = {                                                                                                                                                                                 
      headers: new HttpHeaders(headerDict), 
    }; 
    
  return this.http.post<any>(this.ragisterrUrl+url, params,requestOptions).pipe()
 }

 
    
  
   
  
    // list_data() {
    //   return this.http.get<any>(`${this.incentiveServerUrl}list_data`);
    // }
    // search_details(data){
    //   return this.http.post<any>(`${this.incentiveServerUrl}search_details`, data);
    // }
  
  
   
    // headerDict = {
    //   'Content-Type': 'application/json',
    //   'Accept': 'application/json',
    //   'Access-Control-Allow-Headers': '*',
    // }
  
    // requestOptions = {
    //   headers: new HttpHeaders(this.headerDict),
    // };
  
  
    // incentive_calculate(data: any) {
    //   return this.http.post<any>(`${this.incentiveServerUrl}incentive_calculate`, data);
    // }
  
    // edit_profile(data: any) {
    //   return this.http.post<any>(`${this.incentiveServerUrl}edit_profile`, data);
    // }
  
    // get_profile() {
    //   return this.http.get<any>(`${this.incentiveServerUrl}get_profile`);
    // }
  
 
 
  
    //End ----------
}
