 
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Observer } from 'rxjs';
import { io } from "socket.io-client";
import { CoreModule } from 'src/app/user/core/core.module';
import { DataFactoryService } from '../factory/data-factory.service';
import { CommonService } from './common.service';

@Injectable()
export class WebsocketService {
  getCurrentUser: any ={};
  getUserProfile:any = {}; 
 
  public socket:any; 
  public socketUrl ="http://localhost:3000";
 
  public getContactList = new BehaviorSubject<any>({});
  public getOnlineVisitors = new BehaviorSubject<any>({});
  constructor(
    private commonService: CommonService, 
    private dataFactory: DataFactoryService, 
  ) {
    this.getCurrentUser = this.commonService.getCurrentUser();  
  }

  setupSocketConnection() {
    debugger
    this.socket = io(this.socketUrl, {
      auth: {
        token: this.getCurrentUser.token 
      },
      query: {
        user_id:this.getCurrentUser.id,
        center_id: this.getCurrentUser.center_id
    }
    });  
    this.socket.on('visitors', (user: any) => {
      this.getOnlineVisitors.next(user);
      console.log(user)
    });  
  }

  

   public getEmit(event: any, data?: any) {
    return new Promise((resolve, reject) => {
        if (!this.socket) {
            reject('No socket connection.');
        } else {
            this.socket.emit(event, data, (response:any) => {
                if (response.error) {
                    console.error(response.error);
                    reject(response.error);
                } else {
                    resolve(response);
                }
            });
        }
    });
}

 
 
  public getMessages = () => {
    return new Observable((observer: Observer<object>) => { 
      this.socket.on('new-message', (message:any) => {
        observer.next(message);
      });
     }); 
   
    }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect();
    }
  }
}