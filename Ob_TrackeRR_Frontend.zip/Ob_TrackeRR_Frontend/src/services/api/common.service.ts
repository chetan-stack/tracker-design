import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; 
import { finalize, take } from 'rxjs/operators';
import { environment } from '../../environments/environment'; 
import { ServiceFactory } from '../factory/service-factory.service'; 
import Swal from 'sweetalert2';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { DataFactoryService } from '../factory/data-factory.service';
import { SwPush } from '@angular/service-worker';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
 
declare const navigator: any;
@Injectable({
  providedIn: 'root'
})
export class CommonService {

  logedUserId:any;
  serverUrl = environment.baseUrl;
  pushIsSubscribed = false;
  constructor(
    private http: HttpClient,  
    private serviceFactory: ServiceFactory,  
    private dataFactory: DataFactoryService, 
    private cookieService: CookieService ,
    private router: Router,
    private swPush: SwPush,
    @Inject(PLATFORM_ID) private platformId: object,
    @Inject(DOCUMENT) private document: Document
    ) {
      this.dataFactory.get_pushIsSubscribed().subscribe(res => {
        this.pushIsSubscribed = res;
    })
    }

    login(option:any) {
      // debugger 
      this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
       return this.http.post<any>(`${this.serverUrl}userProfile/sign_in`,option).pipe( 
         finalize(() => { 
         this.serviceFactory.loadingStop("body","");
         })
       );
     } 
  
     forgotPasswordOTPSend(option:any) {
      // debugger 
      this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
       return this.http.post<any>(`${this.serverUrl}userProfile/forgotPasswordOTPSend`,option).pipe( 
         finalize(() => { 
         this.serviceFactory.loadingStop("body","");
         })
       );
     } 
    
     forgotPasswordOTPVerify(option:any) {
      // debugger 
      this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
       return this.http.post<any>(`${this.serverUrl}userProfile/forgotPasswordOTPVerify`,option).pipe( 
         finalize(() => { 
         this.serviceFactory.loadingStop("body","");
         })
       );
     }
     
     forgotPasswordUpdate(option:any) {
      // debugger 
      this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
       return this.http.post<any>(`${this.serverUrl}userProfile/forgotPasswordUpdate`,option).pipe( 
         finalize(() => { 
         this.serviceFactory.loadingStop("body","");
         })
       );
     }
     

  /* get request */
   get(url:any, params?:any){

    
    let getCurrent = this.getCurrentUser(); 
    const headerDict = {
      'authorization': 'JWT '+getCurrent.token,  
    }
    const requestOptions = {                                                                                                                                                                                 
      headers: new HttpHeaders(headerDict), 
    };
      return this.http.get<any>(this.serverUrl+url,requestOptions).pipe()
   }


   
 /* post request */
   post(url:any, params?:any,wait?:any){ 
    //debugger
     let getCurrent = this.getCurrentUser(); 
     let headerDict = {
      'authorization': 'JWT '+getCurrent.token, 
    } 

    const requestOptions = {                                                                                                                                                                                 
      headers: new HttpHeaders(headerDict), 
    };
   
    let activeRoleId:any;
    new Promise((resolve, reject) => {
      activeRoleId = getCurrent.role.filter((item:any) => item.role_key === getCurrent.activeRole)[0].id;
         resolve(activeRoleId)
     })

     if(params instanceof FormData){
      params.append('active_role_id',activeRoleId);
      params.append('active_user_id',getCurrent.id) 
     }else{
      params["active_role_id"] = activeRoleId;
      params["active_user_id"] = getCurrent.id
     }
     
     
    
    
  return this.http.post<any>(this.serverUrl+url, params,requestOptions).pipe()
 }
 

  /* post request */
  post_alphabet(url:any, params?:any,wait?:any){ 
    //debugger
     let getCurrent = this.getCurrentUser(); 
     let headerDict = {
      // 'authorization': 'JWT '+getCurrent.token, 
    } 

    const requestOptions = {                                                                                                                                                                                 
      headers: new HttpHeaders(headerDict), 
    };
   
    let activeRoleId:any;
    new Promise((resolve, reject) => {
      activeRoleId = getCurrent.role.filter((item:any) => item.role_key === getCurrent.activeRole)[0].id;
         resolve(activeRoleId)
     })

     if(params instanceof FormData){
      params.append('active_role_id',activeRoleId);
      params.append('active_user_id',getCurrent.id) 
     }else{
      params["active_role_id"] = activeRoleId;
      params["active_user_id"] = getCurrent.id
     }
     
     
    
    
  return this.http.post<any>(environment.alphabet+url, params,requestOptions).pipe()
 }

// post_alphabet(url:any, params?:any,wait?:any){ 
//   debugger
//   let alphabetUrl = "https://alphabet.researchandranking.com/"; 
//   return this.http.post<any>(alphabetUrl+url, params).pipe()
//  }


/****************/

 
changeActiveRole(value:any){
  this.cookieService.delete('activeRole','/'); 
  this.cookieService.set( 'activeRole', value,365,'/');   
  this.userTypeRedirect();
}

 isLoggedIn() {   
  //debugger    
  if (this.cookieService.get('TrackeRR_user_data')) { 
    return true;
  }     
  return false;
}

userTypeRedirect() { 
  debugger
 // this.router.navigateByUrl(this.returnUrl); 


     if(this.isLoggedIn()){  
      let getCurrent = this.getCurrentUser(); 
      if(getCurrent.activeRole == "counsellor"){
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['./counsellor'])
        );
      } else if(getCurrent.activeRole == "manager"){ 
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['./manager'])
        );
      } else if(getCurrent.activeRole == "saleshead"){ 
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['./saleshead'])
        );
      } else if(getCurrent.activeRole == "admin"){ 
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['./admin'])
        );
      }else if(getCurrent.activeRole == "account"){
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['./account'])
        );
      }else if(getCurrent.activeRole == "ops"){
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(()=>
        this.router.navigate(['./ops'])
        );
      }


      }else{
        this.router.navigate(['./login'])
      }
  }



getCurrentUser() {  
  //debugger 

    let userData = JSON.parse(this.cookieService.get('TrackeRR_user_data')); 
    let roleType = this.cookieService.get('activeRole'); 
    userData['activeRole'] = roleType;
    return userData
  }

  getAuthorizatioRole() {  
    //debugger 
    let getCurrentUser = this.getCurrentUser(); 
     return getCurrentUser.activeRole;   
    }

  async logout(url:any) { 
    debugger  

    if(this.pushIsSubscribed){
      this.unsubscribe('logout'); 
     }else{
      this.cookieService.delete('TrackeRR_user_data','/'); 
      this.cookieService.delete('activeLoginType','/'); 
      this.cookieService.delete('activeRole','/'); 
      navigator.clearAppBadge(); 
      //this.router.navigate(['./login']);
      window.location.reload();
       
     }
    
  }  


  logoutByClick(url:any) {
   debugger
   Swal.fire({ 
    title: 'Logout',
    html: 'Are you sure you want to Logout?', 
   // icon: 'warning', 
    customClass: {
        confirmButton: 'mat-flat-button mat-button-base mat-warn order-last',
        cancelButton: 'mat-stroked-button mat-button-base ',
        container: 'modal-yes-no Modal_Delete', 
        actions: 'modal-btn-yes-no mb-4',
       // closeButton: 'btn-modal-dismiss',
      // header: 'pt-4', 
    },
    width: '36em',
    showCloseButton: true,
    buttonsStyling: false,
    showCancelButton: true,
    confirmButtonText: 'Logout',
    cancelButtonText: 'Cancel' ,       
}).then((result) => {
  debugger 
  if(result.value){  
    this.logout(url);   
   }
}) 

 }
 
 
 unsubscribe(from:any){
  let forThis = this; 


  navigator.serviceWorker.ready.then(function(reg:any) {
      console.log("++++++++++++++++ reg")
      console.log(reg);
      reg.pushManager.getSubscription().then(function(subscription:any) {
      console.log("++++++++++++++++ subscription")
      console.log(subscription);
      let pushData = subscription;
      if(!pushData){
       return
      }
      subscription.unsubscribe().then(function(successful:any) {
        console.log("++++++++++++++++ successful")
        console.log(successful);
        if(from=="click"){
          forThis.serviceFactory.notification('Notification unsubscribed for this device.',false);
        }
        forThis.serviceFactory.loadingStart("body","Please wait while loading...","");
        forThis.post('userProfile/subscribePush',{
          action:'unsubscribe',
          swPush:pushData 
        }).pipe( 
          finalize(() => {  
            forThis.serviceFactory.loadingStop("body","");
            if(from=="logout"){
              navigator.clearAppBadge();
              forThis.cookieService.delete('TrackeRR_user_data','/'); 
              forThis.cookieService.delete('activeLoginType','/'); 
              forThis.cookieService.delete('activeRole','/');
              window.location.reload(); 
              //forThis.router.navigate(['./login']);
            }
          })
        ).subscribe((res) => {
         if(res.data && res.data.subscribePush==false){
           forThis.dataFactory.set_pushIsSubscribed(false);
         }   
       
        }); 

      }).catch(function(e:any) {
        console.log("Unsubscription failed");
        console.log(e); 
        forThis.serviceFactory.loadingStop("body","");
        if(from=="logout"){
          navigator.clearAppBadge();
          forThis.cookieService.delete('TrackeRR_user_data','/'); 
          forThis.cookieService.delete('activeLoginType','/'); 
          forThis.cookieService.delete('activeRole','/'); 
          window.location.reload();
         // forThis.router.navigate(['./login']);
        } 
      })
    })
  }); 
} 

requestPermission(from:any) {  
  console.log(this.swPush)
  if(!this.swPush.isEnabled){
   return
  }

  let forThis = this;
  
  navigator.serviceWorker.ready.then(function(reg:any) {
    console.log("++++++++++++++++ reg")
    console.log(reg);
    reg.pushManager.getSubscription().then(function(subscription:any) {
      console.log("++++++++++++++++ subscription")
      console.log(subscription);
      let pushData = subscription;
      if(pushData){ 
        forThis.dataFactory.set_pushIsSubscribed(true);
        return
      }
      let device=""; 
      if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
        device="Mobile"
       }else{
        device="Desktop"
       }

       //***********
       forThis.swPush.requestSubscription({
        serverPublicKey: forThis.getCurrentUser().vapidKeys.publicKey
       }).then(pushSubscription => { 
        forThis.serviceFactory.loadingStart("body","Please wait while loading...","");
             console.log("pushSubscription================")
             console.log(pushSubscription)
             forThis.post('userProfile/subscribePush',{
               action:'new',
               device_type:device,
               userAgent:navigator.userAgent,
               pushKeys:{
                 swPush:pushSubscription,
                 vapidPush:forThis.getCurrentUser().vapidKeys
               }
             }).pipe( 
               finalize(() => {  
                forThis.serviceFactory.loadingStop("body","");
               })
             ).subscribe((res) => {  
               if(res.data && res.data.subscribePush){
                 forThis.dataFactory.set_pushIsSubscribed(true); 
                 forThis.serviceFactory.notification('Notification subscribed for this device.',true); 
                }else{
                  forThis.dataFactory.set_pushIsSubscribed(false);
                  
                } 
             });
        })
      .catch(err => {  
        forThis.dataFactory.set_pushIsSubscribed(false);
       console.error("err==============");
        console.error(err); 
          if(from=="click"){
            Swal.fire({ 
              title: 'Notifications blocked!',
              html: `<p style="line-height: 26px;font-size: 14px;">You've blocked notifications. Please click on the lock pad icon in the address bar, then set "Notifications" permission to "Ask(default)". Refresh the page.</p>`, 
              customClass: {
                  confirmButton: 'mat-flat-button mat-button-base mat-warn order-last',
                  cancelButton: 'mat-stroked-button mat-button-base ',
                  container: 'modal-yes-no Modal_Delete', 
                  actions: 'modal-btn-yes-no mb-4 mt-3', 
              },
              width: '36em',
              showCloseButton: true,
              buttonsStyling: false,
              showCancelButton: false,
              confirmButtonText: 'OK',
              cancelButtonText: 'Cancel' ,       
             }).then((result) => {}) 
          }  
         });
    });
  });
 
  
}
 

detectBrowserName() {  

  const agent = window.navigator.userAgent.toLowerCase()
  switch (true) {
    case agent.indexOf('edge') > -1:
      return 'edge';
    case agent.indexOf('opr') > -1 && !!(<any>window).opr:
      return 'opera';
    case agent.indexOf('chrome') > -1 && !!(<any>window).chrome:
      return 'chrome';
    case agent.indexOf('trident') > -1:
      return 'ie';
    case agent.indexOf('firefox') > -1:
      return 'firefox';
    case agent.indexOf('safari') > -1:
      return 'safari';
    default:
      return 'other';
  }
}

loadProfile(id:any){
  this.post('userProfile/getProfile',{id:id}).subscribe((res:any) => {
    if(res.status){
      let data = res.data;
      if(!data['profile_image_path']){
        data['profile_image_path'] = './assets/images/no_profile_'+data['gender']+'.svg'
      }
      
       this.dataFactory.set_Profile(data); 
    } 
  })  
}


}
