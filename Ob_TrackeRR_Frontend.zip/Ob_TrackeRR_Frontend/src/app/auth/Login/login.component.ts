import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, Validators, FormGroup, NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router'; 
 
import { CookieService } from 'ngx-cookie-service'; 
 
import { ServiceFactory } from '../../../services/factory/service-factory.service';
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';
import Swal from 'sweetalert2'; 
import { AnimationOptions } from 'ngx-lottie';  
 

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  options: AnimationOptions = {
    path: 'assets/an/lf20_2UeWRZ.json',
  };
  
  @ViewChild('loginForm') public loginForm: NgForm; 
  @ViewChild('ForgotForm') public ForgotForm: NgForm;
  @ViewChild('OTPVerifyForm') public OTPVerifyForm: NgForm;
  @ViewChild('ChangePSForm') public ChangePSForm: NgForm;
  ifLoginForm=true;
  ifForgotForm = false;
  ifOtpForm = false;
  ifChangePSForm = false;


  passwordShowHide = true;
  
  returnUrl: string; 
  loginErrorMSG:any;

  supportForm: FormGroup;
  DialogRef_contactUs:any;

   
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute, 
    private commonService: CommonService,
    private serviceFactory: ServiceFactory, 
    private dialog: MatDialog,
    private cookieService: CookieService,  
    
    ) {  
      
      this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '';
      if(this.commonService.isLoggedIn()){ 
         this.router.navigateByUrl(this.returnUrl); 
      }
 
     }

  ngOnInit() { 
  
  }
  ngAfterViewInit() { 

    this.loginForm.valueChanges?.subscribe(x => { 
      this.loginErrorMSG = false; 
   })
  
  }
  

  trimString(Form:any,name:any,event:any){
     //debugger
    if(event){
      Form.controls[name].setValue(event.currentTarget.value.trim());
    }
    
  }
 
  trimSpace(Form:any,name:any,event:any){
  //  debugger
    if(event){
      Form.controls[name].setValue(event.currentTarget.value.replace(/\s/g, ''));
    }
    
  }

  onSubmitLogin(form_elm:any) {  
    debugger 
    this.cookieService.delete('TrackeRR_user_data','/'); 
    this.cookieService.delete('activeLoginType','/'); 
    this.cookieService.delete('activeRole','/');  

   if(!form_elm.valid){
     return false
   }  
     
      this.commonService.login(form_elm.value).subscribe((res:any) => {
      
      this.serviceFactory.notification(res.message,res.status);  
      if (res.status && res.data) { 
        let data =res.data; 

         if(!data['role'] || data['role'].length==0 || data.role[0].id==null){
          this.serviceFactory.msgPop('Profile is not updated please contact sales head.','error');
          //this.commonService.logout('./login'); 
          return
         } 
        
        this.cookieService.set( 'TrackeRR_user_data', JSON.stringify(data),365,'/');
       //we have getting multiple roles but we are redirect to 1st index role
       setTimeout(()=>{   
         this.commonService.changeActiveRole(data.role[0].role_key); 
         //this.dataFactory.set_data('logged_in',true);
       },200);
        
            
       }else{
            this.loginErrorMSG = res.message;
       } 
      }  
    );
  }
 
  async ForgotPassword(){
    debugger
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    let email = this.loginForm.value.email_id;
    setTimeout(()=>{  
      this.ifLoginForm=false;
      this.ifForgotForm = true;
      this.serviceFactory.loadingStop("body","");
  }, 300);
  
    
    setTimeout(()=>{   
      this.ForgotForm.controls.email_id.setValue(email);
      this.ForgotForm.valueChanges?.subscribe(x => { 
        this.loginErrorMSG = false; 
      })
   }, 500);
    
     
  }
  
  onSubmitForgot(form_elm:any) { 

   if(!form_elm.valid){
     return false
   }  
     
      this.commonService.forgotPasswordOTPSend(form_elm.value).subscribe((res:any) => {
      debugger
      this.serviceFactory.notification(res.message,res.status);  
       if (res.status) {      
        this.ifOtpForm = true;
        this.ifForgotForm = false;
        setTimeout(()=>{   
          this.OTPVerifyForm.controls.email_id.setValue(res.data.email_id); 
          this.OTPVerifyForm.valueChanges?.subscribe(x => { 
            this.loginErrorMSG = false; 
          })
        }, 200);
       }else{
            this.loginErrorMSG = res.message;
       } 
      }  
    );
  }
  onSubmitOTPVerify(form_elm:any) { 

   if(!form_elm.valid){
     return false
   } 
      
      this.commonService.forgotPasswordOTPVerify(form_elm.value).subscribe((res:any) => {
      debugger
      this.serviceFactory.notification(res.message,res.status);  
 
      if (res.status) { 
        this.ifOtpForm = false; 
        this.ifChangePSForm = true; 
        setTimeout(()=>{   
          this.ChangePSForm.controls.email_id.setValue(res.data.email_id); 
          this.ChangePSForm.valueChanges?.subscribe(x => { 
            this.loginErrorMSG = false; 
          })
        }, 200);
       }else{
            this.loginErrorMSG = res.message;
       } 
      }  
    );
  }


  onSubmitChangePS(form_elm:any) { 
debugger
    if(!form_elm.valid){
      return false
    } 
       
       this.commonService.forgotPasswordUpdate(form_elm.value).subscribe((res:any) => {
       debugger
       this.serviceFactory.notification(res.message,res.status);  
        
       if (res.status) { 
          this.passsordChanged(form_elm,res)
        }else{
             this.loginErrorMSG = res.message;
        } 
       }  
     );
   }
   

   passsordChanged(form_elm:any,res:any){
     debugger
     let enail = form_elm.value.email_id;
     let password = form_elm.value.password;
     this.ifLoginForm=true; 
     this.ifChangePSForm = false;
     Swal.fire({
      buttonsStyling: false, 
      allowOutsideClick:false,
      showCloseButton: false, 
      showCancelButton: true,
      confirmButtonText: 'Login',
      cancelButtonText: 'Cancel', 
      customClass: {
        confirmButton: 'mat-flat-button mat-button-base mat-warn',
        cancelButton: 'mat-stroked-button mat-button-base ',
        container: 'modal-yes-no Modal_Delete', 
        actions: 'modal-btn-yes-no mb-4',
       // closeButton: 'btn-modal-dismiss',
      // header: 'pt-4', 
    },
        title:'Success',	
        html: "Password updated successfully.",
        icon:'success',
      }).then((result) => {
        debugger
        /* Read more about isConfirmed, isDenied below */
       

        if (result.isConfirmed) {
          this.loginForm.controls['email_id'].setValue(enail);
          this.loginForm.controls['password'].setValue(password);
          this.loginForm.ngSubmit.emit();
        } else if (result.isDenied) {
         
        }
      }) 

   }

   refresh(): void {
     if(!this.ifLoginForm){
      window.location.reload();
     }
    
}
}
