import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { Router } from '@angular/router'; 

import { AuthRoutingModule,AuthModuleConst } from './auth-routing.module';  
 
import { MustMatchDirective } from '../directive/must-match.directive'; 
import { LottieModule } from 'ngx-lottie';
import player from 'lottie-web';
import { SharedModule } from '../user/shared/shared.module';

export function playerFactory() {
  return player;
}

@NgModule({
  declarations: [AuthModuleConst,MustMatchDirective],
  imports: [
    CommonModule, 
    AuthRoutingModule, 
    SharedModule,
    LottieModule.forRoot({ player: playerFactory })
    
  ] 
})
export class AuthModule {
  constructor(  
    private router: Router,
     ) { 
    }
 }