import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivateChild } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
 
 
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {
  
  canChild:boolean=false;
  constructor(
     private commonService: CommonService,
     private router: Router
     ) {
     // debugger
     } 

     
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): any {     
    const roles: string =  route.data.roles; 
    const url: string = state.url;
    return this.checkLogin(roles,url); 
    
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
     debugger
    this.canChild =true;
    return this.canActivate(route, state);
  }

  checkLogin(roles: string,url: string) { 
      //debugger
    
    if (this.commonService.isLoggedIn()) {

       if(roles==='user'){
          return true 
       }

      if (roles &&  this.commonService.getAuthorizatioRole() ==roles) {
        // not authorised so redirect to home page
        return true
      }else{
        this.router.navigate(['/']);
        return false;
      }

     
       
    } 
     
    
    
    //this.commonService.redirectUrl = url;

    this.router.navigate(['./login'], {queryParams: { returnUrl: url }} );
    
  }
}
