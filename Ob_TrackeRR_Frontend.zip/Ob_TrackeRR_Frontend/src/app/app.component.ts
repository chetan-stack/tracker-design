import { DOCUMENT } from '@angular/common';
import { ApplicationRef, Component, Inject, PLATFORM_ID } from '@angular/core';
import { SwUpdate } from '@angular/service-worker';
import { interval } from 'rxjs';
import { A2hsService } from 'src/services/utility/a2hs.service';
let newVariable: any;



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'TrackeRR';
  constructor( 
    public a2hs: A2hsService,   
    private swUpdate: SwUpdate, 
    private appRef:ApplicationRef,
    @Inject(PLATFORM_ID) private platformId: object,
    @Inject(DOCUMENT) private document: Document
  ) {  
 
    newVariable = window.navigator;

     // A2HS - START
     a2hs.checkUserAgent();
     a2hs.trackStandalone();
     window.addEventListener('beforeinstallprompt', (e) => { 
       a2hs.promptIntercepted = true; 
       e.preventDefault(); 
       a2hs.deferredPrompt = e;
       a2hs.promptSaved = true;
 
     });
     window.addEventListener('appinstalled', (evt) => {
       console.log('window.appinstalled')
       a2hs.trackInstalled(); 
     });
     // A2HS - END

     this.updateToLatest();
  }

 ngOnInit(): void {  
  

  // navigator.serviceWorker.getRegistration()
  //  .then(function(registration) {
  //      if(registration){
  //         registration.unregister()
  //         .then(
  //              function(success) {

  //               if ('caches' in window) {
  //                 caches.keys()
  //                   .then(function(keyList) {
  //                       return Promise.all(keyList.map(function(key) {
  //                           return caches.delete(key);
  //                       }));
  //                   })
  //             }

  //                // if success = true, unregister was successful
  //               });
  //         }
  //   });


  
  //this.checkForUpdates();
 // this.getInstalledRelatedApps();
  }

  // async getInstalledRelatedApps() {
  //   console.log("newVariable"+newVariable);
  //   const relatedApps = await newVariable.getInstalledRelatedApps();
  //   console.log("relatedApps"+relatedApps);
  //     relatedApps.forEach((app:any) => {
  //       console.log(app.id, app.platform, app.url);
  //     });
  // }
  

  updateToLatest(): void {
    //alert('updateToLatest');

    if(!this.swUpdate.isEnabled){
      console.log('swUpdate Not isEnabled !!');
      return;
    }
      
    this.swUpdate.available.subscribe(event => { 
      console.log('current version is - ', event.current);
      console.log('available version is - ', event.available); 
       
      this.swUpdate.activateUpdate().then(() => location.reload()); 
    });

    this.swUpdate.activated.subscribe(event => { 
      console.log('previous previous is - ', event.previous);
      console.log('current version is - ', event.current);  
    });
    
    //this.swUpdate.activateUpdate().then(() => window.location.reload());
  }

  checkForUpdates(){
  this.appRef.isStable.subscribe(event => { 
     let intervalTime = interval(5000);
     intervalTime.subscribe(event => { 
      this.swUpdate.checkForUpdate().then(() => console.log('checkForUpdate====== ')); 
      console.log('Updateed========== - ');
   });
  });
}
  
}
