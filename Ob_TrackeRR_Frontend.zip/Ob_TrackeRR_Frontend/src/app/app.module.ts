import { BrowserModule, DomSanitizer } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'; 
import { httpInterceptorProviders } from '../http-interceptors/index';
import { DataFactoryService } from '../services/factory/data-factory.service'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MatIconRegistry } from '@angular/material/icon';
import { ErrorDialogModule } from './error-dialog/error-dialog.module';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { A2hsService } from 'src/services/utility/a2hs.service';


 
 

@NgModule({
  declarations: [
    AppComponent, 
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    BrowserAnimationsModule,  
    AppRoutingModule, 
    ErrorDialogModule, 
    ServiceWorkerModule.register('ngsw-worker.js?h='+environment.appVersion, {
  enabled: environment.production,
  // Register the ServiceWorker as soon as the app is stable
  // or after 30 seconds (whichever comes first).
  registrationStrategy: 'registerWhenStable:30000'
}), 
    
  ],
  providers: [
    httpInterceptorProviders,
    DataFactoryService,
    A2hsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { 
  constructor(matIconRegistry: MatIconRegistry, domSanitizer: DomSanitizer){
    matIconRegistry.addSvgIconSet(
      domSanitizer.bypassSecurityTrustResourceUrl('./assets/mdi.svg')
    );
    matIconRegistry.addSvgIconSet(
      domSanitizer.bypassSecurityTrustResourceUrl('./assets/icon.svg')
    );
  }
} 
