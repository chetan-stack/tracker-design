import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { UserModuleConst, UserRoutingModule } from './user-routing.module';
 
 
 
 

@NgModule({
  declarations: [    
    UserModuleConst
  ],
  imports: [ 
    UserRoutingModule,  
    CommonModule,    
  ], 
  providers: [],
 
})
export class UserModule {
 
 }