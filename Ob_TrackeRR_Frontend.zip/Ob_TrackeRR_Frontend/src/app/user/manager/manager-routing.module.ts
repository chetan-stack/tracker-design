import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagerComponent } from './manager.component'; 

import { AuthGuard } from '../../auth/auth.guard'; 
 

 
const routes: Routes = [ 
  {
     path: '', component: ManagerComponent, 
     canActivate: [AuthGuard], 
     data: { roles: "manager"},  
     children: [  
          {path: 'home', loadChildren: () => import(`../shared/home/home.module`).then(m => m.HomeModule)},  
          {path: '', redirectTo: 'home', pathMatch: 'full'},
          {path: 'onboarding', loadChildren: () => import(`../shared/onboarding/onboarding.module`).then(m => m.OnboardingModule)},  
          {path: 'team', loadChildren: () => import(`../shared/team/team.module`).then(m => m.TeamModule)},  
          {path: 'target', loadChildren: () => import(`../shared/target/target.module`).then(m => m.TargetModule)},
          {path: 'sales', loadChildren: () => import(`../shared/sales/sales.module`).then(m => m.SalesModule)},
          {path: 'share-leads', loadChildren: () => import(`../shared/share-leads/share-leads.module`).then(m => m.ShareLeadsModule)},  
          {path: 'secrets', loadChildren: () => import(`../shared/secrets/secrets.module`).then(m => m.SecretsModule)},
          {path: 'refund', loadChildren: () => import(`../shared/refund/refund.module`).then(m => m.RefundModule)},
          {path: 'pmp-pending', loadChildren: () => import(`../shared/pending-pmp/pending-pmp.module`).then(m => m.PendingPmpModule)},
          // {path: 'counsellor', component: CounsellorComponent ,data:{title: 'Counsellor Management'}},
          //  {path: 'dashboard', component: DashboardComponent ,data:{title: 'Manager Dashboard'}},
          //  {path: 'salesform', component: SalesformComponent ,data:{type:"Add", title: 'Sales Form Management'}},           
          //  {path: 'salesform/edit/:id', component: SalesformComponent ,data:{type:"Edit", title: 'Sales Form Management'}},
          //  {path: 'salesform/view/:id', component: SalesformComponent ,data:{type:"View", title: 'Sales Form Management'}},
          //  {path: 'salesform/edit', redirectTo: 'dashboard', },
          //  {path: 'salesform/view', redirectTo: 'dashboard', },
          {path: 'ic', loadChildren: () => import(`../shared/incentive/incentive.module`).then(m => m.IncentiveModule)}, 
          { path: 'register', loadChildren: () => import(`../shared/registe/registe.module`).then(m => m.RegisteModule)},
        ], 
     }, 
       
]; 

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManagerRoutingModule { }
export const ManagerModuleConst = [  
  ManagerComponent,  
];