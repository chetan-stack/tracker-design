import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { ManagerModuleConst, ManagerRoutingModule } from './manager-routing.module';
import { CoreModule } from '../core/core.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';



@NgModule({
  declarations: [ManagerModuleConst],
  imports: [
    CommonModule,  
    ManagerRoutingModule, 
    CoreModule,
    MatSidenavModule, 
    MatToolbarModule  
  ]
})
export class ManagerModule { }
