import { Component, HostListener, Inject, OnInit, PLATFORM_ID, Renderer2, ViewChild } from '@angular/core';  
import { Router } from '@angular/router';  
import { DataFactoryService } from 'src/services/factory/data-factory.service'; 
import { CommonService } from 'src/services/api/common.service';  
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';
import { environment } from 'src/environments/environment';

 
@Component({
  selector: 'app-user', 
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'], 
})
export class UserComponent implements OnInit {

  
  getCurrentUser:any = {}; 

 
  constructor( 
    private router: Router,  
    private renderer: Renderer2,    
    public commonService: CommonService,  
    private dataFactory: DataFactoryService,  
    private serviceFactory: ServiceFactory, 
   // private swPush: SwPush,
  
  ) {  
    

    this.getCurrentUser = this.commonService.getCurrentUser();

    if(this.commonService.isLoggedIn() && (this.router.url==='/' || this.router.url==='')){
      this.commonService.userTypeRedirect();  
    }

  
    this.dataFactory.getHeaderType().subscribe(res => { 
      this.renderer.setAttribute(document.body, 'set-theme', 'theme_'+res); 
    })
    
    this.commonService.loadProfile(this.getCurrentUser.id);  

    this.dataFactory.get_Profile().subscribe(res => {  
      let deniedDate = new Date().getDate()>4;
      // if(environment.production){ 
      //   deniedDate = new Date().getDate()>4;
      // } 
      
      if((this.getCurrentUser.activeRole=='saleshead' || this.getCurrentUser.activeRole=='manager') && Object.keys(res).length != 0 && deniedDate){        

       

        if(!res['team_target']){

           let ifSaleshead = this.getCurrentUser.role.filter((item:any) => item.role_key == 'saleshead'); 

           if(ifSaleshead.length>0){
             this.commonService.changeActiveRole('saleshead'); 
                setTimeout(()=>{  
                  this.showTargetPop('saleshead'); 
                  return
                },200);
            }else{
              setTimeout(()=>{  
                this.showTargetPop('manager'); 
                return
              },200);
              
            }
           

          

          
          
          
          
         }
      }
     // this.getUserProfile = res; 
   })
   
   this.loadTeamList();
   this.load_AccessMasterList();
    

  

 /*

    this.swPush.messages.subscribe((res:any) => {
       if(res['notification'] && res['notification'].body){ 

        let ifPushVoice = this.cookieService.get('pushVoice');
        if(ifPushVoice && JSON.parse(ifPushVoice)){ 
         
          setTimeout(()=>{   

            let text = res['notification'].body.replaceAll('\n', ' ');
   
            var synthesis = window.speechSynthesis;
            var voices = synthesis.getVoices();

            var setVoice = voices.filter(elm => elm.name =='Google हिन्दी')
            

            var utterThis  = new SpeechSynthesisUtterance(text); 
             if(setVoice && setVoice.length>0){
              utterThis.voice = setVoice[0]
             } 
   
            synthesis.speak(utterThis);
           },800); 
        }
        
         
        
       }

     }) 
      */ 
  }
 

  showTargetPop(user:any){
    let msgShow = "You won't be able to access your TrackeRR, until Target is not set. Kindly contact your Sales Head to set the Target."
    if(user=='saleshead'){
      msgShow = "You won't be able to access your TrackeRR, until Target is not set. Kindly set the Target."
    }


    Swal.fire({ 
      title: 'Access Denied!',
      html: `<p style=" line-height: 25px; font-size: 16px; ">${msgShow}</p>`,
      icon: 'error', 
   customClass: {
     confirmButton: 'mat-flat-button mat-button-base mat-primary',
     cancelButton: 'mat-stroked-button mat-button-base ',
     container: 'modal-yes-no Modal_Delete', 
     actions: 'modal-btn-yes-no mb-4 mt-2',
     //  header: 'pt-4', 
   },
   //width: '36em',
   showCloseButton: false,
   buttonsStyling: false,
   showCancelButton: false,
   showConfirmButton:true,
   confirmButtonText: user=='saleshead'?'Set Target':'Reload',
   cancelButtonText: 'Cancel' , 
   focusConfirm:false, 
   focusCancel:false,  
   allowOutsideClick: false   
  }).then((result:any) => {
    debugger
     if (result.isConfirmed) { 
      if(user=='saleshead'){
        this.router.navigate(['./'+user+'/target']); 
      }else{
        window.location.reload();
      }
       
     }
    })
    
  }

  loadTeamList(){
    this.commonService.get('userProfile/teamListData').subscribe((res:any) => {
      if(res.status){
        let data = res.data;
        let teamArr:any = [];
        res.data.forEach((elm:any) => {
          elm['access_id'] = elm.access_id.split(',').map((x:any) => Number(x));
          elm['lead_share_with'] = elm.lead_share_with.split(',').map((x:any) => Number(x));
          teamArr.push(elm)
        }); 

        this.dataFactory.set_TeamList(teamArr); 
     } 
     })   
 }

 load_AccessMasterList(){ 
  //debugger  
  this.commonService.get('userProfile/getAccessMasterList').subscribe(async (res:any) => {
    if(res.status){ 
      this.dataFactory.set_AccessMasterList(res.data);  
    }
   }) 

 } 

 ngOnInit() {
 }

ngOnDestroy() {
 }
 
 
 

 }


 
