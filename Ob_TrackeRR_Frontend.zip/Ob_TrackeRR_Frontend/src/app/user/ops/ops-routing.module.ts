import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OpsComponent } from './ops.component'; 

import { AuthGuard } from '../../auth/auth.guard'; 
 

 
const routes: Routes = [ 
  {
     path: '', component: OpsComponent, 
     canActivate: [AuthGuard], 
     data: { roles: "ops"},  
     children: [  
          {path: 'home', loadChildren: () => import(`../shared/home/home.module`).then(m => m.HomeModule)},  
          {path: '', redirectTo: 'home', pathMatch: 'full'},
         // {path: 'onboarding', loadChildren: () => import(`../shared/onboarding/onboarding.module`).then(m => m.OnboardingModule)},  
          //{path: 'team', loadChildren: () => import(`../shared/team/team.module`).then(m => m.TeamModule)},  
         // {path: 'target', loadChildren: () => import(`../shared/target/target.module`).then(m => m.TargetModule)},
          {path: 'sales', loadChildren: () => import(`../shared/sales/sales.module`).then(m => m.SalesModule)},
          {path: 'secrets', loadChildren: () => import(`../shared/secrets/secrets.module`).then(m => m.SecretsModule)},
          {path: 'refund', loadChildren: () => import(`../shared/refund/refund.module`).then(m => m.RefundModule)},
          {path: 'enach', loadChildren: () => import(`../shared/e-nach/e-nach.module`).then(m => m.ENachModule)},
          {path: 'rnr-customer', loadChildren: () => import(`../shared/rnr-customer/rnr-customer.module`).then(m => m.RnrCustomerModule)},
          // {path: 'counsellor', component: CounsellorComponent ,data:{title: 'Counsellor Management'}},
          //  {path: 'dashboard', component: DashboardComponent ,data:{title: 'Ops Dashboard'}},
          //  {path: 'salesform', component: SalesformComponent ,data:{type:"Add", title: 'Sales Form Management'}},           
          //  {path: 'salesform/edit/:id', component: SalesformComponent ,data:{type:"Edit", title: 'Sales Form Management'}},
          //  {path: 'salesform/view/:id', component: SalesformComponent ,data:{type:"View", title: 'Sales Form Management'}},
          //  {path: 'salesform/edit', redirectTo: 'dashboard', },
          //  {path: 'salesform/view', redirectTo: 'dashboard', },
        ], 
     }, 
       
]; 

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OpsRoutingModule { }
export const OpsModuleConst = [  
  OpsComponent,  
];