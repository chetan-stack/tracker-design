import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-sent-refund-request',
  templateUrl: './sent-refund-request.component.html',
  styleUrls: ['./sent-refund-request.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
   // {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}, 
  ],
}) 
export class SentRefundRequestComponent implements OnInit {
  getCurrentUser: any ={}; 
   
  product_color:any= {}
  product_label:any= {}   

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}

  salesType_list:any;

  leadIdData:any = {};
  

  @ViewChild('ngElmSendRequest') public ngElmSendRequest: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;

  panVerifyed = false;
  featureImage:any={};
  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<SentRefundRequestComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
  ) {
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser(); 
     this.salesType_list = dataFactory.salesType_list;

     this.product_label = this.dataFactory.all_product_label;
     this.product_color = this.dataFactory.all_product_color;

     this.Status_Name = this.dataFactory.All_Status_Name;
     this.Status_Color = this.dataFactory.All_Status_Color;
     this.Status_Icon = this.dataFactory.All_Status_Icon; 

    if(AddEditData.type!='add'){
      this.getRefundUserById()
    }

  }

  
  ngOnInit(): void {
 
  }

 
 

  fetchLeadDetail(){
    debugger

    let control_lead_no = this.ngElmSendRequest.form.controls.lead_id; 
 
    if(control_lead_no.invalid){
      this.elm_lead_no.nativeElement.focus()
     return false
    }  
     
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('refund/fetchRefundUserByLead',{
      lead_id:control_lead_no.value
     }).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => { 
      this.serviceFactory.notification(res.message,res.status); 
     
      if(res.status){ 
         control_lead_no.setErrors(null);
         let data = res.data; 
         this.leadIdData = data; 
         
          
      }else{
        control_lead_no.setErrors({'incorrect': true});
        this.elm_lead_no.nativeElement.focus(); 
        this.leadIdData = {}; 
      }
      
    });

  }



  onSubmit(Form_Group:any){
    debugger 
     
      
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value;  

    if(!Array.isArray(elmForm['product_for'])){
      elmForm['product_for'] = JSON.parse(elmForm['product_for']);
   }

    var formData = new FormData();   

    Object.keys(elmForm).forEach(function (key) {
      if(elmForm[key]){
        formData.append(key, elmForm[key]); 
      }
   });

   formData.delete('request_attachment'); 
   if(this.featureImage['request_attachment']){
    formData.append('request_attachment', this.featureImage['request_attachment']);
   }

   formData.delete('account_attachment');
   if(this.featureImage['account_attachment']){
    formData.append('account_attachment', this.featureImage['account_attachment']);
   } 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('refund/saveRefund',formData).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res); 
      } 
     }) 
     
  
     
     
 }


 getRefundUserById(){
  debugger 
  this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
  this.commonService.post('refund/getRefundUserById',{
    id:this.AddEditData.id
   }).pipe(  
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res:any) => {  
    let data = res.data;
    data['product_for'] = JSON.stringify(data['product_for']);
    this.leadIdData = data;  
  });

}


jsonP(data:any){
  return data?JSON.parse(data):[] 
   
 
}

jsonS(data:any){
  return data?JSON.stringify(data):{}    

}

bindLabel(type:any){ 
  if(this.leadIdData['product_for']){
    return type[JSON.stringify(this.leadIdData['product_for'])]
  }
  return ''

}

verifyPAN(elm_pan_no:any){
  debugger
  if(elm_pan_no.invalid){
    return
  }

  var payload = new FormData(); 
  payload.append('pan', elm_pan_no.value); 

  this.commonService.post_alphabet('quickoPanVerify',payload).pipe(  
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res:any) => {  
     if(res.status ==="VALID"){
          this.serviceFactory.notification("Your pan verification successfully.",true);  
          this.panVerifyed = true;
          setTimeout(()=>{   
            this.ngElmSendRequest.form.controls.account_holder_name.setValue(res.full_name); 
            this.ngElmSendRequest.form.controls.pan_no.setValue(res.pan);                     
          }, 500);
           
        } else{
          this.serviceFactory.notification("Please enter valid PAN details.",false);
           this.panVerifyed = false; 
        }
  });
}


async handleFileInput(event:any,ngModel:any){ 
  debugger  
 let validFile =  await this.serviceFactory.fileFalidation(event.target.files[0],5,['png','jpg','jpeg','pdf']); 
 debugger 
 if(!validFile){
  debugger
  event.target.value = "";
  this.featureImage[ngModel] = undefined; 
 }else{
  this.featureImage[ngModel] = event.target.files[0];
  this.leadIdData[ngModel] = this.featureImage[ngModel].name; 
 } 

}

}
