import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';   
import { RefundComponent } from './refund.component'; 
import { RefundListComponent } from './refund-list/refund-list.component';

 
 
 
const routes: Routes = [ 
  {
    path: '', component: RefundComponent,  
    data:{pageType:'refund'},   
     children: [    
              {path: 'list', component: RefundListComponent ,data:{title: 'Refund'}}, 
              {path: '', redirectTo: 'list', pathMatch: 'full'},  
        ],   
     }, 
        
];   

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RefundRoutingModule { }
export const RefundModuleConst = [  
  RefundComponent,  
  RefundListComponent
];