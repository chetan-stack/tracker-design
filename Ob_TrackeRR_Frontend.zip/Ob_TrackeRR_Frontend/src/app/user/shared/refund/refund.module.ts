import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
 
import { SharedModule } from '../shared.module';  
import { RefundModuleConst, RefundRoutingModule } from './refund-routing.module';
import { SentRefundRequestComponent } from './refund-list/sent-refund-request/sent-refund-request.component'; 
import { ViewUserInfoModule } from '../dialog/view-user-info/view-user-info.module';
 

@NgModule({
    declarations: [
        RefundModuleConst,
        SentRefundRequestComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        RefundRoutingModule,
        ViewUserInfoModule
    ]
})
export class RefundModule { }
