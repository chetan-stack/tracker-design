import { NgModule } from '@angular/core';
import { AsyncPipe, CommonModule } from '@angular/common'; 
  
   
/***** Routing & Component *******/
 
  
import { OnboardingModuleConst, OnboardingRoutingModule } from './onboarding-routing.module';  
import { SharedModule } from '../shared.module'; 
import { ResetAgreementTypeComponent } from './dialog/reset-agreement-type/reset-agreement-type.component'; 
import { ViewUserInfoModule } from '../dialog/view-user-info/view-user-info.module';
import { FilePreviewModule } from '../dialog/file-preview/file-preview.module';
import { PaymentConfirmationComponent } from './dialog/payment-confirmation/payment-confirmation.component';
import { EnachSkipRequestModule } from '../dialog/enach-skip-request/enach-skip-request.module';
import { RemarkHistoryModule } from '../dialog/remark-history/remark-history.module';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { DownloadModule } from '../dialog/download/download.module';
import { AgGridModule } from 'ag-grid-angular';
import { DailogManageComponent } from './pages/history/dailog-manage/dailog-manage.component';
import 'ag-grid-enterprise';
import { AggridetableComponent } from './pages/history/aggridetable/aggridetable.component';


@NgModule({
  declarations: [     
    OnboardingModuleConst , 
    ResetAgreementTypeComponent, PaymentConfirmationComponent, DailogManageComponent, AggridetableComponent, 
  ],
  imports: [
    CommonModule,  
    SharedModule, 
    OnboardingRoutingModule,    
    ViewUserInfoModule,
    FilePreviewModule,
    EnachSkipRequestModule,
    RemarkHistoryModule,
    NgxMatSelectSearchModule,
    DownloadModule,
    AgGridModule

  ], 
  providers: [AsyncPipe],
  entryComponents: [ResetAgreementTypeComponent,PaymentConfirmationComponent],
})
export class OnboardingModule {
  constructor( 
   
     ) {
      
    }
 }