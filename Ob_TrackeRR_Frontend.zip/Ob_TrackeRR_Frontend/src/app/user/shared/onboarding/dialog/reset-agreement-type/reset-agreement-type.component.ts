import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-reset-agreement-type',
  templateUrl: './reset-agreement-type.component.html',
  styleUrls: ['./reset-agreement-type.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ResetAgreementTypeComponent implements OnInit {
  Reason_List:any =[]
  toggle_agreementType:boolean = false;
  generateOnBoard:any = {}
  constructor(
    private commonService:CommonService,
    private serviceFactory: ServiceFactory,
    public dialogRef: MatDialogRef<ResetAgreementTypeComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any, 
  ) { 

 
    if(this.dialogData.salestype=='pmp_lt' || this.dialogData.salestype=='dwn_lt'){ 
      this.toggle_agreementType = dialogData.legal_agreement_status=='otp'?true:false  
    }
    else{ 
      this.getLeadSquaredDataByLeadId()
    }

  }

  ngOnInit(): void {
    this.commonService.get('dwOnboarding/getOtpReasonMasterList').subscribe((res:any) => {  
      debugger 
      this.Reason_List = res.data
      
    }) 
    
  }



  switchToggle_agreementType(mode:any){
    this.toggle_agreementType = mode;
    this.onChange_toggle_agreementType(this.toggle_agreementType);
  }
  
  onChange_toggle_agreementType(mode:any){
  
  }

  onSubmit(form_Group:any){
    debugger  
      
    // stop here if form is invalid 
    if (form_Group.invalid) {
        return;
    }
    let formElmValue = form_Group.value

    if(formElmValue.agreement_toggle){
      formElmValue['agreement_type'] = 'otp';
      formElmValue['legal_agreement_status'] = 'otp'
    }else{
      formElmValue['legal_agreement_status'] = 'legal';
      formElmValue['agreement_type'] = 'adhaar' 
    }
    
    formElmValue['salestype'] = this.dialogData.salestype;
    formElmValue['subscriber_lead_no'] = this.dialogData.leadId;
    formElmValue['user_id'] = this.dialogData.user_id;
    formElmValue['ob_customer_id'] = this.dialogData.ob_customer_id;

    let apiUrl = '';
    if(this.dialogData.salestype=='pmp_lt'){
      apiUrl = 'dwLTAgreement/saveUrlAndSendToLtUser';
    }else if(this.dialogData.salestype=='dwn_lt'){
      apiUrl = 'dwLTAgreement/saveUrlAndSendToUser';
    }
    else{
      apiUrl = 'onboarding/changeAgreementType';
    }

    
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

    this.commonService.post(apiUrl,formElmValue).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((data) => {
      debugger 
      this.serviceFactory.notification(data.message,data.status); 
      if(data.status){
        this.dialogRef.close(formElmValue);
      }
    
  }) 


  }


  
  getLeadSquaredDataByLeadId(){
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('onboarding/getLeadSquaredDataByLeadId',{
      leadId:this.dialogData.leadId,
      ob_customer_id:this.dialogData.ob_customer_id,
      salestype:this.dialogData.salestype,
      counsellor_id:this.dialogData.counsellor_id
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => { 
      if(res.status){ 
        let data = res.data;  
        this.generateOnBoard = data; 
        this.toggle_agreementType = data.agreement_type=='otp'?true:false  
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
   }) 
  }

}
