import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service'; 
 

@Component({
  selector: 'app-payment-confirmation',
  templateUrl: './payment-confirmation.component.html',
  styleUrls: ['./payment-confirmation.component.scss']
})
export class PaymentConfirmationComponent implements OnInit {
  getCurrentUser: any ={}; 
  getPaymentType:any=[]; 
  featureImage:any={}; 
  moment = moment;
  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<PaymentConfirmationComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
  ) {
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.loadPaymentType();
  }
  ngOnInit(): void {
  }

  loadPaymentType(){
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.get('sales/getPaymentList').pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => { 
      this.getPaymentType = res.data
    })
  }
  
  paymentDialogclose(SF_form:any){
    debugger
    if (SF_form.invalid) {
      return;
   } 

    let elmForm  = SF_form.value;  

    var formData = new FormData();   
  

    formData.append('payment_method',elmForm.payment_method);
   if(this.featureImage['payment_file']){
    formData.append('payment_file', this.featureImage['payment_file']);
   } 
   formData.append('comment',elmForm.comment);
   formData.append('ref_no',elmForm.ref_no);
   formData.append('first_tranche_date',moment(elmForm.first_tranche_date).format('YYYY-MM-DD'));
  
   formData.append('lead_id',this.AddEditData.lead_id);
   formData.append('customer_id',this.AddEditData.customer_id);
   formData.append('product',this.AddEditData.product); 
   formData.append('sales_type_id',this.AddEditData.sales_type_id); 
   formData.append('counsellor_id',this.AddEditData.counsellor_id);
   formData.append('sale_source_id',this.AddEditData.id);

 

     

 
   this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
   this.commonService.post('autopayment/saveOfflinePayment',formData).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body",""); 
    })
  ).subscribe((res:any) => {
    debugger  
   this.serviceFactory.notification(res.message,res.status); 
   if(res.status){ 
     this.dialogRef.close(res);
   }

 }) 

    
  }


  async handleFileInput(event:any,ngModel:any){  
    debugger  
   let validFile =  await this.serviceFactory.fileFalidation(event.target.files[0],5,['png','jpg','jpeg','pdf']); 
   debugger 
   if(!validFile){
    debugger
    event.target.value = "";
    this.featureImage[ngModel] = undefined; 
   }else{
    this.featureImage[ngModel] = event.target.files[0];
    this.AddEditData[ngModel] = this.featureImage[ngModel].name; 
   } 
  
  }
 
  
}
