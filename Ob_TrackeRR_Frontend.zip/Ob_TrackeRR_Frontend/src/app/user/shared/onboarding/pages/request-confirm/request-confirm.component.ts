import { Component, OnInit, ViewChild } from '@angular/core'; 
import { ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/services/api/common.service';
import { finalize } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
 

// 1:"5 in 5",
// 12:"MPO",
// 3:"Vision",
// 7:"Combo (5in5 + MPO)",      
// 14:"DWN", 
 

@Component({
  selector: 'app-request-confirm',
  templateUrl: './request-confirm.component.html',
  styleUrls: ['./request-confirm.component.scss'], 
  encapsulation: ViewEncapsulation.None,
})
export class RequestConfirmComponent implements OnInit {
  getCurrentUser: any ={};
  moment = moment;  
  product_label:any={};
  product_color:any = {} ;
  
  @ViewChild('salesform') public salesform: NgForm;
   params_LeadId:any;
   generateOnBoard:any = {} 
   storeOldData:any  
   salestype_Params:any;
 

  constructor(
    private commonService: CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    private route: ActivatedRoute,
    private router:Router,
    ) {
      this.getCurrentUser = this.commonService.getCurrentUser();
      let PageTitle = route.snapshot.data['title'];
      this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
      
      this.product_color = this.dataFactory.all_product_color;
      this.product_label = this.dataFactory.all_product_label; 
       
      route.queryParams.subscribe(p => {  
        this.params_LeadId = this.route.snapshot.params['id']; 
        this.salestype_Params = p.salestype; 
        this.fetchLeadDetail();
      });

       
       
     }

  ngOnInit(): void {
     
  }
 
  
 


  fetchLeadDetail() { 
    debugger
  
    
     
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('subscriptionRenewal/getChangedPortfolioDataLeadIdWise',{
      leadId:this.params_LeadId,
      salestype:this.salestype_Params
     }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => { 
      this.serviceFactory.notification(res.message,res.status); 
      
      if(res.status){ 
         let data = res.data;
        
         let justify = JSON.stringify(data);
         this.storeOldData = JSON.parse(justify);
          
         this.generateOnBoard = data; 
      } 
      
    });
   
   
   

  }
 
  ContinueWith(form_Group:any,type:any){
  debugger 
   //form_Group.ngSubmit.markAllAsTouched();
  //form_Group.ngSubmit.emit(true);
  form_Group.submitted = true;
  // stop here if form is invalid 
  if (form_Group.invalid) {
      return;
  }
   let formElmValue = form_Group.value;
   formElmValue['acceptType']=type;
   formElmValue['cs_counsellor_id']=this.getCurrentUser.id;
   formElmValue['salestype']=this.salestype_Params;

    let api="";
    // if(type=="old" || type=="new"){ // retail
    //   api="subscriptionRenewal/submitPortfolio";
    // }else if(type=="request_new"){
    //   api="dwSubscriptionRenewal/portfolioFinalAssignByConsellor_dhanwaan_renewal";
    // }

    // if(type=="old" || type=="new"){
    //   api = "subscriptionRenewal/submitPortfolio"
    // } 
   
    

    // if(type=="Go_Ahead_New" || type=="Continue_Old"){
    //  }
  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('subscriptionRenewal/submitPortfolio',formElmValue).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      debugger 
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.router.navigate(['./portfolio-request'],{  
          relativeTo: this.route.parent
        });  
      }
    
  })   
}
 
 
 

}
