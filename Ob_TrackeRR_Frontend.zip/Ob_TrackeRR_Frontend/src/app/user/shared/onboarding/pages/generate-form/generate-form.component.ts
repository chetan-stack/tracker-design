import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'; 
 import { NgForm } from '@angular/forms';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/services/api/common.service';
import { finalize } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { KeyValue } from '@angular/common';
import Swal from 'sweetalert2';
 

 

@Component({
  selector: 'app-generate-form',
  templateUrl: './generate-form.component.html',
  styleUrls: ['./generate-form.component.scss'],  
})
export class GenerateFormComponent implements OnInit { 
  getCurrentUser:any = {};
  getUserProfile:any = {};
  page_id:string;
  page_counsellor_id:any; 
  salestype_Params:any;
  @ViewChild('salesform') public salesform: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;
  @ViewChild('elm_phone_no') public elm_phone_no: ElementRef;


  getTeamListData:any=[];
 
  lead_Identifier_List:any = {};  
  counsellorListByCenter_List:any = [];
  center_list:any={};
  center_color:any={};

  
  minPaidAmountValidation=10000;  
  generateOnBoard:any = {
    is_complementry:false
  }
 

  ob_product_list:any = { };
  product_color:any= {}
  product_label:any= {}  
  storeOldData:any;  
  
 

  disabledOnfecthLeadDetails = false; 
  ngModel_url:any; 
  ob_customer_id:any;
 
  Reason_List:any = [];
  counsellorList:any =[];
  salesType_list:any = {};
  salesType_id:any = {};

 ComplimentaryService:boolean = true;

 corporateCategoriesList:any =[];
  constructor(
    private commonService: CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    private route:ActivatedRoute,
    private router: Router,
    ) {
       //this.router.routeReuseStrategy.shouldReuseRoute = () => false;
      debugger

      this.getCurrentUser = this.commonService.getCurrentUser();
      this.salesType_list = this.dataFactory.salesType_list; 
      this.salesType_id = this.dataFactory.get_salesType_id;
      let PageTitle = route.snapshot.data['title'];
      this.dataFactory.setPageTitle({PageTitle: PageTitle});
      this.product_label = this.dataFactory.all_product_label;
      this.product_color = this.dataFactory.all_product_color; 

      this.center_list = dataFactory.all_centerList;
      this.center_color = dataFactory.all_centerColor;

      if(this.getCurrentUser.activeRole!="counsellor"){
        this.loadTeamListByParent();
      } 

      this.dataFactory.get_Profile().subscribe((res: any) => {
        this.getUserProfile = res;
     })

     this.dataFactory.get_TeamList().subscribe((res: any) => {
      // debugger
      this.getTeamListData = res;
   })
     
       route.queryParams.subscribe((p:any) => {  
         debugger
        this.salestype_Params = p.salestype; 
        this.page_id = this.route.snapshot.params['id'];
        this.page_counsellor_id = this.route.snapshot.params['counsellor_id']; 
        this.dataFactory.setPageTitle({PageTitle: "Generate URL For "+this.salesType_list[this.salestype_Params]});
         
        this.salesform?.reset();

        this.ngModel_url = undefined;
        this.disabledOnfecthLeadDetails = false; 
        this.ob_customer_id = undefined;
        
        
         if(this.salestype_Params=="retail_new" || this.salestype_Params=="retail_renewal"){
            this.minPaidAmountValidation = 10000;
          }else{
            this.minPaidAmountValidation = 25000;
          }

          if(!this.page_id){ 
            this.serviceFactory.loadingStart("body","Please wait while loading...","");
            setTimeout(()=>{  
              this.serviceFactory.loadingStop("body","");  
             }, 300);
          }
          

           if(this.salestype_Params=="dwn_new" || this.salestype_Params=="dwn_renewal"){
              this.loadCorporateCategories();
           } 

           
      })   
     
  }
  /*************************** */
  onChangeLeadIdentifier(event:any){
     
  }
  onChangeLeadIdentifierOrigin(event:any){ 

  }

  onChangeLeadIdentifierCenter(event:any){
    debugger
     this.loadCounsellorListByCenter(event.value);
  }
  
  loadCounsellorListByCenter(id:any) { 
    this.commonService.post('userProfile/getCounsellorListByCenter',{center_id:id,team_id:this.generateOnBoard['lead_origin_id']}).subscribe((res:any) => {
      this.counsellorListByCenter_List = res.data.sort((a:any, b:any) => a.name.localeCompare(b.name));  
    })
  }
 

  loadLeadIdentifierOrigin() { 
    debugger
    this.serviceFactory.loadingStart(".Identifier_loading","","");
    
    this.commonService.post('onboarding/getLeadOriginListTeamIdentifierWise',{
      team_id:this.getCurrentUser.team_id, 
      sales_type_id:this.salesType_id[this.salestype_Params ],
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop(".Identifier_loading","");
      })
    ).subscribe((res:any) => {
      if(res.status){ 
       let data = res.data;
       let identifier_List:any = {};  
       data?.forEach((elm: any) => { 
         const pushSubArr = {
           lead_origin_name:elm.lead_origin_name,
           lead_origin_id:elm.lead_origin_id
         } 
         if(!identifier_List[elm.identifier_id]){
           identifier_List[elm.identifier_id] = {
              identifier_name:elm.identifier_name,
              identifier_id:elm.identifier_id,
              origin_list:[pushSubArr]
           }
         }else{
           identifier_List[elm.identifier_id].origin_list.push(pushSubArr)
         }
       }); 
       this.lead_Identifier_List = identifier_List; 
      }
     
   })
  }
 

/************************************ */

  loadCorporateCategories() { 
    this.commonService.get('dwOnboarding/getCorporateDocumentType').subscribe((res:any) => {
     this.corporateCategoriesList = res.data; 
    })
  }
  
  loadTeamListByParent() {
    let dataOption:any = { 
     parent_id:this.getCurrentUser.id
    }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
     this.counsellorList = res.data; 
    })
  }

  ngOnInit(): void {
    this.commonService.get('dwOnboarding/getOtpReasonMasterList').subscribe((res:any) => {  
       this.Reason_List = res.data
      
    })   
  }

  ngAfterViewInit(){
    setTimeout(()=>{ 
      debugger   
       

      this.route.queryParams.subscribe(() => {   
          if(this.page_id){ 
            this.salesform.form.controls.subscriber_lead_no.setValue(this.page_id); 
            this.salesform.form.controls.counsellor_id.setValue(Number(this.page_counsellor_id));  

        }else if(!this.page_id && this.getCurrentUser.activeRole=='counsellor'){
           this.salesform.form.controls.counsellor_id.setValue(this.getCurrentUser.id); 
        }
      }
    )


        
     }, 50);

     setTimeout(()=>{ 
      debugger                    
        if(this.page_id){ 
             this.fetchLeadDetail();
        }
     }, 100);
    
   
  } 
 

  fetchLeadDetail() { 
    debugger
    let FormCTR = this.salesform.form.controls;  
    //FormCTR.subscriber_lead_no.setErrors(null);
    
    if(this.getCurrentUser.activeRole=='manager' && FormCTR.counsellor_id.invalid){ 
     this.serviceFactory.notification("Please Select the Counsellor.",false);
     return false
    } 


    if(FormCTR.subscriber_lead_no.invalid){
      this.elm_lead_no.nativeElement.focus()
     return false
    }  
    
 
  

    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('onboarding/getLeadSquaredDataByLeadId',{
      leadId:FormCTR.subscriber_lead_no.value,
      salestype:this.salestype_Params,
      counsellor_id:FormCTR.counsellor_id.value?FormCTR.counsellor_id.value:null
     }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      if(res.status){ 
        FormCTR.subscriber_lead_no.setErrors(null);
        let data = res.data;
        
         let justify = JSON.stringify(data);
         this.storeOldData = JSON.parse(justify); 
         
        data['counsellor_id'] = FormCTR.counsellor_id.value; 
        data['salestype'] = this.salestype_Params; 
        data['tenure_extended'] = data['tenure_extended']?data['tenure_extended']:false;
        data['agreement_type'] = data['agreement_type']?data['agreement_type']:'adhaar';
        data['user_type'] = data['user_type']?data['user_type']:'individual'; 
        data['product'] = data['product']?JSON.stringify(data['product']):null;

        data['duration'] = data['duration']?data['duration']:1;
        data['informed_investor_subscribed'] = true;  
        data['informed_investor_amount'] = 0;  


       // data['gst'] = this.getGST(data['amount']); 
       // data['total_subscription_amount'] = Number((data['amount'])+Number(data['gst']));

         
        if(this.salestype_Params=='retail_renewal' || this.salestype_Params=='dwn_renewal'){
         
          if(data['is_complementry']===null || data['is_complementry']===undefined){
            data['is_complementry'] = false
          }else{
            data['is_complementry'] = data['is_complementry'];
          }
          
         }
         
         if(data.customers_lead_origin_dtl){
          Object.assign(data, data.customers_lead_origin_dtl);
          delete data.customers_lead_origin_dtl; 
 
          // if(data['identifier_id']==3){
          //   const dwnCheck_Expired = [16,8];
            
          //   if(dwnCheck_Expired.includes(data.lead_origin_id)){
          //     data['lead_origin_id'] = 'Expired_To_Dhanwaan';
          //     if(data['lead_origin_id']==16){ 
          //       data['is_pmp_service'] = true;
          //     }else{
          //       data['is_pmp_service'] = false;
          //     }
          //   }
            
          //   if(data['lead_origin_id']==7 && data['is_pmp_service']){
          //     data['lead_origin_id'] = 4
          //   } 
          // }

          

        }

         this.generateOnBoard = data;

          
         if(data.current_status>4){
          this.disabledOnfecthLeadDetails = true;            
         }else{
          this.disabledOnfecthLeadDetails = false;  
         } 

         if(data.onboarding_url){
          this.ob_customer_id = data.ob_customer_id;
           let tag = this.dataFactory.salesType_ob_url[this.salestype_Params];
           if(tag!=''){
            this.ngModel_url = environment.onboarding_host+tag+"?uid="+data.onboarding_url;  
           }else{
            this.ngModel_url = environment.onboarding_host+tag+"?uid="+data.onboarding_url; 
           }
                    
         } 
    
         this.bindExistingProductShow() ; 
         this.loadLeadIdentifierOrigin();
         
         if(data.lead_origin_center_id){
          this.loadCounsellorListByCenter(data.lead_origin_center_id);
         }

        
         
         
         
         setTimeout(()=>{                     
          this.elm_phone_no.nativeElement.focus()
         }, 500); 
        
         setTimeout(()=>{  
          this.elm_phone_no.nativeElement.blur()
         }, 550);


         if(data.shared_status){
          this.checkIf_Confirm('This lead has been already shared. Please confirm if you still want to proceed. Lead Sharing will not be considered after proceeding.')
         }

         if(data.subscription_exp_cust && this.getCurrentUser.center_id!=5){
          this.checkIf_Confirm('You are renewing to the expired clients, hence complimentary service is not applicable on it.')
         }


      }else{
        this.serviceFactory.notification(res.message,res.status);  
        //FormCTR.subscriber_lead_no.setErrors({'incorrect': true});
       
        this.elm_lead_no.nativeElement.focus();        
        this.ngModel_url = undefined;
        this.generateOnBoard = {
          leadId:FormCTR.subscriber_lead_no.value,
          counsellor_id:FormCTR.counsellor_id.value?FormCTR.counsellor_id.value:null,
          salestype:this.salestype_Params,
          is_complementry:false
           
        };
        
        this.disabledOnfecthLeadDetails = false; 
        
      }
      
    });
   
   
   

  }

  checkIf_Confirm(msg:any){ 
      Swal.fire({ 
        title: 'Confirm!',
        html: msg,
        icon: 'warning', 
     customClass: {
       confirmButton: 'mat-flat-button mat-button-base mat-primary',
       cancelButton: 'mat-stroked-button mat-button-base ',
       container: 'modal-yes-no Modal_Delete', 
       actions: 'modal-btn-yes-no mb-4',
       //  header: 'pt-4', 
     },
     //width: '36em',
     showCloseButton: true,
     buttonsStyling: false,
     showCancelButton: true,
     confirmButtonText: 'Confirm',
     cancelButtonText: 'Cancel' , 
     focusConfirm:false, 
     focusCancel:true,     
    }).then((result:any) => {
      debugger
       if (result.isConfirmed) {
      
       }else{
        let FormCTR = this.salesform.form.controls; 
          
        FormCTR.subscriber_lead_no.setErrors({'incorrect': true});
        this.elm_lead_no.nativeElement.focus();        
        this.ngModel_url = undefined;
        this.generateOnBoard = {
          leadId:FormCTR.subscriber_lead_no.value,
          counsellor_id:FormCTR.counsellor_id.value?FormCTR.counsellor_id.value:null,
          salestype:this.salestype_Params, 
        };
        this.disabledOnfecthLeadDetails = false; 
         
       }
      })
    
  }

  hasErrorPhone(name:any,hasAction:any){ 
    debugger
    if(!hasAction){
      this.salesform.form.controls[name].setErrors({'incorrect': true});
    }else{
      this.salesform.form.controls[name].setErrors(null);
    } 
 }

 onSubmit(form_Group:any){
  debugger 
    
  // stop here if form is invalid 
  if (form_Group.invalid) {
      return;
  }
   let formElmValue = form_Group.value;
    if(!Array.isArray(formElmValue['product'])){
       formElmValue['product'] = JSON.parse(formElmValue['product']);
    }
 
    if(this.getCurrentUser.activeRole=="manager"){  // When manager approve SalesForm with update data 
      formElmValue["manager_id"] = this.getCurrentUser.id; 
    } 
    formElmValue["salestype"] = this.salestype_Params;


   formElmValue['dataChanged'] =  {mobile:false,email:false};

   let removeHyphen = formElmValue.phone_no.split('-')[1];
    if(!this.storeOldData.Phone.includes(removeHyphen)){
      formElmValue.dataChanged.mobile =  true
    }  
    
    if(!this.storeOldData.EmailAddress.includes(formElmValue.email)){
      formElmValue.dataChanged.email =  true
    }
    
    if(!formElmValue['otp_reason_id']){
      formElmValue['agreement_type'] = "adhaar" 
    }

    if(!formElmValue['total_amount']){
      formElmValue['total_amount'] = formElmValue['amount']
    }

  
    // if(formElmValue['identifier_id']==3){
    //   if(formElmValue['lead_origin_id']=="Expired_To_Dhanwaan"){
    //     formElmValue['lead_origin_id'] = formElmValue['is_pmp_service']?16:8
    //   }
    //   if(formElmValue['lead_origin_id']==4 && formElmValue['is_pmp_service']){
    //     formElmValue['lead_origin_id'] = 7
    //   } 
    // }

    
 
   

    
    if(formElmValue.dataChanged.mobile==true || formElmValue.dataChanged.email==true){
      Swal.fire({ 
        title: 'Attention!',
        html: 'Since you are going to change customers contact details so customer has to verify his details again.',
        icon: 'warning', 
     customClass: {
       confirmButton: 'mat-flat-button mat-button-base mat-primary',
       cancelButton: 'mat-stroked-button mat-button-base ',
       container: 'modal-yes-no Modal_Delete', 
       actions: 'modal-btn-yes-no mb-4',
       //  header: 'pt-4', 
     },
     //width: '36em',
     showCloseButton: true,
     buttonsStyling: false,
     showCancelButton: true,
     confirmButtonText: 'Confirm',
     cancelButtonText: 'Cancel' , 
     focusConfirm:false, 
     focusCancel:true,     
    }).then((result:any) => {
      debugger
       if (result.isConfirmed) {
        this.saveUserDtl(formElmValue); 
       }
      })
    }else{
      this.saveUserDtl(formElmValue); 
    }
   
    
}





saveUserDtl(formElmValue:any){

  if(this.generateOnBoard.shared_status){ 
      formElmValue['lead_shared_id'] = this.generateOnBoard.lead_shared_id;
   }

   

  this.serviceFactory.loadingStart("body","Please wait while loading...","");
  this.commonService.post('onboarding/saveUserDtl',formElmValue).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res:any) => {  
    debugger 
    this.serviceFactory.notification(res.message,res.status); 
    if(res.status){
    //  this.fetchLeadDetail();
        this.ob_customer_id = res.data.ob_customer_id;
        let tag = this.dataFactory.salesType_ob_url[this.salestype_Params];
         if(tag!=''){ 
          this.ngModel_url = environment.onboarding_host+tag+"?uid="+res.data.onboarding_url;  
         }else{
          this.ngModel_url = environment.onboarding_host+tag+"?uid="+res.data.onboarding_url; 
         }  
    }
  
})  
}
 
copyUrl(form_Group:any,element:any){
  debugger
   if (form_Group.invalid) {
    return;
   }
   element.select();
   element.setSelectionRange(0, 99999)
   document.execCommand("copy");
   this.serviceFactory.notification("URL Copied.",true);
   
}

onSendUrl(form_Group:any){
  debugger  
  // if (this.salesform.invalid) {
  //   let control = this.salesform.form.controls.subscriber_lead_no; 
  //   if(control.value=="" || control.value==null){
  //    subscriber_lead_no.focus()
  //    return false
  //  }
  //   return;
  // } 
  if (form_Group.invalid) {
      return;
  }
   let subscriber_lead_no = this.salesform.form.controls.subscriber_lead_no.value;
   //let salestype = this.salesform.form.controls.salestype.value;
   this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('onboarding/sendUrlToUser',{
      ob_customer_id:this.ob_customer_id,
      leadId:subscriber_lead_no,
      salestype:this.salestype_Params
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((data) => {  
      debugger 
      this.serviceFactory.notification(data.message,data.status); 
      if(data.status){
        
      }
    
  })   
}

doSomething() {
  debugger
  if (this.generateOnBoard['duration'] == 1) { 
    this.generateOnBoard['total_amount'] = parseInt(this.generateOnBoard['amount'])*2;
  } else {
    debugger
    this.generateOnBoard['total_amount'] = parseInt(this.generateOnBoard['amount'])*10;
  }
if(this.generateOnBoard['tenure_extended']==true){
  this.generateOnBoard['tenure_extended']=false
}

}
 
bindPaidAmountValidation(){
  debugger
 
  if(this.salestype_Params=="retail_new" || this.salestype_Params=="retail_renewal"){
    this.minPaidAmountValidation = 10000;
  }else{
    let prd = this.generateOnBoard['product'];
    let iva = Number(this.generateOnBoard['investment_amount']);
    this.generateOnBoard['amount'] = undefined;
    
    if(iva && prd=='[14]'){
      if(iva>=25 && iva<=40){
        this.minPaidAmountValidation = 25000;
       // control_investment_amount.setErrors(null);  
      }else if(iva>=50 && iva<=100){
        this.minPaidAmountValidation = 40000; 
       // control_investment_amount.setErrors(null);
      }else{     
        //control_investment_amount.setErrors({'incorrect': true});
      }
      
    }else if(iva && prd=='[14,12]'){
      if(iva>=25 && iva<=40){
        this.minPaidAmountValidation = 40000;  
        //control_investment_amount.setErrors(null);  
      }else if(iva>=50 && iva<=100){
        this.minPaidAmountValidation = 55000; 
       // control_investment_amount.setErrors(null);
      }else{     
        //control_investment_amount.setErrors({'incorrect': true});
      }
      
    }
    else if(iva && prd=='[12]'){
      this.minPaidAmountValidation = 10000;    
    }else{
      this.minPaidAmountValidation = 25000;
    }
  }


 
 
}
 
 
bindExistingProductShow(){
  //debugger 
  if(this.salestype_Params=="retail_new" || this.salestype_Params=="retail_renewal"){
      this.ob_product_list ={
        '[1]':'5in5 ',
        '[12]':'MPO',
        '[1,12]':'Combo (5in5 + MPO)',
        }
  }else if(this.salestype_Params=="dwn_renewal"){
    this.ob_product_list = {
      '[14]':'DWN',
      '[14,12]':'DWN + MPO',
    }
  }
  else{
    let exp = this.generateOnBoard['existing_products'];
    if(exp.includes(12) && !exp.includes(14)){
      this.ob_product_list ={
        '[14]':'DWN'
       }  
     }else if(!exp.includes(12) && !exp.includes(14)){
      this.ob_product_list ={
        '[14]':'DWN',
        '[14,12]':'DWN + MPO',
       }  
     }else if(exp.includes(12) && exp.includes(14)){
      this.ob_product_list ={
        
       }  
     }else{
      this.ob_product_list ={
        '[14]':'DWN',
        '[14,12]':'DWN + MPO',
       } 
     }
  }

 
 
}



onChangeDuration(event:any){
  debugger
  if(event.value===5){
    this.generateOnBoard['tenure_extended'] = false
  }
  this.doSomething()
  
 // return ""
}

jsonP(data:any){
  return data?JSON.parse(data):[] 
   
 
}

jsonS(data:any){
  return data?JSON.stringify(data):{}    

}

getGST(val: any){
  //debugger
   var get_GST = (Number(val) * 18)/100;
   return Number(get_GST.toFixed())
}

showAgreement_type(){
  //debugger
  let phone;
  if(this.salesform && this.salesform.form.controls.phone_no?.value){
    phone = this.salesform.form.controls.phone_no.value;
  }

  if(phone && phone.includes("+91")){
    return false
  }else if(phone && !phone.includes("+91")){
    return true
  }else{
    return false
  }
   
  
 
}

 // Preserve original property order
originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
  return 0;
}
getNumber(val:any){
 return Number(val);
}

getEventVal(event:any){
  debugger
   return event.target.value
}
onRMToggleChange(){
  
}
}