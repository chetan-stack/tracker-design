import { Component, OnInit } from '@angular/core';
import { GridOptions, IDatasource, IGetRowsParams } from 'ag-grid-community';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { DailogManageComponent } from '../dailog-manage/dailog-manage.component';


@Component({
  selector: 'app-aggridetable',
  templateUrl: './aggridetable.component.html',
  styleUrls: ['./aggridetable.component.scss']
})
export class AggridetableComponent implements OnInit {

  gridOptions: Partial<GridOptions>;
  gridApi:any;
  gridColumnApi:any;
 columnDefs:any;
  cacheOverflowSize:any;
  maxConcurrentDatasourceRequests:any;
  infiniteInitialRowCount:any;
  rowData:any

 constructor(
   private serviceFactory: ServiceFactory,
   private commonService: CommonService,  
   private dataFactory: DataFactoryService,
   ) {

 this.columnDefs =[
   {headerName: 'S No.', field: 'selfIndex',width:70},
   {headerName: 'Customer Name', field: 'customer_full_name',filter: "agSetColumnFilter",
   cellRenderer:DailogManageComponent,cellRendererParams:{typeSend:'customer_name'}},
   {headerName: 'Lead No.', field: 'lead_id',filter:true},
   {headerName: 'Counsellor Name', field: 'counsellor_name',filter:'agSetColumnFilter',
   filterParams: {
     values: (params:any) => {
         // async update simulated using setTimeout()
       let array =Object.keys(this.dataFactory.all_product_label) 
         console.log("param------",params,array)
         setTimeout(function () {
           params.success([51, 45]);
         }, 1000);
     }
 }},
 
   {headerName: 'Sent Date', field: 'sent_date',filter:'agDateColumnFilter',filterParams:{values:''}},
   {headerName: 'Product', field: 'product',filter:'agSetColumnFilter',
   cellRenderer:(param:any) => {
    if(param['data'] != undefined){
      // console.log("check--------",param['data'].product)

      let key = param['data']['product'].toString()
      return`
      <span class="badge ProductColor">${key == "1"?'5in5':key=="12"?'MPO':''}</span>
      <span class="badge ProductColor">${key == "1,12"?'combo(5in5 & MPO)':''}</span>
      `;
    }
   
    
  },
   filterParams: {
    values: (params:any) => {
      setTimeout(function () {
        params.success(["1", "12", "1,12"]);
      }, 1000);
  }   
}

 },
   {headerName: 'Amount', field: 'amount',filter:true},
   {headerName: 'Agreement Type', field: 'agreement_type',filter:'agSetColumnFilter',
   filterParams: {
    values: (params:any) => {
      setTimeout(function () {
        params.success(["adhaar", "otp"]);
      }, 1000);
  }   
}
  },
   {headerName: 'Status', field: 'status',filter:'agSetColumnFilter',
   filterParams: {
    values: (params:any) => {
      setTimeout(function () {
        params.success([3, 4, 5, 6, 1, 7, 8]);
      }, 1000);
  }
}
   },
   {headerName: 'e-Nach Status', field: 'enach_status',filter:'agSetColumnFilter',
   cellRenderer:DailogManageComponent,
   cellRendererParams: {
     typeSend:'enash'
   }},
   {headerName: 'Actions', field: '1',filter:true,pinned:'right',width:100,cellRenderer:DailogManageComponent,cellRendererParams: {
    typeSend:'menuDailog'
  }}
 
 ];


   this.cacheOverflowSize = 2;
   this.maxConcurrentDatasourceRequests = 2;
   this.infiniteInitialRowCount = 2;

   this.gridOptions = {
     headerHeight: 45,
     rowHeight: 30,
     cacheBlockSize: 20,
     paginationPageSize: 20,
     rowModelType: 'infinite',
   }
 }



 resultparam(params:any){

  if(Object.keys(params.filterModel).length !== 0){
    if(params.filterModel['counsellor_name']['values']){
      return params.filterModel['counsellor_name']['values']
    }
   if(params.filterModel['product']['values']){
    return params.filterModel['product']['values']
    }
    else{
      return []
    }
  }
  else{
    return []
  }
 }

 onPageSizeChanged() {
  var value = (document.getElementById('page-size') as HTMLInputElement)
    .value;
  this.gridApi.paginationSetPageSize(Number(value));
}

 onGridReady(params:any) {
   console.log('On Grid Ready');

   this.gridApi = params.api;
   this.gridColumnApi = params.columnApi;
  console.log("grid api",this.gridApi['paginationProxy'].currentPage)
   var datasource = {
     getRows: (params: IGetRowsParams) => {
       debugger
       const para = {
         page: this.gridApi['paginationProxy'].currentPage + 1,
         perpage: 20,
         salestype: "retail_new",
         agreement_type:params.filterModel['agreement_type'] == undefined?[]:params.filterModel['agreement_type']['values'],
         counsellors:params.filterModel['counsellor_name'] == undefined?[]:params.filterModel['counsellor_name']['values'],
         end_date:params.filterModel['sent_date'] == undefined?'':params.filterModel['sent_date']['dateTo'].replace(' 00:00:00', ''),
         product:params.filterModel['product'] == undefined?[]:params.filterModel['product']['values'],
         search:'',
         short_order:'',
         start_date:params.filterModel['sent_date'] == undefined?'':params.filterModel['sent_date']['dateFrom'].replace(' 00:00:00', ''),
         status:params.filterModel['status'] == undefined?[]:params.filterModel['status']['values']
       }
       this.commonService.post('onboarding/getObUsersHistory',para)
       .subscribe((data:any) => {
        data.data.dataobject.forEach((ele:any,i:any) => {
          data.data.dataobject[i].selfIndex = i+1
        });

        params.successCallback(data.data.dataobject, data.data.count) 

         } )
         
     }
   }

   this.gridApi.setDatasource(datasource);
 }
 

 onPaginationChanged() {

 }

 ngOnInit(): void {
 }


}
