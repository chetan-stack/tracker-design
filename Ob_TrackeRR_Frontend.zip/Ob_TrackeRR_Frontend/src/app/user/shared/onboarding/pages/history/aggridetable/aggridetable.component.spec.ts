import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AggridetableComponent } from './aggridetable.component';

describe('AggridetableComponent', () => {
  let component: AggridetableComponent;
  let fixture: ComponentFixture<AggridetableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AggridetableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AggridetableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
