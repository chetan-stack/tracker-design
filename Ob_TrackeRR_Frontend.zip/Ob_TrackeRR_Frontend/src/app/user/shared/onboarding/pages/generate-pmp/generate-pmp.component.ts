import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core'; 
 import { NgForm } from '@angular/forms';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/services/api/common.service';
import { finalize } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { KeyValue } from '@angular/common';
import Swal from 'sweetalert2';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import * as moment from 'moment';
import { MatDialog } from '@angular/material/dialog';
import { ResetAgreementTypeComponent } from '../../dialog/reset-agreement-type/reset-agreement-type.component';
import { DomSanitizer } from '@angular/platform-browser';
  
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

 

@Component({
  selector: 'app-generate-pmp',
  templateUrl: './generate-pmp.component.html',
  styleUrls: ['./generate-pmp.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
   // {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}},
   
    
  ],
}) 
export class GeneratePmpComponent implements OnInit {
  getCurrentUser:any = {};
  getUserProfile:any = {};
  page_id:string;
  page_counsellor_id:any; 
  salestype_Params:any;
  moment = moment;
  @ViewChild('salesform') public salesform: NgForm;
  @ViewChild('elm_email_id') public elm_email_id: ElementRef;
  @ViewChild('elm_phone_no') public elm_phone_no: ElementRef;
  
  
  generateOnBoard:any = {
    product_price_details:{},
    savedData:{
      base_detail:{}
    }
  }
 

  ob_product_list:any = { };
  product_color:any= {}
  product_label:any= {}  
  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}
  
  storeOldData:any;  
  
 

  disabledLeadSource:any = false; 
  ngModel_url:any; 

 
  Reason_List:any = [];
  counsellorList:any =[];
  salesType_list:any = {};
  salesType_id:any = {};

 ComplimentaryService:boolean = true;

 numberTranchesList:any = {};

 addMonthsinTranchList:any = {
  alternateMonth:2,
  monthly:1,
  quarterly:3, 
  halfYearly:6
}

getTeamListData:any=[];
lead_Identifier_List:any = [];
lead_Identifier_Origin_List:any = [];
counsellorListByCenter_List:any = [];
center_list:any={}; 
center_color:any={};

 Arr = Array;
 getPaymentType:any=[];
 @ViewChild('IframePreviewAgreementTemplate') IframePreviewAgreementTemplate: TemplateRef<any>; 
 IframePreviewAgreementDialogRef:any;

  constructor(
    private commonService: CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    private route:ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    public domSanitizer:DomSanitizer
    ) {
       //this.router.routeReuseStrategy.shouldReuseRoute = () => false;
      debugger

      this.getCurrentUser = this.commonService.getCurrentUser();
      this.salesType_list = this.dataFactory.salesType_list; 
      this.salesType_id = this.dataFactory.get_salesType_id;

      let PageTitle = route.snapshot.data['title'];
      this.dataFactory.setPageTitle({PageTitle: PageTitle});
      this.product_label = this.dataFactory.all_product_label;
      this.product_color = this.dataFactory.all_product_color;  

      this.Status_Name = this.dataFactory.All_Status_Name;
      this.Status_Color = this.dataFactory.All_Status_Color;
      this.Status_Icon = this.dataFactory.All_Status_Icon;  

      this.center_list = dataFactory.all_centerList;
      this.center_color = dataFactory.all_centerColor;

      if(this.getCurrentUser.activeRole!="counsellor"){
        this.loadTeamListByParent();
      } 

      this.dataFactory.get_Profile().subscribe((res: any) => {
        this.getUserProfile = res;
     })

     this.dataFactory.get_TeamList().subscribe((res: any) => {
      // debugger
      this.getTeamListData = res;
   })


       route.queryParams.subscribe((p:any) => {  
         debugger
        this.salestype_Params = p.salestype; 
        this.page_id = this.route.snapshot.params['id'];
        this.page_counsellor_id = this.route.snapshot.params['counsellor_id']; 
        this.dataFactory.setPageTitle({PageTitle: "Generate URL For "+this.salesType_list[this.salestype_Params]});
        this.salesform?.reset(); 
        this.ngModel_url = undefined; 

          if(!this.page_id){ 
            this.serviceFactory.loadingStart("body","Please wait while loading...","");
          }
          setTimeout(()=>{  
            this.serviceFactory.loadingStop("body","");  
           }, 300);

 
           if(this.salestype_Params=='pmp_lt'){ 
                this.numberTranchesList = {
                  alternateMonth:9,
                  monthly:18,
                  quarterly:6, 
                  halfYearly:3
                };
           }else if(this.salestype_Params=='dwn_lt'){ 
                this.numberTranchesList = {
                  alternateMonth:18,
                  monthly:36,
                  quarterly:12, 
                  halfYearly:6
                };
           }else{
           }
      })   
     
      this.loadPaymentType();
  }



 /*************************** */
 onChangeLeadIdentifier(event:any){
     
}
onChangeLeadIdentifierOrigin(event:any){ 

}

onChangeLeadIdentifierCenter(event:any){
  debugger
   this.loadCounsellorListByCenter(event.value);
}

loadCounsellorListByCenter(id:any) { 
  this.commonService.post('userProfile/getCounsellorListByCenter',{center_id:id,team_id:this.generateOnBoard['lead_origin_id']}).subscribe((res:any) => {
    this.counsellorListByCenter_List = res.data.sort((a:any, b:any) => a.name.localeCompare(b.name));  
  })
}


loadLeadIdentifierOrigin() { 
  this.commonService.post('onboarding/getLeadOriginListTeamIdentifierWise',{
    team_id:this.getCurrentUser.team_id, 
    sales_type_id:this.salesType_id[this.salestype_Params ], 
  }).subscribe((res:any) => {
    if(res.status){ 
     let data = res.data;
     let identifier_List:any = {};  
     data.forEach((elm: any) => { 
       const pushSubArr = {
         lead_origin_name:elm.lead_origin_name,
         lead_origin_id:elm.lead_origin_id
       } 
       if(!identifier_List[elm.identifier_id]){
         identifier_List[elm.identifier_id] = {
            identifier_name:elm.identifier_name,
            identifier_id:elm.identifier_id,
            origin_list:[pushSubArr]
         }
       }else{
         identifier_List[elm.identifier_id].origin_list.push(pushSubArr)
       }
     }); 
     this.lead_Identifier_List = identifier_List; 
    }
   
 })
}


/************************************ */

  
  loadPaymentType(){
    this.commonService.get('sales/getPaymentList').subscribe((res:any) => { 
      this.getPaymentType = res.data
    })
  }

  loadTeamListByParent() {
    let dataOption:any = { 
     parent_id:this.getCurrentUser.id
    }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
     this.counsellorList = res.data; 
    })
  }

  ngOnInit(): void {
    this.commonService.get('dwOnboarding/getOtpReasonMasterList').subscribe((res:any) => {  
       this.Reason_List = res.data
      
    })   
  }

  ngAfterViewInit(){
    setTimeout(()=>{ 
      debugger   
       

      this.route.queryParams.subscribe(() => {   
          if(this.page_id){ 
            this.salesform.form.controls.email.setValue(this.page_id); 
            this.salesform.form.controls.counsellor_id.setValue(Number(this.page_counsellor_id));  

        }else if(!this.page_id && this.getCurrentUser.activeRole=='counsellor'){
           this.salesform.form.controls.counsellor_id.setValue(this.getCurrentUser.id); 
        }
      }
    )


        
     }, 50);

     setTimeout(()=>{ 
      debugger                    
        if(this.page_id){ 
             this.fetchLeadDetail();
        }
     }, 100);
    
   
  } 
 

  fetchLeadDetail() { 
    debugger
    let FormCTR = this.salesform.form.controls;  
    //FormCTR.email.setErrors(null);
    

    if(this.getCurrentUser.activeRole=='manager' && FormCTR.counsellor_id.invalid){ 
      this.serviceFactory.notification("Please Select the Counsellor.",false);
      return false
     } 

    if(FormCTR.email.invalid){
      this.elm_email_id.nativeElement.focus()
     return false
    }  
     
  

    let apiUrl = '';
    if(this.salestype_Params=='pmp_lt'){
      apiUrl = 'dwLTAgreement/fetchltcustomerdetail';
    }else if(this.salestype_Params=='dwn_lt'){
      apiUrl = 'dwLTAgreement/fetchcustomerdetail';
    }else{
    }


    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

    this.commonService.post(apiUrl,{
      email:FormCTR.email.value,
      salestype:this.salestype_Params,
      counsellorId:FormCTR.counsellor_id.value?FormCTR.counsellor_id.value:null
     }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      if(res.status){ 
        FormCTR.email.setErrors(null);
        let data = res.data;
        
        if(!data.customers_lead_origin_dtl){
          this.serviceFactory.msgPop('Lead source is not updated for this customer, please contact to Tech Team.','error');
           return;   
        } 

         let justify = JSON.stringify(data);
         this.storeOldData = JSON.parse(justify); 
         
          data['counsellor_id'] = FormCTR.counsellor_id.value; 
          data['salestype'] = this.salestype_Params; 


        if(!data.agreement_signed_date){ 
          this.masterAgreementNot_Signed(data);
          return ;   
         }


          if(!data.savedData || !data.savedData.base_detail || !data.savedData.base_detail.payment_type){
            data['savedData']['base_detail']['payment_type'] = 'full';  
          }
          
           if(!data.savedData || !data.savedData.base_detail || !data.savedData.base_detail.legal_agreement_status){
            data['savedData']['base_detail']['legal_agreement_status'] = 'legal'; 
           } 

           if(data.savedData && data.savedData.base_detail && data.savedData.base_detail['user_type']=='coorporate'){
            data.savedData.base_detail['user_type']==true; 
           }else{
            data['savedData']['base_detail']['user_type'] = false;
           }

           if(data.savedData && data.savedData.base_detail && data.savedData.base_detail.first_tanch_date){
            data.savedData.base_detail.first_tanch_date = moment(data.savedData.base_detail.first_tanch_date);
           }  

         

         if(data.esign_sent_url){
          let tag = this.dataFactory.salesType_ob_url[this.salestype_Params];
          if(tag!=''){
           this.ngModel_url = environment.onboarding_host+tag+"?uid="+data.esign_sent_url;  
          }else{
           this.ngModel_url = environment.onboarding_host+tag+"?uid="+data.esign_sent_url; 
          }
                   
        } 

 
        if(data.customers_lead_origin_dtl){
          Object.assign(data, data.customers_lead_origin_dtl);
          delete data.customers_lead_origin_dtl; 
        }


        this.loadLeadIdentifierOrigin(); 
        if(data.lead_origin_center_id){
         this.loadCounsellorListByCenter(data.lead_origin_center_id);
        }
         
        if(data['is_pmp_service'] !=null){
          this.disabledLeadSource = true
        }
       
         
       this.generateOnBoard = data;     

      }else{
        this.serviceFactory.notification(res.message,res.status);  
        FormCTR.email.setErrors({'incorrect': true});
        this.elm_email_id.nativeElement.focus();        
        this.ngModel_url = undefined;
        this.generateOnBoard = {
          leadId:FormCTR.email.value,
          counsellor_id:FormCTR.counsellor_id.value?FormCTR.counsellor_id.value:null,
          salestype:this.salestype_Params,
           
        };
        this.storeOldData = undefined;  
        
      }
      
    });
   
   
   

  }

  onSaveForm(form_Group:any){
    debugger 
    Swal.fire({ 
      title: 'Agreement Not Signed!',
      html: 'Customer has not signed Master Agreement, Please click on Send Master Service Agreement to customer.',
      icon: 'error', 
   customClass: {
     confirmButton: 'mat-flat-button mat-button-base mat-primary',
     cancelButton: 'mat-stroked-button mat-button-base ',
     container: 'modal-yes-no Modal_Delete', 
     actions: 'modal-btn-yes-no mb-4',
     //  header: 'pt-4', 
   },
   width: '36em',
   showCloseButton: true,
   buttonsStyling: false,
   showCancelButton: true,
   confirmButtonText: 'Send Master Link',
   cancelButtonText: 'Cancel' , 
   focusConfirm:false, 
   focusCancel:true,     
  }).then((result:any) => {
    debugger
     if (result.isConfirmed) {
   
     }
   })

  }

 async onSubmit(form_Group:any){
  debugger 
    
  // stop here if form is invalid 
  if (form_Group.invalid) {
      return;
  }
   let formElmValue = form_Group.value;

   let get_client_ip = await fetch('https://api64.ipify.org/?format=json').then(response => response.json())
   .then(result => {    
     return result.ip
   })
   .catch(error => {
     return "0.0.0.0"
   });
 
   
  if(formElmValue.non_adv_installment){ 
    let non_ad:any = []
    Object.entries(formElmValue.non_adv_installment).forEach(([key, value]:any) =>{
       value['schedule_date'] = moment(value['schedule_date']).format('YYYY-MM-DD');
       non_ad.push(value);
   })
     

 let firstTranchDate_plusMonths:any = moment(non_ad[0].schedule_date).add(this.numberTranchesList.monthly, 'M'); 
 let lastTranchDate_date:any = moment(non_ad[non_ad.length - 1].schedule_date);

 
 if(Date.parse(firstTranchDate_plusMonths) <  Date.parse(lastTranchDate_date)){
    this.serviceFactory.msgPop('Difference between first and last tranche date should not be more than '+this.numberTranchesList.monthly+' Months.','error');
   // return false;   
 } 

 formElmValue['non_adv_installment'] = non_ad;

  }

  if(formElmValue['adv_installment']){ 
    let ad:any = []
    let arr = formElmValue.adv_installment;


 


    for (var k in arr) {
      let value = arr[k];
      value['schedule_date'] = moment(value['schedule_date']).format('YYYY-MM-DD'); 
      let mom = moment;
      if(this.salestype_Params=='pmp_lt' && k!='0' && mom(value['schedule_date']).isSameOrBefore(moment().add(9, 'days'))){
        this.serviceFactory.notification('Kindly change the date of 2nd advisory, we cannot get sign the eNach for this date.',false);
       // return
      }
      ad.push(value);
      
    }  
   formElmValue['adv_installment'] = ad;
  }



   formElmValue["first_tanch_date"] = moment(formElmValue["first_tanch_date"]).format('YYYY-MM-DD'); 
   formElmValue["dob"] = moment(new Date(formElmValue["dob"])).format('YYYY-MM-DD'); 
   formElmValue['down_payment_status'] = 0;
   formElmValue['discount_amount'] = 0;
   formElmValue['down_payment'] = null; 
    formElmValue['sale_value'] = null; 
    formElmValue['adv_discount'] = null; 
    formElmValue['adv_adjust_amount'] = null; 
    formElmValue['discount_amount'] = null; 
    formElmValue['adv_total_amount_to_be_paid'] = null;
    formElmValue['tranche_price'] = null;
   formElmValue['lt_type'] = 'membership';
   formElmValue['ip'] = get_client_ip;
   formElmValue['user_type'] = formElmValue['user_type']?'coorporate':'individual';


    if(this.getCurrentUser.activeRole=="manager"){  // When manager approve SalesForm with update data 
      formElmValue["manager_id"] = this.getCurrentUser.id; 
    } 
 

  this.saveUserDtl(formElmValue)
  
    
}





saveUserDtl(formElmValue:any){

 debugger
   
 let apiUrl = '';
 if(this.salestype_Params=='pmp_lt'){
   apiUrl = 'dwLTAgreement/ltagreementstore';
 }else if(this.salestype_Params=='dwn_lt'){
   apiUrl = 'dwLTAgreement/agreementstore';
 }else{
 }

  this.serviceFactory.loadingStart("body","Please wait while loading...","");
  this.commonService.post(apiUrl,formElmValue).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res:any) => {  
    debugger  
    if(res.status && !this.ngModel_url){ 
        this.previewAgreement(formElmValue); 
    }else{
      this.serviceFactory.notification(res.message,res.status); 
    }
  
})  
}
 
previewAgreement(formElmValue:any){ 
  let previewUrl='';
  let apiUrl = '';
  if(this.salestype_Params=='pmp_lt'){
    previewUrl = environment.onboarding_host+'lt-premium-esign?counsellor_preview='+formElmValue.user_id
  }else if(this.salestype_Params=='dwn_lt'){
    previewUrl = environment.onboarding_host+'lt-esign?counsellor_preview='+formElmValue.user_id
  }else{
  }

  this.IframePreviewAgreementDialogRef = this.dialog.open(this.IframePreviewAgreementTemplate,{
    autoFocus: false,
    disableClose: true,
    width: '1100px',
   
  data: {
    preview_url:this.domSanitizer.bypassSecurityTrustResourceUrl(previewUrl),
    formElmValue:formElmValue, 
  }
});
 
this.IframePreviewAgreementDialogRef.beforeClosed().subscribe((result: any) => {
  if(result){
    debugger 
     this.fetchLeadDetail();
  }       
})
}

show_in_ob_list(){
  debugger   
  
  let apiUrl = '';
  if(this.salestype_Params=='pmp_lt'){
    apiUrl = 'dwLTAgreement/saveUrlAndSendToLtUser';
  }else if(this.salestype_Params=='dwn_lt'){
    apiUrl = 'dwLTAgreement/saveUrlAndSendToUser';
  }
  else{
   
  }
 
   this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post(apiUrl,{
      user_id:this.generateOnBoard.user_id,
      actionType:'add'
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      debugger 
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.IframePreviewAgreementDialogRef.close(res);
      }
    
  })   
}


 

jsonP(data:any){
  return data?JSON.parse(data):[] 
   
 
}

jsonS(data:any){
  return data?JSON.stringify(data):{}    

}

 

 // Preserve original property order
originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
  return 0;
}
getNumber(val:any){
 return Number(val);
}

getEventVal(event:any){
  debugger
   return event.target.value
}
onRMToggleChange(){
  
}

ordinal_suffix_of(i:any) {
  i = Number(i);
  var j = i % 10,
      k = i % 100;
  if (j == 1 && k != 11) {
      return i + "<sup>st</sup>";
  }
  if (j == 2 && k != 12) {
      return i + "<sup>nd</sup>";
  }
  if (j == 3 && k != 13) {
      return i + "<sup>rd</sup>";
  }
  return i + "<sup>th</sup>";
}

onChangeSoFar(){
  debugger
  
  this.generateOnBoard.savedData.base_detail['adv_sale_value'] =  Number(this.generateOnBoard.product_price_details['price']);

  this.generateOnBoard.savedData.base_detail['total_amount_to_be_paid'] = this.generateOnBoard.savedData.base_detail['deal_value']-this.generateOnBoard.savedData.base_detail['adv_sale_value'] 
}

onChangeCalcADV(){
  debugger
  let sumIndustryBy:number =0;
  this.generateOnBoard.savedData['adv_installment']?.forEach((item:any) => {
    debugger
     sumIndustryBy = sumIndustryBy + Number(item.amount);
  });
 this.generateOnBoard.savedData.base_detail['adv_sale_value'] =  Number(sumIndustryBy.toFixed(2)) 
 this.onChangeDealValue();
}
onChangeDealValue(){
  debugger 
 this.generateOnBoard.savedData.base_detail['total_amount_to_be_paid'] = this.generateOnBoard.savedData.base_detail['deal_value']-this.generateOnBoard.savedData.base_detail['adv_sale_value']
 this.onChangeNumberTranches('DealValue')
}

onChangePaymentType(event:any,ngModel:any){
  debugger
  if(event.value=='part' && (!this.generateOnBoard.savedData.base_detail['total_amount_to_be_paid'] || this.generateOnBoard.savedData.base_detail['total_amount_to_be_paid']<1)){
   this.serviceFactory.msgPop('Please Check Deal Value & Non Advisory Fee','error');
   ngModel.control.setValue('full'); 
   return false
  }
  this.generateOnBoard.savedData.base_detail['installment_type'] = 'halfYearly'; 
  this.generateOnBoard.savedData.base_detail['installment_number'] =  this.numberTranchesList['halfYearly'] 
  
  //this.generateOnBoard.savedData.base_detail.first_tanch_date = moment();
  this.onChangeNumberTranches('paymentType');
}


onChangeFrequency(event:any){
  debugger  
  this.generateOnBoard.savedData.base_detail.installment_number =  this.numberTranchesList[this.generateOnBoard.savedData.base_detail.installment_type]  
  this.onChangeNumberTranches('TranchesNo')
}








 onChangeNumberTranches(type:any,indx?:any){
  debugger

  
  let newTranch = [];
  let totalTranch = this.generateOnBoard.savedData.base_detail.installment_number;
  let totalAmount_nonAdv = this.generateOnBoard.savedData.base_detail.total_amount_to_be_paid
  let eachTranchPrice = (totalAmount_nonAdv/totalTranch).toFixed(2);
  var addMonth =0 
  var addMonthsinTranch = this.addMonthsinTranchList[this.generateOnBoard.savedData.base_detail.installment_type]; 
  
  
 

  for(var i = 0; i < totalTranch; i++){
   debugger

   let nextDate = null;
   if(i!=0 && this.generateOnBoard.savedData.base_detail.first_tanch_date){
      nextDate = moment(this.generateOnBoard.savedData.base_detail.first_tanch_date).add(addMonth, 'M'); 
    }

    newTranch.push({
      schedule_date:nextDate,
      amount:Number(eachTranchPrice),
      payment_mode_id:1
     })
   
   
 
   if(i!=0){
    addMonth+=addMonthsinTranch
  }
   
  }
  this.generateOnBoard.savedData.non_adv_installment = newTranch
 }

 onChangeTrancheAmount(i:any){
  debugger
  let totalAmount_nonAdv = this.generateOnBoard.savedData.base_detail.total_amount_to_be_paid-this.generateOnBoard.savedData.non_adv_installment[i].amount
  let eachTranchPrice = (totalAmount_nonAdv/(this.generateOnBoard.savedData.non_adv_installment.length-1)).toFixed(2);

  this.generateOnBoard.savedData.non_adv_installment.forEach((elm:any,index:number) => {
     debugger
     if(i!=index){
       elm.amount = Number(eachTranchPrice);
     }
  });
 }

 onLoad_preview() {
  console.log('onLoad executed');
}
 
copyUrl(form_Group:any,element:any){
  debugger
   if (form_Group.invalid) {
    return;
   }
   element.select();
   element.setSelectionRange(0, 99999)
   document.execCommand("copy");
   this.serviceFactory.notification("URL Copied.",true);
   
}

onSendUrl(form_Group:any){
  debugger  
 
  if (form_Group.invalid) {
      return;
  }

  let apiUrl = '';
  if(this.salestype_Params=='pmp_lt'){
    apiUrl = 'dwLTAgreement/saveUrlAndSendToLtUser';
  }else if(this.salestype_Params=='dwn_lt'){
    apiUrl = 'dwLTAgreement/saveUrlAndSendToUser';
  }
  else{
    apiUrl = 'onboarding/changeAgreementType';
  }


    
   //let salestype = this.salesform.form.controls.salestype.value;
   this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post(apiUrl,{
      user_id:this.generateOnBoard.user_id,
      actionType:'mail'
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      debugger 
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        
      }
    
  })   
}


masterAgreementNot_Signed(data:any){
  this.serviceFactory.msgPop('','error');

  Swal.fire({ 
    title: 'Agreement Not Signed!',
    html: 'Customer has not signed Master Agreement, Please click on Send Master Service Agreement to customer.',
    icon: 'error', 
 customClass: {
   confirmButton: 'mat-flat-button mat-button-base mat-primary',
   cancelButton: 'mat-stroked-button mat-button-base ',
   container: 'modal-yes-no Modal_Delete', 
   actions: 'modal-btn-yes-no mb-4',
   //  header: 'pt-4', 
 },
 width: '36em',
 showCloseButton: true,
 buttonsStyling: false,
 showCancelButton: true,
 confirmButtonText: 'Send Master Link',
 cancelButtonText: 'Cancel' , 
 focusConfirm:false, 
 focusCancel:true,     
}).then((result:any) => {
  debugger
   if (result.isConfirmed) {

    let apiUrl = '';
    if(this.salestype_Params=='pmp_lt'){
      apiUrl = 'dwLTAgreement/sendAgreementOTPLink';
    }else if(this.salestype_Params=='dwn_lt'){
      apiUrl = 'dwLTAgreement/sendAgreementOTPLink';
    }else{
    }

     this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
     this.commonService.post(apiUrl,{
      email:data.email_id,  
     }).pipe( 
       finalize(() => {  
         this.serviceFactory.loadingStop("body","");
       })
     ).subscribe((data:any) => {
       debugger 
       this.serviceFactory.notification(data.message,data.status);  
   }) 
   }
 })

}


}