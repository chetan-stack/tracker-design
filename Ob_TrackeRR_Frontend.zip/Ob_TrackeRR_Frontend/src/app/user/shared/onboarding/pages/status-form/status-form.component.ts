import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'; 
import { NgForm } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';  
import { ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs/operators'; 
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';
import { FilePreviewComponent } from '../../../dialog/file-preview/file-preview.component';
import { ResetAgreementTypeComponent } from '../../dialog/reset-agreement-type/reset-agreement-type.component';
 
 
 

@Component({
  selector: 'app-status-form',
  templateUrl: './status-form.component.html',
  styleUrls: ['./status-form.component.scss'], 
})
export class StatusFormComponent implements OnInit {
   
  getCurrentUser:any = {};
 

  page_id:string;

  @ViewChild('salesform') public salesform: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;
  @ViewChild('elm_phone_no') public elm_phone_no: ElementRef;

 
  generateOnBoard:any = {}

  ob_product_list:any = { };
  product_color:any= {}
  product_label:any= {}  

  storeOldData:any; 
   
  disabledGenerateBTN:boolean = false; 

  ngModel_url:any; 
  salestype_Params:any;
  status_Params:any;
  counsellor_id:any;

   constructor(
    public dialog: MatDialog,
    private commonService: CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService, 
    private route:ActivatedRoute,
  ) { 

    route.queryParams.subscribe(p => {
      debugger  
      if(p){  
          this.salestype_Params =  p.salestype; 
          this.status_Params = atob(p.stus); 
          this.counsellor_id = atob(p.ci);   
      }
       
    }
  )

      this.getCurrentUser = this.commonService.getCurrentUser();
      let PageTitle = route.snapshot.data['title'];
      this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
      this.page_id = this.route.snapshot.params['id'];
    

      this.product_label = this.dataFactory.all_product_label;
      this.product_color = this.dataFactory.all_product_color;

 
       this.fetchLeadDetail();
       
  } 

  ngOnInit(): void {
  }
 

  fetchLeadDetail() { 
    debugger
    
   
    this.serviceFactory.loadingStart("body","Please wait while loading...","");  
    this.commonService.post('onboarding/getOnboardingStatus',{
      ob_customer_id:this.page_id ,
      salestype:this.salestype_Params 
    }).pipe( 
      finalize(() => { 
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      debugger 
      if(res.status){ 
         let data = res.data.data;
        this.generateOnBoard = data

          let tag = this.dataFactory.salesType_ob_url[this.salestype_Params];
           if(tag!=''){
            this.ngModel_url = environment.onboarding_host+tag+"?uid="+data.onboarding_url;  
           }else{
            this.ngModel_url = environment.onboarding_host+tag+"?uid="+data.onboarding_url; 
           }

       
       
        const created = data.cust_status.filter((item:any) => item.label === "Payment");
       if(created.length>0 && created[0].status){
        this.disabledGenerateBTN = true
       }else{
        this.disabledGenerateBTN = false
       }
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
  
    }) 


  

  }
 

  async resetStapes(elm:any){
    debugger
     

    Swal.fire({ 
         title: 'Steps Reset!',
         html: 'Are you sure you want to reset this Steps?',
         icon: 'warning', 
      customClass: {
        confirmButton: 'mat-flat-button mat-button-base mat-primary',
        cancelButton: 'mat-stroked-button mat-button-base ',
        container: 'modal-yes-no Modal_Delete', 
        actions: 'modal-btn-yes-no mb-4',
        //  header: 'pt-4', 
      },
      width: '36em',
      showCloseButton: true,
      buttonsStyling: false,
      showCancelButton: true,
      confirmButtonText: 'Reset',
      cancelButtonText: 'Cancel' , 
      focusConfirm:false, 
      focusCancel:true,     
     }).then((result) => {
       debugger
        if (result.isConfirmed) {
          this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
          this.commonService.post('onboarding/resetCustomerStatus',{
            leadId:this.generateOnBoard.leadId,
            ob_customer_id:this.page_id,
            label:elm.label,
            salestype:this.salestype_Params
          }).pipe( 
            finalize(() => {  
              this.serviceFactory.loadingStop("body","");
            })
          ).subscribe((data) => {
            debugger 
            this.serviceFactory.notification(data.message,data.status); 
            if(data.status){
              this.fetchLeadDetail()
            } 
        }) 
        }
      })


   
    
  }

 

  dynmClass(str:any){
   return str.replace(/[*]|[' ']|[.]|[?]|[\[]|[\]]|[/]|[:]|[;]|[\\]/g, '_')
  }


  ResetAgreement_Type(elm:any){
    debugger
  
   let dialogRef = this.dialog.open(ResetAgreementTypeComponent,{
      autoFocus: false,
      // disableClose: true,
    //  width: '800px',
      data: {ob_customer_id:this.page_id,leadId:this.generateOnBoard.leadId,label:elm.label,salestype:this.salestype_Params,counsellor_id:this.counsellor_id}
  });


  dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      this.fetchLeadDetail()

     // this.generateOnBoard =  undefined
    }       
  })

  }


  copyUrl(form_Group:any,element:any){
    debugger
     if (form_Group.invalid) {
      return;
     }
     element.select();
     element.setSelectionRange(0, 99999)
     document.execCommand("copy");
     this.serviceFactory.notification("URL Copied.",true);
     
  }
  
  onSendUrl(form_Group:any){
    debugger  
  
      this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

      this.commonService.post('onboarding/sendUrlToUser',{
        leadId:this.generateOnBoard.leadId,
        ob_customer_id:this.page_id,
        salestype:this.salestype_Params
      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data) => {  
        debugger 
        this.serviceFactory.notification(data.message,data.status); 
        if(data.status){
          
        }
      
    })   
  }

  viewKyc(elm:any){
    debugger

    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

    this.commonService.post('miscellaneous/getPanfile',{
      leadId:this.generateOnBoard.leadId,
      ob_customer_id:this.page_id,
      salesType:this.salestype_Params
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res) => {  
      debugger  
      if(res.status){ 
        let dialogRef = this.dialog.open(FilePreviewComponent,{ 
           maxWidth:'1000px',  
           maxHeight: 'calc(100vh - 90px)',
          autoFocus:false,
          restoreFocus:false,
          panelClass: 'chat-box-container',
          data:{ 
            file:res.data
          }, 
        });
        
        dialogRef.beforeClosed().subscribe(result => {
          if(result){
            debugger 
           
          }       
        })
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
    
  }) 
     

  }

}
