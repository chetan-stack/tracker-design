import { KeyValue } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { fromEvent, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service'; 
import { ViewUserInfoComponent } from '../../../dialog/view-user-info/view-user-info.component';


 
 

const columns_show = {
  'id': 'S No.', 
  'customer_full_name': 'Customer Name',
  'customer_email_id': 'Customer Email',
  'lead_id': 'Lead No.',
  'phone_no': 'Phone No.',
  'received_date': 'Received Date',
  'old_profile_type':'Old Profile Type', 
  'new_profile_type': 'New Profile Type', 
  'request_status':'Request Status',
  'action': 'Actions'
}

const ColumnDefaultShow  =  [
  'id',
  'customer_full_name',
  'customer_email_id',
  'lead_id',
  'phone_no',
  'received_date',
  'old_profile_type',
  'new_profile_type', 
  'request_status',
  'action'
  ]

  export const MY_FORMATS = {
    parse: {
      dateInput: 'LL',
    },
    display: {
      dateInput: 'D MMM YYYY',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'MMMM YYYY',
    },
  };

   
@Component({
 selector: 'app-portfolio-request',
    templateUrl: './portfolio-request.component.html',
    styleUrls: ['./portfolio-request.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
   // { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
  ],
})
export class PortfolioRequestComponent implements OnInit {
  getCurrentUser: any ={};
  moment = moment; 
  product_label:any={};
  product_color:any = {} ; 
  salestype_Params:any;
 
  gridDataSource = new MatTableDataSource();
  allColumnsForShow:any = {}
  Column_type_defaultShow:any = []

 

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;

  filter_Search:string = "";
  counsellors:any=[];
  managers:any=[];
  
  storedAllData:any;
  counsellorList:any=[];
  constructor(
    private route: ActivatedRoute,
    private dataFactory: DataFactoryService,
    private serviceFactory: ServiceFactory,
    private commonService: CommonService,  
    private router: Router,
    private dialog: MatDialog,
    
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
    
    this.product_color = this.dataFactory.all_product_color;
    this.product_label = this.dataFactory.all_product_label;

    this.allColumnsForShow = columns_show;
    
    
    
 
    if(this.getCurrentUser.activeRole=="counsellor"){
      this.counsellors = [this.getCurrentUser.id]
     }else{
      this.loadTeamListByParent();
     }

    if(this.getCurrentUser.activeRole!="counsellor"){
     this.loadTeamListByParent();
    }
    
    route.queryParams.subscribe(p => {   
      this.salestype_Params = p.salestype ; 
      this.loadGrid_Data() 
    });

     
  }

  loadTeamListByParent() {
    let dataOption:any = { 
     parent_id:this.getCurrentUser.id
   }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
     this.counsellorList = res.data; 
    })
 }

  ngOnInit(): void {
    this.Column_type_defaultShow = ColumnDefaultShow;
  }

  ngAfterViewInit(): void {
     
  
  }

  loadGrid_Data() {


    let dataOption:any = { 
      counsellors:this.counsellors,
      salestype:this.salestype_Params
    }
    if(this.getCurrentUser.activeRole!="counsellor" && this.getCurrentUser.activeRole!="manager"){
      dataOption['managers'] = this.managers
    }

    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('subscriptionRenewal/getNewPortfolioRequestList',dataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
       if(res.status){
        this.storedAllData = res.data;
        this.bindGridData(res.data);
      }else{
        this.serviceFactory.notification(res.message,res.status); 
        this.storedAllData = undefined;
        this.bindGridData([]);
      }

    })
  }

  bindGridData(data:any) {
    this.gridDataSource = new MatTableDataSource(data);
    this.gridDataSource.sort = this.sort;
    this.bindTableGridWidth();
  }
 
  
  onFilterGrid() { 
      this.loadGrid_Data();
  }

  onFilter_DateRange_Grid(data:any){ 
    if(data.value){
      this.onFilterGrid()
    }
  }
  bindTableGridWidth() {

    let w = 0;
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number = string.replace("%", "");
      w = w + Number(number);
    }

    if (this.data_table._elementRef.nativeElement) {
      this.data_table._elementRef.nativeElement.style.minWidth = w + 'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w + 'px';

    }

  }

  // Preserve original property order
  originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
    return 0;
  }

  textMask(type: any, value: any) {
    //
    if (type == 'phone' && value) {
      var part1, part2;
      part1 = value.slice(0, 3);
      part2 = value.toString().substr(-2);
      return part1 + "********" + part2;
    } else if (type == 'email' && value) {

      var avg, splitted, part1, part2;
      splitted = value.split("@");
      part1 = splitted[0];
      part1 = part1.slice(0, 3);
      part2 = splitted[1].substr(-4);
      return part1 + "*******@****" + part2;
    } else {
      return value
    }
  }

  openDialogUserInfo(element:any){
    debugger
    const dialogRef = this.dialog.open(ViewUserInfoComponent, {
      height: 'auto',
      width: '610px',
      data: {
        name:element.customer_full_name,
        email:element.customer_email_id,
        phone:element.customer_phone_no
      },
    });
  }


  refreshGrid() {
 
    this.filter_Search="";
    this.gridDataSource.filter = "".trim().toLowerCase(); 

    this.loadGrid_Data();

  }


  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.gridDataSource.filter = filterValue.trim().toLowerCase();
  }
}
