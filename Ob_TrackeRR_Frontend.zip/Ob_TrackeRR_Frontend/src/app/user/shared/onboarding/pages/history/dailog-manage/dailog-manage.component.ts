import { ViewUserInfoComponent } from './../../../../dialog/view-user-info/view-user-info.component';
import { RemarkHistoryComponent } from './../../../../dialog/remark-history/remark-history.component';
import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';  
import { CommonService } from 'src/services/api/common.service';
import { ActivatedRoute, ActivationStart, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-dailog-manage',
  templateUrl: './dailog-manage.component.html',
  styleUrls: ['./dailog-manage.component.scss']
})

export class DailogManageComponent implements ICellRendererAngularComp, OnInit {
  element:any
  salestype_Params:any
  getCurrentUser:any
  parameterCheck:any
  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}

  constructor(
    private dataFactory: DataFactoryService,
    private serviceFactory: ServiceFactory,
    private commonService: CommonService,  
    private router: Router,
    private dialog: MatDialog,
    private route: ActivatedRoute,

  ) { 
    this.Status_Icon = this.dataFactory.All_Status_Icon;  
    this.Status_Name = this.dataFactory.All_Status_Name;

    this.getCurrentUser = this.commonService.getCurrentUser();
    this.Status_Color = this.dataFactory.All_Status_Color;

    route.queryParams.subscribe((p:any) => {  
      debugger
     this.salestype_Params = p.salestype; 
   });
   this.Status_Name = this.dataFactory.All_Status_Name;

  }



  ngOnInit(): void {
  }

  public cellValue!: string;

  
  getValueToDisplay(params: ICellRendererParams) {
    return params.valueFormatted ? params.valueFormatted : params.value;
  }
  agInit(params: any): void {
    // this.cellValue = this.getValueToDisplay(params.data);
    if(params.data != undefined || params.data != null){
      this.element = params.data
      this.parameterCheck = params.typeSend
    }
   else{
    this.element = ''
      this.parameterCheck = ''
   }
    //  console.log(this.element,this.parameterCheck)
  }

  refresh(params: any) {
    // this.cellValue = this.getValueToDisplay(params.data);
    return true;
    //this.parameterCheck = params.typeSend
  }

  EditOnboarding(element:any){
    if(this.salestype_Params!='pmp_lt' && this.salestype_Params!='dwn_lt'){
      this.router.navigate(['./edit/'+element.counsellor_id+'/'+element.lead_id],{ 
        queryParams: {salestype: this.salestype_Params},
        relativeTo: this.route
      }); 
    }
 
    else{
      this.router.navigate(['./edit-pmp/'+element.counsellor_id+'/'+element.customer_email_id],{ 
        queryParams: {salestype: this.salestype_Params},
        relativeTo: this.route
      });
    } 
    
  }
  getBtoa(data:string){
    return btoa(data);
    }

    showRemarkHistory(element:any){
 
      debugger 
      let dialogRef; 
     
      this.commonService.post('autopayment/getEnachSkipComments',{enach_dtl_id:element.enach_dtl_id}).subscribe((res:any) => {  
        debugger    
            if(res.status){ 
              dialogRef = this.dialog.open(RemarkHistoryComponent, {
                height: 'auto',
                width: '900px',
                data: {title:'e-Nach Status Remarks History', data:res.data}, 
              }); 
            }else{
              this.serviceFactory.notification(res.message,res.status); 
            }
      })   
    }

    openDialogUserInfo(element:any){
      debugger
      const dialogRef = this.dialog.open(ViewUserInfoComponent, {
        height: 'auto',
        width: '610px',
        data: {
          name:element.customer_full_name,
          email:element.customer_email_id,
          phone:element.customer_phone_no
        }, 
      });
    }

    changeStatus(element:any){
      debugger
    
      Swal.fire({ 
        title: 'Change Status!',
        html: 'Since you are going to change its agreement status so customer has to resign his agreement.',
        icon: 'warning', 
     customClass: {
       confirmButton: 'mat-flat-button mat-button-base mat-primary',
       cancelButton: 'mat-stroked-button mat-button-base ',
       container: 'modal-yes-no Modal_Delete', 
       actions: 'modal-btn-yes-no mb-4',
       //  header: 'pt-4', 
     },
     width: '36em',
     showCloseButton: true,
     buttonsStyling: false,
     showCancelButton: true,
     confirmButtonText: 'Change',
     cancelButtonText: 'Cancel' , 
     focusConfirm:false, 
     focusCancel:true,     
    }).then((result:any) => {
      debugger
       if (result.isConfirmed) {
         this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
         this.commonService.post('sales/changeAgreementStatusPmp',{
           customer_id:element.customer_id, 
           salesType:this.salestype_Params
         }).pipe( 
           finalize(() => {  
             this.serviceFactory.loadingStop("body","");
           })
         ).subscribe((data) => {
           debugger 
           this.serviceFactory.notification(data.message,data.status); 
           if(data.status){
            //  this.loadGrid_Data()
           } 
       }) 
       }
     })
    }
}
