import { DailogManageComponent } from './dailog-manage/dailog-manage.component';
import { BreakpointObserver } from '@angular/cdk/layout';
import { KeyValue } from '@angular/common';
import { AfterViewInit, Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, ActivationStart, Router } from '@angular/router';
import * as moment from 'moment';
import { fromEvent, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators'; 
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';  
import Swal from 'sweetalert2'; 
import { DownloadComponent } from '../../../dialog/download/download.component';
import { EnachSkipRequestComponent } from '../../../dialog/enach-skip-request/enach-skip-request.component';
import { RemarkHistoryComponent } from '../../../dialog/remark-history/remark-history.component';
import { ViewUserInfoComponent } from '../../../dialog/view-user-info/view-user-info.component';
import { PaymentConfirmationComponent } from '../../dialog/payment-confirmation/payment-confirmation.component';
import { ColDef, ColumnApi, GridApi, GridOptions, GridReadyEvent, IGetRowsParams } from 'ag-grid-community';


const columns_show = {
  all:{
    'id': 'S No.',
    'customer_full_name': 'Customer Name', 
    'customer_email_id':'Email', 
    'lead_id': 'Lead No.', 
    'customer_phone_no':'Phone',
    'counsellor_name': 'Counsellor Name', 
    'sent_date': 'Sent Date', 
    'product': 'Product',
    'duration':'Duration(Y)',
    'amount': "Amount",
    'tenure_extended': 'Tenure Extended',
    'informed_investorr': "Informed InvestoRR",
    'agreement_type': "Agreement Type", 
    'status': "Status",
    'enach_status':'e-Nach Status',
    'action': 'Actions'
  }, 
  pmp:{
    'id': 'S No.',
    'customer_full_name': 'Customer Name', 
    'customer_email_id':'Email',  
    'customer_id': 'Cust. ID',  
    'customer_phone_no':'Phone',
    'lead_id': 'Lead No.',
    
    'counsellor_name': 'Counsellor Name', 
    'status': "Status",  
    'enach_status':'e-Nach Status', 
    //'tenure_extended': 'Tenure Extended',
    //'informed_investorr': "Informed InvestoRR",
    'agreement_type': "Agreement Type", 
    'sent_date': 'Sent Date', 
    'approve_date':'Approved Date',
    //'schedule_date':'Payment Status', 
    'action': 'Actions'
  },
}

const ColumnDefaultShow  =  {
  all:[
  'id',
  'customer_full_name', 
  'lead_id', 
  'counsellor_name',
  'sent_date', 
  'product', 
  'amount',
  'agreement_type',
  'status', 
  'enach_status',
  'action'
  ],
  pmp:[
    'id',
    'customer_full_name', 
    'customer_id', 
    'counsellor_name',
    'sent_date',
    'approve_date', 
    'agreement_type',
    'status', 
    'enach_status', 
    'action'
    ],

  
}
const filterForm:any = {
  filter_Counsellor:[], 
  filter_Status:[],
  filter_Enach:[],
  filter_Product:[],   
  filter_sent_date:{
    start_date:null,
    end_date:null,
  }, 
}

  export const MY_FORMATS = {
    parse: {
      dateInput: 'LL',
    },
    display: {
      dateInput: 'D MMM YYYY',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'MMMM YYYY',
    },
  };

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss'], 
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
     { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
     { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
  ],
})
export class HistoryComponent implements OnInit,AfterViewInit {
  selectedRowIndex:any;
  getCurrentUser: any ={};
  rnr_domain:any;
  moment = moment; 
  product_label:any={};
  product_color:any = {} ;
  salesType_list:any={};
  paginationPageSize:any
  arraydata:any = []

  getStatusMasterList:any = []

  AgreementTypes:any = [
    "OTP",
    "Adhaar"
  ]

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}
  
  gridDataSource = new MatTableDataSource();
  allColumnsForShow:any = {}
  Column_type_defaultShow:any = []
  rowData:any;
  // columnDefs:any

  @ViewChild(MatPaginator) paginator: MatPaginator;

  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;
  @ViewChild('ngFilterFormElm') public ngFilterFormElm: NgForm|any;


//ag grid column start
columnDefs : ColDef[] =[
  {headerName: 'S No.', field: 'selfIndex',width:100},
  {headerName: 'Customer Name', field: 'customer_full_name',filter: 'agSetColumnFilter',cellRenderer:DailogManageComponent,cellRendererParams:{typeSend:'customer_name'}},
  {headerName: 'Lead No.', field: 'lead_id',filter:true},
  {headerName: 'Counsellor Name', field: 'counsellor_name',filter:true},

  {headerName: 'Sent Date', field: 'sent_date',filter:'agDateColumnFilter'},
  {headerName: 'Product', field: 'product',filter:true,
  cellRenderer:(param:any) => {
    if(param['data'] != undefined){
      // console.log("check--------",param['data'].product)

      let key = param['data']['product'].toString()
      return`
      <div style="margin-top: 7px;">
      <span class="badge ProductColor in5">${key == "1"?'5in5':''}</span>
      <span class="badge ProductColor">${key == "1,12"?'combo(5in5 & MPO)':''}</span>
      <span class="badge ProductColor mpo">${key == "12"?'MPO':''}</span>
      </div>
      `;
    }
    
  }},
  {headerName: 'Amount', field: 'amount',filter:'agNumberColumnFilter'},
  {headerName: 'Agreement Type', field: 'agreement_type',filter:true},
  {headerName: 'Status', field: 'status',filter:true,
  cellRenderer:DailogManageComponent,
  cellRendererParams: {
    typeSend:'status'
  }},
  {headerName: 'e-Nach Status', field: 'enach_status',filter:true,
  cellRenderer:DailogManageComponent,
  cellRendererParams: {
    typeSend:'enash'
  }

},
  {headerName: 'Actions', field: '1',filter:true,pinned:'right',width:100,
  cellRenderer: DailogManageComponent,
  cellRendererParams: {
    typeSend:'menuDailog'
  }
}

];
//ag grid end


  filter_Search:string = ""; 
  filter_fieldData:any = JSON.parse(JSON.stringify(filterForm));
  filter_ApplyedCount:any = 0;
  counsellors:any=[];
  managers:any=[];
  storedAllData: any;
  filterApiDataOption:any = {};
  allTeamList:any=[];
  sideBar:any;
  salestype_Params:any;
  columnDefstree:any;
  rowModelType:any;
  cacheOverflowSize:any;
  maxConcurrentDatasourceRequests:any;
  infiniteInitialRowCount:any;
  gridOptions: Partial<GridOptions>;
  datasource: { getRows: (params: IGetRowsParams) => void; };

  constructor(
    private route: ActivatedRoute,
    private dataFactory: DataFactoryService,
    private serviceFactory: ServiceFactory,
    private commonService: CommonService,  
    public mediaQ: BreakpointObserver,
    private router: Router,
    private dialog: MatDialog,
    
  ) { 

  

    //ag-grid
    this.gridOptions = {
      headerHeight: 45,
      rowHeight: 40,
      cacheBlockSize: 20,
      paginationPageSize: 20,
      rowModelType: 'infinite',
    }
    this.paginationPageSize= 20;
    this.rowModelType = 'serverSide';
    this.sideBar = {
      toolPanels: [
        {
          id: 'columns',
          labelDefault: 'Columns',
          labelKey: 'columns',
          iconKey: 'columns',
          toolPanel: 'agColumnsToolPanel',
        }, 
      ],
    };

    //tree data

    this.columnDefstree = [
      {
        headerName: 'Category',
        field: 'catName',
        hide: true,
      },
      {
        headerName: 'Category Id',
        field: 'catId',
      },
    ];
    this.prepareData();

    //ag-grid-end

    console.log('columnDefs',this.columnDefs)

     this.getCurrentUser = this.commonService.getCurrentUser();
     this.rnr_domain = environment.rnr_domain;
      let PageTitle = route.snapshot.data['title'];
      this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
      
      this.product_color = this.dataFactory.all_product_color;
      this.product_label = this.dataFactory.all_product_label;
      this.salesType_list = this.dataFactory.salesType_list;
      this.Status_Name = this.dataFactory.All_Status_Name;
      this.Status_Color = this.dataFactory.All_Status_Color;
      this.Status_Icon = this.dataFactory.All_Status_Icon;  
     
 

     if(this.getCurrentUser.activeRole=="counsellor"){
      this.counsellors = [this.getCurrentUser.id]
     }else{
      this.loadTeamListByParent();
     }
     route.queryParams.subscribe(p => {  
       debugger
      let stringifyColumn:any = JSON.stringify(ColumnDefaultShow);



      this.salestype_Params = p.salestype; 
      if(this.salestype_Params=='pmp_lt' || this.salestype_Params=='dwn_lt'){
        this.allColumnsForShow = columns_show.pmp;
        this.Column_type_defaultShow = JSON.parse(stringifyColumn).pmp;
      }else{
        this.allColumnsForShow = columns_show.all;
        this.Column_type_defaultShow = JSON.parse(stringifyColumn).all;
      }
      this.dataFactory.setPageTitle({PageTitle: "History Of "+this.salesType_list[this.salestype_Params]});
  
      const countFilteredData = p.sales_countFiltered?JSON.parse(atob(p.sales_countFiltered)):null;

      if(countFilteredData?.status){   
         this.filter_fieldData.filter_Status = countFilteredData['status'];
      }
      if(countFilteredData?.date){   
        this.filter_fieldData.filter_sent_date.start_date = countFilteredData['date'].from_date;
        this.filter_fieldData.filter_sent_date.end_date = countFilteredData['date'].to_date;
      }
       

      if(this.getCurrentUser.activeRole=="counsellor"){
        const index = this.Column_type_defaultShow.indexOf('counsellor_name');
        if (index > -1) {
          this.Column_type_defaultShow.splice(index, 1); // 2nd parameter means remove one item only
        } 
      }

      if(this.salestype_Params=='retail_renewal' || this.salestype_Params=='dwn_renewal'){
        const index = this.Column_type_defaultShow.indexOf('enach_status');
        if (index > -1) {
          this.Column_type_defaultShow.splice(index, 1); // 2nd parameter means remove one item only
        } 
      }

      this.loadGrid_Data() 
    });

  }

  loadTeamListByParent() {
    let dataOption:any = { 
     parent_id:this.getCurrentUser.id
   }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
      this.allTeamList = res.data; 
    })
 }

  ngOnInit(): void {
    this.commonService.get('onboarding/getUserStatusMasterList',{salestype:this.salestype_Params}).subscribe((res:any) => {
      if(res.status){
        this.getStatusMasterList = res.data;
      } 
   })
    
  }

  ngAfterViewInit(): void {
    debugger

    fromEvent(this.textSearch_main.nativeElement, 'keyup').pipe(debounceTime(250),distinctUntilChanged(),tap(() => {
      debugger
      // this.paginator.pageIndex = 0,
      //  this.loadGrid_Data();
      this.gridApi.setDatasource(this.datasource);   

    })
  ).subscribe();
  
 
 
 

      // reset the paginator after sorting
   this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

   // on sort or paginate events, load a new page
   merge(this.sort.sortChange, this.paginator.page)
   .pipe(
       tap(() => this.loadGrid_Data())
   )
   .subscribe();
  }

  loadGrid_Data() {
    debugger

    this.filterApiDataOption = {
      search: this.filter_Search,
      status: this.filter_fieldData.filter_Status,
      agreement_type: this.filter_fieldData.Agrement_Type,
      product: this.filter_fieldData.filter_Product,
      short_key: this.sort?this.sort.active:"",
      short_order: this.sort?this.sort.direction:"",
      page: this.paginator?this.paginator.pageIndex:0,
      perpage: this.paginator?this.paginator.pageSize:20,
      start_date: this.filter_fieldData.filter_sent_date.start_date ? moment(this.filter_fieldData.filter_sent_date.start_date).format('YYYY-MM-DD') : '',
      end_date: this.filter_fieldData.filter_sent_date.end_date ? moment(this.filter_fieldData.filter_sent_date.end_date).format('YYYY-MM-DD') : '',
      counsellors:this.filter_fieldData.filter_Counsellor,
      salestype:this.salestype_Params
    }

     

    if(this.getCurrentUser.activeRole!="counsellor" && this.getCurrentUser.activeRole!="manager"){
      this.filterApiDataOption['managers'] = this.managers
    }

    
    
   

    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('onboarding/getObUsersHistory',this.filterApiDataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      //add index key
      res.data.dataobject.forEach((ele:any,i:any) => {
        res.data.dataobject[i].selfIndex = i+1
      } )
      if(res.status){
        this.storedAllData = res.data;
        this.bindGridData(res.data.dataobject);
        //  this.rowData = res.data.dataobject
      }else{
        this.storedAllData = undefined;
        this.bindGridData([]);
      }
     

    })

 
    this.filter_ApplyedCount = this.serviceFactory.getFilterAppliedCount(this.filter_fieldData);
     

  }

  bindGridData(data:any) {
    this.gridDataSource = new MatTableDataSource(data);
    this.gridDataSource.sort = this.sort;
    this.bindTableGridWidth();
  }

  changeColumnFilter(event: any,elm:any){
    debugger 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");  
    setTimeout(() => {
      let selected:any = []; 
      elm.options._results.forEach((element:any) => {
        if(element.selected){
           selected.push(element.value)
        }
      });
      this.Column_type_defaultShow = selected;
      this.serviceFactory.loadingStop("body","");
       debugger
    }, 200);

    setTimeout(() => {
      this.bindTableGridWidth();
    }, 700);
    
  }
  onFilterGrid() {
    debugger
    // this.paginator.pageIndex = 0,
      // this.loadGrid_Data();
      this.gridApi.setDatasource(this.datasource);   

      // this.onGridReady(this.gridApi)
  }

  onFilter_SalesDateRange_Grid(data:any){ 
    if(data.value){
      this.onFilterGrid()
    }
  }
  
  bindTableGridWidth() {

    let w = 0;
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number = string.replace("%", "");
      w = w + Number(number);
    }

    if (this.data_table._elementRef.nativeElement) {
      this.data_table._elementRef.nativeElement.style.minWidth = w + 'px';
      
      document.querySelector<any>('.Grid_No_data').style.minWidth = w + 'px';

    }

  }

  // Preserve original property order
  originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
    return 0;
  }

  textMask(type: any, value: any) {
    //
    if (type == 'phone' && value) {
      var part1, part2;
      part1 = value.slice(0, 3);
      part2 = value.toString().substr(-2);
      return part1 + "********" + part2;
    } else if (type == 'email' && value) {

      var avg, splitted, part1, part2;
      splitted = value.split("@");
      part1 = splitted[0];
      part1 = part1.slice(0, 3);
      part2 = splitted[1].substr(-4);
      return part1 + "*******@****" + part2;
    } else {
      return value
    }
  }

  openDialogUserInfo(element:any){
    debugger
    const dialogRef = this.dialog.open(ViewUserInfoComponent, {
      height: 'auto',
      width: '610px',
      data: {
        name:element.customer_full_name,
        email:element.customer_email_id,
        phone:element.customer_phone_no
      }, 
    });
  }


  refreshGrid(mode:any) {
    let stringifyColumn:any = JSON.stringify(ColumnDefaultShow);
   
   
    if(this.salestype_Params=='pmp_lt' || this.salestype_Params=='dwn_lt'){ 
      this.Column_type_defaultShow = JSON.parse(stringifyColumn).pmp;
    }else{ 
      this.Column_type_defaultShow = JSON.parse(stringifyColumn).all;
    }


    if(this.getCurrentUser.activeRole=="counsellor"){
      const index = this.Column_type_defaultShow.indexOf('counsellor_name');
      if (index > -1) {
        this.Column_type_defaultShow.splice(index, 1); // 2nd parameter means remove one item only
      } 
    }

    if(this.salestype_Params=='retail_renewal' || this.salestype_Params=='dwn_renewal'){
      const index = this.Column_type_defaultShow.indexOf('enach_status');
      if (index > -1) {
        this.Column_type_defaultShow.splice(index, 1); // 2nd parameter means remove one item only
      } 
    }
     
    
    if(this.paginator){
      this.paginator.pageIndex = 0;  
      this.sort.active = "";
      this.sort.direction = ""; 
      
      this.filter_Search="";
      this.filter_fieldData = JSON.parse(JSON.stringify(filterForm));
    }
 

    if(mode=="reset"){
      // this.loadGrid_Data();
      this.gridApi.setDatasource(this.datasource);   
    }
   
  }

  jsonP(data:any){
    return data?JSON.parse(data):[] 
     
   
  }
  
  jsonS(data:any){
    return data?JSON.stringify(data):""    
  
  }
  getBtoa(data:string){
    return btoa(data);
    }

    copyMessage(val:any){
      const selBox = document.createElement('textarea');
      selBox.style.position = 'fixed';
      selBox.style.left = '0';
      selBox.style.top = '0';
      selBox.style.opacity = '0';
      selBox.style.height = '1px';
      selBox.style.width = '1px'; 
      selBox.style.border = '0';
      selBox.value = val;
      document.body.appendChild(selBox);
      selBox.focus();
      selBox.select();
      document.execCommand('copy');
      document.body.removeChild(selBox); 
      this.serviceFactory.notification("URL Copied.",true);
     
}

changeStatus(element:any){
  debugger

  Swal.fire({ 
    title: 'Change Status!',
    html: 'Since you are going to change its agreement status so customer has to resign his agreement.',
    icon: 'warning', 
 customClass: {
   confirmButton: 'mat-flat-button mat-button-base mat-primary',
   cancelButton: 'mat-stroked-button mat-button-base ',
   container: 'modal-yes-no Modal_Delete', 
   actions: 'modal-btn-yes-no mb-4',
   //  header: 'pt-4', 
 },
 width: '36em',
 showCloseButton: true,
 buttonsStyling: false,
 showCancelButton: true,
 confirmButtonText: 'Change',
 cancelButtonText: 'Cancel' , 
 focusConfirm:false, 
 focusCancel:true,     
}).then((result) => {
  debugger
   if (result.isConfirmed) {
     this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
     this.commonService.post('sales/changeAgreementStatusPmp',{
       customer_id:element.customer_id, 
       salesType:this.salestype_Params
     }).pipe( 
       finalize(() => {  
         this.serviceFactory.loadingStop("body","");
       })
     ).subscribe((data) => {
       debugger 
       this.serviceFactory.notification(data.message,data.status); 
       if(data.status){
         this.loadGrid_Data()
       } 
   }) 
   }
 })
}


sendSkipReq(elm:any){
  debugger

  const dialogRef = this.dialog.open(EnachSkipRequestComponent, {
    height: 'auto',
    width: '610px',
    data: elm, 
  });
  dialogRef.afterClosed().subscribe((result: any) => {
    if (result) { 
      this.loadGrid_Data();
    }
  });

}

markPaymentDone(elm:any){ 
  debugger
  elm['type'] = "Add";
  const dialogRef = this.dialog.open(PaymentConfirmationComponent, {
      width:'820px',  
      autoFocus:false,
      restoreFocus:false,
      disableClose: true,
      //data: elm, 
      data:elm, 
  });
  dialogRef.afterClosed().subscribe((result: any) => {
    if (result) { 
      this.loadGrid_Data();
    }
  });
}


EditOnboarding(element:any){

 

  if(this.salestype_Params!='pmp_lt' && this.salestype_Params!='dwn_lt'){
    this.router.navigate(['./edit/'+element.counsellor_id+'/'+element.lead_id],{ 
      queryParams: {salestype: this.salestype_Params},
      relativeTo: this.route
    }); 
  }
  // if(this.salestype_Params=='pmp_lt'){ 
  //   window.open(this.rnr_domain+"premium-membership/retail-pmp/edit/"+this.getBtoa(element.customer_email_id), "_blank");
      
  // }else if(this.salestype_Params=='dwn_lt'){ 
  //   window.open(this.rnr_domain+"lt-premium/dashboard-pmp/edit/"+this.getBtoa(element.customer_email_id), "_blank");
      
  // }
  else{
    this.router.navigate(['./edit-pmp/'+element.counsellor_id+'/'+element.customer_email_id],{ 
      queryParams: {salestype: this.salestype_Params},
      relativeTo: this.route
    });
  } 
  
}

 

showRemarkHistory(element:any){
 
  debugger 
  let dialogRef; 
 
  this.commonService.post('autopayment/getEnachSkipComments',{enach_dtl_id:element.enach_dtl_id}).subscribe((res:any) => {  
    debugger    
        if(res.status){ 
          dialogRef = this.dialog.open(RemarkHistoryComponent, {
            height: 'auto',
            width: '900px',
            data: {title:'e-Nach Status Remarks History', data:res.data}, 
          }); 
        }else{
          this.serviceFactory.notification(res.message,res.status); 
        }
       

  })   
}

downloadPdf(){
  debugger 
  let stringify = JSON.stringify(this.Column_type_defaultShow);
  let parse = JSON.parse(stringify);

  
  let colShow:any = []
    parse.forEach((element:any) => {
      colShow.push({name:element,label:this.allColumnsForShow[element]})
    });

 
    let stringify_dataOption = JSON.stringify(this.filterApiDataOption);
    let dataOption = JSON.parse(stringify_dataOption);  

    let endPoint = 'onboarding/getObUsersHistory';


    let cellW = [];
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number = string.replace("%", ""); 
     cellW.push(Number(number))
    }


       const dialogRef = this.dialog.open(DownloadComponent, {
      width:'600px',   
      autoFocus:false, 
      data:{
        endPoint:endPoint,
        fileName:'Onboarding History',
        dataOption:dataOption,
        colShow:colShow,
        cellW:cellW
      },
    });
 
}

selectRow(event:any){
console.log(event)
this.columnDefs = event
  // if(!this.columnDefs.includes(event)){

  // }
}


//ag grid bind data

private gridApi:any;
private gridColumnApi:any;
onPageSizeChanged() {
  var value = (document.getElementById('page-size') as HTMLInputElement)
    .value;

  this.gridApi.paginationSetPageSize(Number(value));
  console.log(this.gridApi)
}

 async onGridReady(params:any) {
   console.log('On Grid Ready');
   this.gridApi = params.api;
   this.gridColumnApi = params.columnApi;
  console.log("grid api",this.gridApi)
    this.datasource = {
     getRows: (params: IGetRowsParams) => {
       debugger
       const para = {
         page: this.gridApi['paginationProxy'].currentPage + 1,
          perpage:this.gridApi['paginationProxy'].pageSize?this.gridApi['paginationProxy'].pageSize:20,
        search: this.filter_Search,
        status: this.filter_fieldData.filter_Status,
        agreement_type: this.filter_fieldData.Agrement_Type,
        product: this.filter_fieldData.filter_Product,
        short_key: this.sort?this.sort.active:"",
        short_order: this.sort?this.sort.direction:"",
       
        start_date: this.filter_fieldData.filter_sent_date.start_date ? moment(this.filter_fieldData.filter_sent_date.start_date).format('YYYY-MM-DD') : '',
        end_date: this.filter_fieldData.filter_sent_date.end_date ? moment(this.filter_fieldData.filter_sent_date.end_date).format('YYYY-MM-DD') : '',
        counsellors:this.filter_fieldData.filter_Counsellor,
        salestype:this.salestype_Params
       }
       this.commonService.post('onboarding/getObUsersHistory',para)
       .subscribe((data:any) => {
        data.data.dataobject.forEach((ele:any,i:any) => {
          data.data.dataobject[i].selfIndex = i+1
        });

        params.successCallback(data.data.dataobject, data.data.count) 

         } )
         
     }
   }

  
  // this.arraydata.push({item:this.gridApi['paginationProxy'].masterRowCount})

   this.gridApi.setDatasource(this.datasource);   
    this.paginationpageset()
 }

 paginationpageset(){
  console.log(this.gridApi['paginationProxy'],'---=======---')
    console.log(this.gridApi.paginationProxy['bottomDisplayedRowIndex'],"-------****-----")

  
  for(var i = 10; i <= 138+50; i+=50 ){
    this.arraydata.push({item:i})
    // console.log(arraydata)
  }
 }
 
//ag gird bind data


//ag grid tree start

rowData2:any
getDataPath = function (data:any) {
  return data.hierachy;
};

private prepareData() {
  this.rowData2 = flattenChildrenRecursively(this.categoryData);
  console.log(
    'flattenChildrenRecursively : ',
    flattenChildrenRecursively(this.categoryData)
  );
}

categoryData = [
  {
    catId: 1,
    catName: 'Category - 1',
    children: [
      {
        children: [{
          catId: 3,
        catName: 'Sub child Category - 2',
        }],
        catName: 'Sub Category - 1',
      },
      {
        catId: 3,
        catName: 'Sub Category - 2',
      },
      {
        catId: 4,
        catName: 'Sub Category - 4',
      },
    ],
  },
  {
    catId: 4,
    catName: 'Category - 4',
    children: [
      {
        catId: 5,
        catName: 'Sub Category - 5',
      },
    ],
  },
  {
    catId: 6,
    catName: 'Category - 6',
    children: [],
  },
];
//ag - grid tree end

}
const flattenChildrenRecursively = (
  data:any,
  parent:any = null,
  childHierachy:any = null
) => {
  let newData:any = [];

  if (data) {
    data.forEach((initialRow:any, parentIndex:any) => {
      let parentHierachy:any = [];
      initialRow.hierachy = parentHierachy;

      if (parent) {
        initialRow.parent = parent;
        parentHierachy = [...childHierachy];
        initialRow.hierachy = parentHierachy;
      }
      parentHierachy.push(initialRow.catName);

      newData.push(initialRow);

      if (initialRow.children) {
        newData = [
          ...newData,
          ...flattenChildrenRecursively(
            initialRow.children,
            initialRow,
            parentHierachy
          ),
        ];
      }
    });
  }

  return newData;
};

function ServerSideDatasource(server:any) {
  console.log("server________",server)
  return {
    getRows: function(params:any) {
      console.log('[Datasource] - rows requested by grid: ', params.request);
      params.successCallback(server);

      // var response = server.getData(params.request);
      // setTimeout(function() {
      //   if (response.success) {
      //     params.successCallback(response.rows, response.lastRow);
      //   } else {
      //     params.failCallback();
      //   }
      // }, 500);
    },
  };
}