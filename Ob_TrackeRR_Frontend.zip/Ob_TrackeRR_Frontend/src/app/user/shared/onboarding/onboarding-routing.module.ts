import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router'; 
 import { OnboardingComponent } from './onboarding.component';
import { GenerateFormComponent } from './pages/generate-form/generate-form.component';
import { GeneratePmpComponent } from './pages/generate-pmp/generate-pmp.component';
import { AggridetableComponent } from './pages/history/aggridetable/aggridetable.component';
import { HistoryComponent } from './pages/history/history.component';
import { PortfolioRequestComponent } from './pages/portfolio-request/portfolio-request.component';
import { RequestConfirmComponent } from './pages/request-confirm/request-confirm.component';
import { StatusFormComponent } from './pages/status-form/status-form.component';
 
 



const routes: Routes = [
 
  {
     path: '', component: OnboardingComponent,  
     data:{pageType:'onboarding'},  
     children: [   
      {path: 'generate', component: GenerateFormComponent ,data:{pageType:'onboarding', title: 'Generate Onboarding URL'}},
      {path: 'history/edit/:counsellor_id/:id', component: GenerateFormComponent ,data:{pageType:'onboarding', title: 'Edit Onboarding'}},

      {path: 'generate-pmp', component: GeneratePmpComponent ,data:{pageType:'onboarding', title: 'Generate Onboarding URL'}},
      {path: 'history/edit-pmp/:counsellor_id/:id', component: GeneratePmpComponent ,data:{pageType:'onboarding', title: 'Edit Onboarding'}},

      {path: 'history', component: HistoryComponent ,data:{pageType:'renewal',title: 'History Of Onboarding'}}, 
      {path: 'history/status/:id', component: StatusFormComponent ,data:{pageType:'onboarding', title: 'Onboarding Status'}},
      {path: '', redirectTo: 'history', pathMatch: 'full'}, 
      
      {path: 'portfolio-request', component: PortfolioRequestComponent ,data:{pageType:'renewal',title: 'Portfolio Request'}},
      {path: 'portfolio-request/:id', component: RequestConfirmComponent ,data:{pageType:'renewal',title: 'Portfolio Request'}},
  
      {path: 'sample', component: AggridetableComponent ,data:{pageType:'renewal',title: 'Portfolio Request'}},

    ], 
   
     },   
        
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
}) 
export class OnboardingRoutingModule { }


export const OnboardingModuleConst = [
    OnboardingComponent,
    GenerateFormComponent, 
    GeneratePmpComponent,
    HistoryComponent,
    StatusFormComponent,
    PortfolioRequestComponent,
    RequestConfirmComponent
   
];
