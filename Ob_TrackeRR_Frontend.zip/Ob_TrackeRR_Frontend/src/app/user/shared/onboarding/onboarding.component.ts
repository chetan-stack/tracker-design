import { Component, OnInit } from '@angular/core';
import { DataFactoryService } from 'src/services/factory/data-factory.service';

@Component({
  selector: 'app-onboarding',
  templateUrl: './onboarding.component.html',
  styleUrls: ['./onboarding.component.scss']
})
export class OnboardingComponent implements OnInit {

  constructor( 
    private dataFactory: DataFactoryService, 
  ) { 
   // this.dataFactory.setHeaderType('onboarding');
  }

  ngOnInit(): void {
  }
 
}
