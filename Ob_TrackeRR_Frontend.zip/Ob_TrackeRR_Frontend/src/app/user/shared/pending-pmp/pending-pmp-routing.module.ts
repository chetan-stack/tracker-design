import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PendingPmpComponent } from './pending-pmp.component';
import { PmpListComponent } from './pmp-list/pmp-list.component';

const routes: Routes = [ 
  {
    path: '', component: PendingPmpComponent,  
    data:{pageType:'PendingPmp'},   
     children: [    
              {path: 'list', component: PmpListComponent ,data:{title: 'Pending PMP'}}, 
              {path: '', redirectTo: 'list', pathMatch: 'full'},  
        ],   
     }, 
        
];   

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingPmpRoutingModule { }
export const PendingPmpModuleConst = [  
  PendingPmpComponent,  
  PmpListComponent
];