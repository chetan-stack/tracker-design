import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-pmp',
  templateUrl: './pending-pmp.component.html',
  styleUrls: ['./pending-pmp.component.scss']
})
export class PendingPmpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
