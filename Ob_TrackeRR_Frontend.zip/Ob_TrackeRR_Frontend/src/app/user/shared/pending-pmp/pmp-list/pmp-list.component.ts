import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core'; 
import { MatTableDataSource } from '@angular/material/table';
import {MatSort, Sort} from '@angular/material/sort'; 
 
import { ActivatedRoute } from '@angular/router';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2'; 
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';  
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators';


import { MatPaginator } from '@angular/material/paginator';
import { fromEvent, merge } from 'rxjs';
import { BreakpointObserver } from '@angular/cdk/layout';  
import * as moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
  
const filterForm:any = { 
  filter_Status:[], 
  filter_team_id:[],
  filter_payment_date:{
    start_date:null,
    end_date:null,
  }, 
 
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

@Component({
  selector: 'app-pmp-list',
  templateUrl: './pmp-list.component.html',
  styleUrls: ['./pmp-list.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    //{provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
})
export class PmpListComponent implements OnInit {
  getCurrentUser:any = {}; 
  pageType:string;
  moment = moment;  

  filter_Search:string = ""; 
  filter_fieldData:any = JSON.parse(JSON.stringify(filterForm));
  filter_ApplyedCount:any = 0;


  gridDataSource = new MatTableDataSource(); 
  displayedColumns:any = [
    "id",
    "customer_name", 
    "lead_id",
    "email_id",
    "counsellor_name",
   // "onboarding_type",
    //"center",
    //"booking_amount",
    //"amount_received", 
    //"payment_received_date", 
   // "payment_mode", 
    //"status", 
    //"action"  
  ]
  
counsellor_name: "Raj Mehta"
customer_email_id: "stg_new226@yopmail.com"
customer_id: 1000408
customer_name: "Testing_14919"
lead_id: 14919
 

  salesType_list:any = {};
  access_list:any=[];
  team_list:any=[];

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}  
  product_label:any={};
  product_color:any = {};
 
  storedAllData: any; 

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver, 
    private dialog: MatDialog ,
  ) {

    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
       
    this.salesType_list = this.dataFactory.salesType_list;  

    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon;
    this.product_color = this.dataFactory.all_product_color;
    this.product_label = this.dataFactory.all_product_label;
    

    this.dataFactory.get_TeamList().subscribe((res: any[]) => { 
      if(res.length>0){ 
        this.team_list = res;
        // let teamData = res.filter((elm:any) => elm.id == Number(this.team_Params))[0];  
        // this.access_list =  teamData.access_id;
        // this.loadGrid_Data();  
      } 
   })
 

    this.loadGrid_Data();

   }
 
  ngOnInit(): void {
    
  }
  ngAfterViewInit(): void {
  

    fromEvent(this.textSearch_main.nativeElement, 'keyup').pipe(debounceTime(250),distinctUntilChanged(),tap(() => {
      debugger
      this.paginator.pageIndex = 0,
       this.loadGrid_Data();
    })
  ).subscribe();
  
  
  
      // reset the paginator after sorting
   this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
  
   // on sort or paginate events, load a new page
   merge(this.sort.sortChange, this.paginator.page)
   .pipe(
       tap(() => this.loadGrid_Data())
   )
   .subscribe();
  }
 

  onFilterGrid() { 
      this.loadGrid_Data();
  }

  onFilter_PaymentDateRange_Grid(data:any){ 
    if(data.value){
      this.onFilterGrid()
    }
  }

  
  loadGrid_Data() { 

    let dataOption:any = {
      search: this.filter_Search,
      status: this.filter_fieldData.filter_Status, 
      team_id:this.filter_fieldData.filter_team_id,
      payment_from_date: this.filter_fieldData.filter_payment_date.start_date ? moment(this.filter_fieldData.filter_payment_date.start_date).format('YYYY-MM-DD') : '', 
      payment_to_date: this.filter_fieldData.filter_payment_date.end_date ? moment(this.filter_fieldData.filter_payment_date.end_date).format('YYYY-MM-DD') : '',
      short_key: this.sort?this.sort.active:"",
      short_order: this.sort?this.sort.direction:"",
      page: this.paginator?this.paginator.pageIndex:0,
      perpage: this.paginator?this.paginator.pageSize:20,
     }
  
        
   
  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('sales/getPMPSalesNotDoneList',dataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      if(res.status){
        this.storedAllData = res.data;
        this.bindGridData(res.data);
      }else{
        this.storedAllData = undefined;
        this.bindGridData([]);
      }
  
    })



    let fData = this.filter_fieldData;
 
    let fCount:any = 0;
     Object.keys(fData).forEach(function (key) {
       let obVar = fData[key];
       if(Array.isArray(obVar) && obVar.length>0){ 
         fCount=fCount+1; 
       }else if (typeof obVar === 'object' && !Array.isArray(obVar) && obVar !== null && Object.values(obVar).length>0){
          if(Object.values(obVar).filter((v) => v).length>0){
           fCount=fCount+1; 
          } 
       }else if(obVar && obVar!=''){
         fCount=fCount+1; 
       }else{ 
       }  
    });
    
    this.filter_ApplyedCount = fCount

  }

   
  bindGridData(data:any) {
    this.gridDataSource = new MatTableDataSource(data);
    this.gridDataSource.sort = this.sort;
    this.bindTableGridWidth();
  }
 
  
 

  refreshGrid(mode:any) {
     if(this.paginator){
      this.paginator.pageIndex = 0; 
      this.sort.active = "";
      this.sort.direction = ""; 
    
      this.filter_Search="";
      this.filter_fieldData = JSON.parse(JSON.stringify(filterForm));
    }
    
  
  if(mode=="reset"){
    this.loadGrid_Data();
  }
    
  
  }

 
  openDialogUserInfo(element:any){
    debugger
    // const dialogRef = this.dialog.open(ViewUserInfoComponent, {
    //   height: 'auto',
    //   width: '610px',
    //   data: {
    //     name:element.customer_full_name,
    //     email:element.customer_email_id,
    //     phone:element.customer_phone_no
    //   }, 
    // });
  }

 
 


  addUser(){
    debugger
  }
 


  bindTableGridWidth(){
    debugger
 
    let w = 0;  
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number  = string.replace("%", ""); 
      w = w + Number(number);
    } 
 
    if(this.data_table._elementRef.nativeElement){
      this.data_table._elementRef.nativeElement.style.minWidth = w+'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w+'px';
       
    }   
     
  }
 
  showRemarkHistory(element:any){
 
    debugger 
    // let dialogRef; 
   
    // this.commonService.post('autopayment/getEnachSkipComments',{enach_dtl_id:element.enach_dtl_id}).subscribe((res:any) => {  
    //   debugger 
    //   if(res.status){ 
    //       dialogRef = this.dialog.open(RemarkHistoryComponent, {
    //         height: 'auto',
    //         width: '900px',
    //         data: {title:'e-Nach Status Remarks History', data:res.data}, 
    //       });
    //   }else{
    //     this.serviceFactory.notification(res.message,res.status); 
    //   }
      
  
    // }) 
  
  
     
  }
  jsonS(data:any){
    return data?JSON.stringify(data):""    
  
  }
}
