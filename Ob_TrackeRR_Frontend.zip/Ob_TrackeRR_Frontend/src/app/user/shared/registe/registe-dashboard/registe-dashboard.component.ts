import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';

@Component({
  selector: 'app-registe-dashboard',
  templateUrl: './registe-dashboard.component.html',
  styleUrls: ['./registe-dashboard.component.scss']
})
export class RegisteDashboardComponent implements OnInit  {

  getCurrentUser:any = {};

  constructor(
    private router: Router,
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService,
    public commonService: CommonService,
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }

  ngOnInit(): void {
  }

  // onchange() {
  //   // this.router.navigateByUrl('/sales-details');
  //   this.router.navigate(['registe/sales-details'])
  //   window.scrollTo(0,0);
  // }
  // center_per() {
  //   // this.router.navigateByUrl('/center-performance');
  //   this.router.navigate(['registe/center-performance'])
  //   window.scrollTo(0,0);
  // }
  // counselor_per() {
  //   // this.router.navigateByUrl('/counselor-performance');
  //   this.router.navigate(['registe/counselor-performance'])
  //   window.scrollTo(0,0);
  // }

  // manager() {
  //   this.router.navigate(['registe/manager-counsellor'])
  //   window.scrollTo(0,0);
  // }


}
