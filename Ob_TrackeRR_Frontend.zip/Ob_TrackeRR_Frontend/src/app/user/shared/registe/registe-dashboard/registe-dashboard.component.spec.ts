import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisteDashboardComponent } from './registe-dashboard.component';

describe('RegisteDashboardComponent', () => {
  let component: RegisteDashboardComponent;
  let fixture: ComponentFixture<RegisteDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RegisteDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisteDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
