import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CenterPerformanceComponent } from './center-performance/center-performance.component';
import { CounselorPerformanceComponent } from './counselor-performance/counselor-performance.component';
import { ManagerCounsellorComponent } from './manager-counsellor/manager-counsellor.component';
import { RegisteDashboardComponent } from './registe-dashboard/registe-dashboard.component';
import { RegisteComponent } from './registe.component';
import { SalesDetailsComponent } from './sales-details/sales-details.component';

const routes: Routes = [
  // { path: 'sales-details', component: SalesDetailsComponent, data: {title: 'Sales Detail' }},
  // { path: 'center-performance', component: CenterPerformanceComponent, data: {title: 'Center- Performance' }},
  // { path: 'counselor-performance', component: CounselorPerformanceComponent, data: {pageType:'registe', title: "Counselor-Performance" }},
  // { path: 'manager-counsellor', component: ManagerCounsellorComponent, data: {pageType:'registe', title: "Manager-Counsellor" }},
  // {path: '', component: RegisteDashboardComponent, data: {pageType:'registe', title: 'Sales Detail' }},   

  {
    path: '', component: RegisteComponent,
    data:{pageType:'register'},
     children: [    
            {path: '', component: RegisteDashboardComponent, data: {title: 'Register' }},
            { path: 'sales-details', component: SalesDetailsComponent, data: {title: 'Sales Detail' }},
            { path: 'center-performance', component: CenterPerformanceComponent, data: {title: 'Center- Performance' }},
            { path: 'counselor-performance', component: CounselorPerformanceComponent, data: {title: "Counselor-Performance" }},
            { path: 'manager-counsellor', component: ManagerCounsellorComponent, data: {title: "MoM-Performance" }},           
        ],  
     }, 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RegisteRoutingModule { }

export const RegisteModuleConst = [  
  RegisteComponent,
  RegisteDashboardComponent,
  SalesDetailsComponent,
  CenterPerformanceComponent,
  CounselorPerformanceComponent,
  ManagerCounsellorComponent 
];
