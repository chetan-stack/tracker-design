import { DatePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
 

const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-counselor-performance',
  templateUrl: './counselor-performance.component.html',
  styleUrls: ['./counselor-performance.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    DatePipe
  ],
})
export class CounselorPerformanceComponent implements OnInit {
  displayedColumns: string[] = ['sNo', 'counsellor_name', 'tenure', 'total_revenue',  'total_sales' , 'lead', 'conversion', 'workable_count' , 'non_workable_count' , 'arpa' , 'combos_sold' , 'combo_sold_vs_total_sales', 'fif_sold', 'fif_sold_vs_total_sales', 'mpo_sold', 'mpo_sold_vs_total_sales', 'dwn_sold', 'dwn_sold_vs_total_sales', 'pmp_sold', 'pmp_sold_vs_total_sales'  ];
  dataSource:any;

  displayLtColumn: string[] = [
    "sNo",
    "counsellor_name",
    "total_revenue",
    "total_sales",
    "arpa",
    "first_tranch_revenue",
    "arft",
    "Secret_Pitched",
    "Secret_Sold",
    "total_secret_amount",
    "agreement_not_generated",
    "agreement_not_accepted"
  ];
  dataSource_lt:any;

  displayedColumns_dwn: string[] = ['sNo', 'counsellor_name', 'tenure', 'total_revenue', 'total_sales' , 'workable_count' , 'non_workable_count' , 'arpa' , 'combos_sold' , 'combo_sold_vs_total_sales', 'fif_sold', 'fif_sold_vs_total_sales', 'mpo_sold', 'mpo_sold_vs_total_sales', 'dwn_sold', 'dwn_sold_vs_total_sales', 'pmp_sold', 'pmp_sold_vs_total_sales'  ];
  dataSource_dwn:any;
  displayedColumns_renewal: string[] = ['sNo', 'counsellor_name', 'Tenure', 'Lead_Size', 'totale-sales', 'Total_Rev' , 'Total_No_of_Non_LT' , 'Revenue_of_Non_LT' , 'ARPA_Non_LT_Excl_GST', 'Conv_Rate', 'Combos_Sold', 'Combo_Sold1', '5in5_Sold', '5in5_Sold1', 'MPO_Sold', 'MPO_Sold1', 'Dhanwaan_Sold', 'Dhanwaan_Sold1' , 'Total_PMP' , 'Total_revenue' , 'revenue_First_Tranch' ,'PMP_Sold' , 'ARPA_Excl_GST' , 'ARFT' ];
  dataSource_renewal:any;
  getCurrentUser:any = {};
  counsellorListArray:any = []

  counselorList:any = []
  growth:any = {}
  year_months_list:any = []
  from_date:any;
  to_date:any;
  
  @ViewChild(MatSort) sort: MatSort;


  convertMonth:any = {
    January: "01",
    February:"02",
    March:"03",
    April:"04",
    May:"05",
    June:"06",
    july:"07",
    August:"08",
    September:"09",
    October:"10",
    November:"11",
    December:"12"
  }
  selectedMonth:any;
  selectedYear = new Date().getFullYear().toString();

  initialDatePicker:any;

  todayDate = new Date();
  minDate = moment("2020-01-01").format("YYYY-MM-DD");

  start_date = moment().subtract(1, 'M').format('YYYY-MM-DD');
  end_date = moment(new Date()).format('YYYY-MM-DD');

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService,
    public commonService: CommonService,
    private incentiveService: IncentiveService,
    private serviceFactory: ServiceFactory,
   // private loginService: LoginService,
    ) { 
      debugger
      this.getCurrentUser = this.commonService.getCurrentUser();
      let PageTitle = route.snapshot.data['title'];
      this.dataFactory.setPageTitle({PageTitle: PageTitle});
      this.selectedMonth = (this.convertMonth[new Date().toLocaleString('default', { month: 'long' })]).toString();
      
       this.initialDatePicker = this.selectedYear+'-'+this.selectedMonth+'-'+'01';
  }
  

  ngOnInit(): void {
    this.counsellorPerformance();
    this.counsellor_List1();
    // this.counselor_per_list();  
  }

  counsellorPerformance() {
    debugger
    this.start_date = moment().subtract(1, 'M').format('YYYY-MM-DD');
    this.end_date = moment(new Date()).format('YYYY-MM-DD');

    if(this.getCurrentUser.team_id==4 ) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('pmp/counsellorPerformance',{

      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.counselorList = data.result;
        this.lt_bind_userlist_Data(data.result['sales_data']);
      })
     
    }else if(this.getCurrentUser.team_id == 2 ) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('renewal/counsellorPerformance',{

      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.counselorList = data.result;
        this.rene_bind_userlist_Data(data.result['sales_data']);
      })
     
    }
     else if(this.getCurrentUser.team_id==3) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet(`dwn/counsellorPerformance?start_date=${this.start_date}&end_date=${this.end_date}`).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.counselorList = data.result;
        this.dwn_bind_userlist_Data(data.result['sales_data']);
      })
    } else {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('counsellorPerformance',{

      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.counselorList = data.result;
        this.bind_userlist_Data(data.result['sales_data']);
      })
    }

    console.log(this.counselorList);
    
    
  }

 

  rangeSelector(startDate:any, endDate:any) {
    debugger
  }
  counsellor_List1() {
    this.incentiveService.RGet("counsellorList?search= ").subscribe((data)=> {
      this.counsellorListArray = data.result;
    })
  }

  dateRangeChange(dateRangeStart: HTMLInputElement, dateRangeEnd: HTMLInputElement) {
    debugger
    this.from_date = dateRangeStart.value;
    this.to_date = dateRangeEnd.value

    
    
    
  }

  onSubmit(form:any) {
    debugger
    let month = form.value.selectedMonth
    let year = form.value.selectedYear

    this.initialDatePicker = year + '-' + month + '-' + "01";

    let start_date = moment(form.value.from_date).format('YYYY-MM-DD');
    let end_date = moment(form.value.to_date).format('YYYY-MM-DD');
    let num_months = form.value.select_months
    let counsellor_id = form.value.coonselor_list


    if(this.getCurrentUser.team_id==4) {

      if(form.value.from_date || form.value.to_date) {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/counsellorPerformance',{
          "number_of_months": num_months,
          "start_date": start_date?start_date: "",
          "end_date": end_date?end_date: "" ,
          "counselor_list": counsellor_id?counsellor_id: null,
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.counselorList = data.result;
          this.lt_bind_userlist_Data(data.result['sales_data']);
        })
      } else {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/counsellorPerformance',{
          "number_of_months": num_months,
          "counselor_list": counsellor_id?counsellor_id: null,
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.counselorList = data.result;
          this.lt_bind_userlist_Data(data.result['sales_data']);
        })
      }
      
    }if(this.getCurrentUser.team_id==2) {

      if(form.value.from_date || form.value.to_date) {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('renewal/counsellorPerformance',{
          "number_of_months": num_months,
          "start_date": start_date?start_date: "",
          "end_date": end_date?end_date: "" ,
          "counselor_list": counsellor_id?counsellor_id: null,
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.counselorList = data.result;
          this.rene_bind_userlist_Data(data.result['sales_data']);
        })
      } else {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('renewal/counsellorPerformance',{
          "number_of_months": num_months,
          "counselor_list": counsellor_id?counsellor_id: null,
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.counselorList = data.result;
          this.rene_bind_userlist_Data(data.result['sales_data']);
        })
      }
      
    }
     else if(this.getCurrentUser.team_id==3) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet(`dwn/counsellorPerformance?start_date=${this.start_date}&end_date=${this.end_date}`).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.counselorList = data.result;
        this.dwn_bind_userlist_Data(data.result['sales_data']);
      })
    } else {
      if(form.value.from_date || form.value.to_date){
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('counsellorPerformance',{
          "number_of_months": num_months,
          "start_date": start_date?start_date: " ",
          "end_date": end_date?end_date: " " ,
          "counselor_list": counsellor_id?counsellor_id: null,
  
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.counselorList = data.result;
          this.bind_userlist_Data(data.result['sales_data']);
        })
      } else{
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('counsellorPerformance',{
          "number_of_months": num_months,
          "counselor_list": counsellor_id?counsellor_id: null,
  
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.counselorList = data.result;
          this.bind_userlist_Data(data.result['sales_data']);
        })
      }
     
    }
  }

  clear(form:any) {
    debugger
    form.reset();
    this.counsellorPerformance();
  }


  bind_userlist_Data(data:any) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    // this.dataSource.sort = this.sort;
  }

  lt_bind_userlist_Data(data:any) {
    this.dataSource_lt = new MatTableDataSource(data);
    this.dataSource_lt.sort = this.sort;
  }

  dwn_bind_userlist_Data(data:any) {
    this.dataSource_dwn = new MatTableDataSource(data);
    this.dataSource_dwn.sort = this.sort;
  }
  rene_bind_userlist_Data(data:any) {
    this.dataSource_renewal = new MatTableDataSource(data);
    this.dataSource_renewal.sort = this.sort;
  }
}
