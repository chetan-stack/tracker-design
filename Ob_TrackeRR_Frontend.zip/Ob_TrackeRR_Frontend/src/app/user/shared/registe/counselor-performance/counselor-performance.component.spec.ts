import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CounselorPerformanceComponent } from './counselor-performance.component';

describe('CounselorPerformanceComponent', () => {
  let component: CounselorPerformanceComponent;
  let fixture: ComponentFixture<CounselorPerformanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CounselorPerformanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CounselorPerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
