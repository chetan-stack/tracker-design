import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrachesComponent } from './traches.component';

describe('TrachesComponent', () => {
  let component: TrachesComponent;
  let fixture: ComponentFixture<TrachesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrachesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrachesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
