import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-traches',
  templateUrl: './traches.component.html',
  styleUrls: ['./traches.component.scss']
})
export class TrachesComponent implements OnInit {
  displayedColumns: string[] = ['sNo' , 'amount', 'date' ];
  // tranches: any ={}
  datasourse_tranches : any;
  tranches = []

  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<TrachesComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
  ) { 
    this.tranches = dialogData;
    console.log(this.tranches);
    this.bindTranch(this.tranches);
    
  }

  ngOnInit(): void {
  }

  bindTranch(data: any) {
    this.datasourse_tranches = new MatTableDataSource(data);
  }
}
