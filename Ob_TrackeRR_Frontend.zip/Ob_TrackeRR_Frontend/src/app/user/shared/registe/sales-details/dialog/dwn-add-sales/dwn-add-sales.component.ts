import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { IncentiveService } from 'src/services/api/informed.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
 
@Component({
  selector: 'app-dwn-add-sales',
  templateUrl: './dwn-add-sales.component.html',
  styleUrls: ['./dwn-add-sales.component.scss']
})
export class DwnAddSalesComponent implements OnInit {

  dataListObj:any = {}
  userData:any = {}
  title: string = 'ADD SALES';
  action: String = 'Add';
  enablePlaceholder: boolean = true;

  separateDialCode = false;
  dropdoemData:any
  passforshow:any
  apiMessage:any
  isMessage = false;
  lead_age = []
  priceExcludingGST:any
  

  selectedSameMonth: any

  counsellerList:any = []
  productListArray:any = []
  status_workable:any;
  status_tenure_extended:any;
  discount_value:any;
  status_iir:any;
  plan_duration:any;

  constructor(
    // private userManagementService: UserManagementService,
    private serviceFactory: ServiceFactory,
    private incentiveService: IncentiveService,
    public dialogRef: MatDialogRef<DwnAddSalesComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData:any
    ) {
    if (dialogData) {
      // debugger
      if (this.dialogData.type == 'edit') {
        this.userData = dialogData.element;
        this.status_workable = this.userData['status_workable'].toString();
        this.status_tenure_extended = this.userData['status_tenure_extended'].toString();
        this.status_iir = this.userData['status_iir'].toString();
        this.discount_value = this.userData['discount_value'].toString();
        this.plan_duration = this.userData['plan_duration'].toString();

      }
    }
  }

  ngOnInit(): void {
    this.counsellorPopup();
    this.productList();
    // this.data_list();
    // this.addUserDropdown();
    if (this.dialogData.type == 'edit') {
      this.title = 'EDIT SALES';
      this.action = 'Proceed';
      this.passforshow = "*****"
    } else {
      this.title = 'ADD SALES';
      this.action = 'Add';
    }
  }

  counsellorPopup() {
    this.incentiveService.RGet('counsellorPopup').subscribe((data)=> {
      this.counsellerList = data.result;
    })
  }

  productList() {
    this.incentiveService.RGet('productList').subscribe((data)=> {
      this.productListArray = data.result;
    })
  }


  
  hasErrorPhone(formData:any, name:any, hasAction:any) {
    // debugger
    if (!hasAction) {
      formData.form.controls[name].setErrors({ 'incorrect': true });
    } else {
      formData.form.controls[name].setErrors(null);
    }

  }

  // data_list(){
  //   this.commonService.list_data().subscribe((data)=> {
  //     this.dataListObj = data.result;
  //     console.log(data);
  //   })
  // }


  // onDismiss() {
  //   this.dialogRef.close(false);
  // }

  

  addUserDropdown() {
    // this.userManagementService.addUserDropdown().subscribe((data) => {
    //   this.dropdoemData = data.result;
    // })
  }

  changeAgent() {
    // debugger
  }
  keyPress(event: any) {
    debugger
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }


  getvalue(event:any,form:any) {
    debugger
    this.lead_age = event.target.value;
    this.selectedSameMonth = undefined;
    let date = form.value.SaleDate.getDate();
    console.log(this.lead_age);
    console.log(date);


    let leadAge = Number(this.lead_age);
    
    if(leadAge>0) {
      if(date - leadAge >=1) {
        this.selectedSameMonth = "Yes";
        // this.lead_age = []
      } else {
        this.selectedSameMonth = "No";
        // this.lead_age = []
      } 
    } else {
      this.selectedSameMonth = ""
    }
   
  }


  getsalling(event:any){
    var sallingprice = event.target.value;
    // let gst = (sallingprice * 82)/118;
    this.priceExcludingGST = (sallingprice * 82)/118;
    console.log(this.priceExcludingGST);

  }

  onConfirm(form:any) {
    // debugger

    if (this.dialogData.type == 'edit') {
      
      let formData = form.value;
      this.incentiveService.RPost('dwn/addNewSale',{
        "record_id": this.userData['record_id'],
        "lead_id" : formData['lead_id'],
        "sale_date": moment(formData['sale_date']).format('YYYY-MM-DD'),
        "counsellor_id": formData['counsellor_id'],
        "customer_name": formData['customer_name'],
        "customer_email": formData['customer_email'],
        "customer_phone": formData['customer_phone'],
  
        "lead_age": formData['lead_age'],
        "status_workable": Number(formData['status_workable']),
        // "LeadType": formData['LeadType'],
        "product_id": formData['product_id'],
        "plan_duration": formData['plan_duration'],
        // "SellingPrice": Number(formData['SellingPrice']),
        "price_excluding_gst": formData['price_excluding_gst'],
        // "tranches_count": formData['tranches_count'],
        // "tranches_duration": Number(formData['tranches_duration']),
  
        "status_tenure_extended": Number(formData['status_tenure_extended']),
        // "status_challenge": Number(formData['status_challenge']),
        // "status_refund": Number(formData['status_refund']),
        // "status_gift_share": Number(formData['status_gift_share']),
        // "upgrade_amount": Number(formData['upgrade_amount']),
        "extended_duration": Number(formData['extended_duration'])? Number(formData['extended_duration']): 0,
        "status_iir": Number(formData['status_iir']),
        "iir_selling_price": Number(formData['iir_selling_price'])? Number(formData['iir_selling_price']): 0,
        "discount_value": formData['discount_value']
      }).subscribe((data)=> {
        console.log(data);
        if (data.status) {
          this.serviceFactory.notification(data['message'], data['status']);
          this.dialogRef.close(data);
        }
      })

    } else {
      debugger
      let formData = form.value;
      this.incentiveService.RPost('dwn/addNewSale',{
        "lead_id" : formData['lead_id'],
        "sale_date": moment(formData['sale_date']).format('YYYY-MM-DD'),
        "counsellor_id": formData['counsellor_id'],
        "customer_name": formData['customer_name'],
        "customer_email": formData['customer_email'],
        "customer_phone": formData['customer_phone'],
  
        "lead_age": formData['lead_age'],
        "status_workable": Number(formData['status_workable']),
        // "LeadType": formData['LeadType'],
        "product_id": formData['product_id'],
        "plan_duration": formData['plan_duration'],
        // "SellingPrice": Number(formData['SellingPrice']),
        "price_excluding_gst": formData['price_excluding_gst'],
        // "tranches_count": formData['tranches_count'],
        // "tranches_duration": Number(formData['tranches_duration']),
  
        "status_tenure_extended": Number(formData['status_tenure_extended']),
        // "status_challenge": Number(formData['status_challenge']),
        // "status_refund": Number(formData['status_refund']),
        // "status_gift_share": Number(formData['status_gift_share']),
        // "upgrade_amount": Number(formData['upgrade_amount']),
        "extended_duration": Number(formData['extended_duration'])? Number(formData['extended_duration']): 0,
        "status_iir": Number(formData['status_iir']),
        "iir_selling_price": Number(formData['iir_selling_price'])? Number(formData['iir_selling_price']): 0,
        "discount_value": formData['discount_value']
      }).subscribe((data)=> {
        console.log(data);
        if (data.status) {
          this.serviceFactory.notification(data['message'], data['status']);
          this.dialogRef.close(data);
        }
        
      })
    }
  }
  
}