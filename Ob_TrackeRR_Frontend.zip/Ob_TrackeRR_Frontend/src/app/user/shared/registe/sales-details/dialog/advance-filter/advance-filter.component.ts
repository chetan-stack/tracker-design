import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';
import { IncentiveService } from 'src/services/api/informed.service';
 
@Component({
  selector: 'app-advance-filter',
  templateUrl: './advance-filter.component.html',
  styleUrls: ['./advance-filter.component.scss']
})
export class AdvanceFilterComponent implements OnInit {

  select_Filter_list: any[] = [
    { value: 'counsellor_id', viewValue: 'Counsellor Name' },
    { value: 'sales_date', viewValue: 'Sales Date' },
    { value: 'lead_age', viewValue: 'Lead Age' },
    { value: 'status_same_month', viewValue: 'Same Month' },
    { value: 'product', viewValue: 'Product Type' },
    { value: 'duration', viewValue: 'Subscription Plane in Year' },
    { value: 'amount', viewValue: 'Price Excluding GST' },
    { value: 'tranches_count', viewValue: 'Number Of Tranches' },
    { value: 'tenure_extended', viewValue: 'Tenure Extended' },
    { value: 'duration', viewValue: 'Duration Offered' },
    { value: 'discount_status', viewValue: 'Discount Provided' },
  ];

  formFilter_Data = {}
  filterArray = [];
  // operator = "and";
  prevFilter
  filterData;
  rightFilterStatementArr = []
  overviewData = {
    advance_filters: {}
  }
  transition_type
  statement: string;

  //----------------- variables for selected edit obj -----selected----------------------//

  didEditSelected = false;
  selectedIndex = 0;

  selectedType:any;
  selectedCategory:any;
  start_date:any;
  end_date:any;
  selectedComparator:any;
  selectedValue:any;
  selectedStatus:any;
  selectedStatus1:any;
  selectedProduct:any;

  counsellorListArray:any = []
  productListArray:any = []

  constructor(
    private dialog: MatDialog,
    private incentiveService: IncentiveService,
    public dialogRef: MatDialogRef<AdvanceFilterComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    debugger
    this.prevFilter = data.formData;
    this.overviewData = data.overviewData;
    // this.advnceFilterArary = data.Advancefilter_Array
    if (data.overviewData.advance_filters) {
      this.filterData = data.overviewData;
      // this.operator = this.filterData.operator;
    }
    
    this.transition_type = data.type;
  }

  ngOnInit(): void {
    this.counsellorList();
    this.productList();
  }

  counsellorList() {
    this.incentiveService.RGet("counsellorList?search= ").subscribe((data)=> {
      this.counsellorListArray = data.result;
    })
  }

  productList() {
    this.incentiveService.RGet('productList').subscribe((data)=> {
      this.productListArray = data.result;
    })
  }

  changeFilter(event:any) {
    debugger
    // this.operator = event.value;
  }

  addFilter(form:any) {
    debugger

    // Give me all the stocks which is live without transition.
    // Give me all the stocks which is live with transition.

    if(form.value.filter_type == 'counsellor_id') {
      this.statement = "Give me all the list of Counsellors " + form.value.value_list;
    } 
    else if(form.value.filter_type == 'sales_date') {
      this.statement = "Give me all the Sales created from " + moment(form.value.start_date).format('DD MMM YYYY') + " to " + moment(form.value.end_date).format('DD MMM YYYY')
    }
    else if(form.value.filter_type == 'lead_age'  || form.value.filter_type == 'duration' || form.value.filter_type == 'amount' || form.value.filter_type == 'tranches_count' || form.value.filter_type == 'tenure_extended') {
      this.statement = "Give me all the sales " + form.value.comparator + form.value.value
    }
    else if(form.value.filter_type == 'status_same_month' || form.value.filter_type == 'status_tenure_extended') {
      this.statement = "Give me sales of " + form.value.filter_type + form.value.status
    } 
    else if(form.value.filter_type == 'product') {
      this.statement = "Give me all the list of Products " + form.value.value_list;
    } 
    else if(form.value.filter_type == 'discount_status') {
      this.statement = "Give me disscount status " + form.value.filter_type + " " + form.value.status1
    } 
   

    if (this.didEditSelected) {
      this.updateObjectForAPI(form, this.selectedIndex)
    } else {
      this.createObjectForAPI(form)
    }

    this.didEditSelected = false;
    this.selectedIndex = 0;

    this.selectedType = null;
    this.selectedCategory = null;
    this.start_date = null;
    this.end_date = null;
    this.selectedComparator = null;
    this.selectedValue = null;
    this.selectedStatus = null;
    this.selectedStatus1 = null;
    this.selectedProduct = null;


    // this.rightFilterStatementArr.push(this.statement);
  }

  updateObjectForAPI(form:any, index:any) {
    debugger
    if (!this.filterData) {
      this.filterData = {
        advance_filters: []
      }
    }

    if(form.value['filter_type'] == 'counsellor_id' || form.value.filter_type == 'product') {

      let counsellorArr:any = []
      form.value['value_list'].forEach((element: any) => {
        counsellorArr.push(Number(element));
      });

      this.filterData["advance_filters"][index] = ({
        filter_type: form.value['filter_type'], 
        value_list: counsellorArr,
        statement: this.statement
      })
    } else if(form.value.filter_type == 'sales_date') {
      this.filterData["advance_filters"][index] = ({
        filter_type: form.value['filter_type'], 
        start_date: moment(form.value['start_date']).format('YYYY-MM-DD'),
        end_date: moment(form.value['end_date']).format('YYYY-MM-DD'),
        statement: this.statement
      })
    } else if(form.value.filter_type == 'lead_age'  || form.value.filter_type == 'duration' || form.value.filter_type == 'amount' || form.value.filter_type == 'tranches_count' || form.value.filter_type == 'tenure_extended' || form.value.filter_type == 'discount_value') {
        this.filterData["advance_filters"][index] = ({
          filter_type: form.value['filter_type'], 
          comparator: form.value['comparator'],
          value: form.value['value'],
          statement: this.statement
        })
    } else if(form.value.filter_type == 'status_same_month' || form.value.filter_type == 'tenure_extended') {
      this.filterData["advance_filters"][index] = ({
        filter_type: form.value['filter_type'], 
        status: Number(form.value['status']),
        statement: this.statement
      })
    }
    else if(form.value.filter_type == 'discount_status') {
      this.filterData["advance_filters"][index] = ({
        filter_type: form.value['filter_type'], 
        status: Number(form.value['status1']),
        statement: this.statement
      })
    }
    // if(form.value['filter_type'] =='overperformed' || form.value['filter_type'] =='underperformed') {
      
    //   this.filterData["advance_filters"][index] = ({
    //       filter_type: form.value['filter_type'], 
    //       comparison_with: form.value['comparison_with'],
    //       value: form.value['value'],
    //       statement: this.statement
    //     })
    //   }
    //   else if(form.value['filter_type'] =='live' || form.value['filter_type'] =='exited') {
    //     this.filterData["advance_filters"][index] = ({
    //         filter_type: form.value['filter_type'], 
    //         transition_to: form.value['transition_to'],
    //         statement: this.statement
    //       })
    //   } 
    //   else if(form.value['filter_type'] =='fundamental_score') {
    //     this.filterData["advance_filters"][index] = ({
    //         filter_type: form.value['filter_type'], 
    //         value_start: form.value['value_start'],
    //         value_end: form.value['value_end'],
    //         statement: this.statement
    //       })
    //     }
  }

  createObjectForAPI(form:any) {
    debugger
    if (!this.filterData) {
      this.filterData = {
        advance_filters: []
      }
    }

    if(form.value['filter_type'] == 'counsellor_id' || form.value.filter_type == 'product') {

      let counsellorArr:any = []
      form.value['value_list'].forEach((element: any) => {
        counsellorArr.push(Number(element));
      });

      this.filterData["advance_filters"].push({
        filter_type: form.value['filter_type'], 
        value_list: counsellorArr,
        statement: this.statement
      })
    } else if(form.value.filter_type == 'sales_date') {
      this.filterData["advance_filters"].push({
        filter_type: form.value['filter_type'], 
        start_date: moment(form.value['start_date']).format('YYYY-MM-DD'),
        end_date: moment(form.value['end_date']).format('YYYY-MM-DD'),
        statement: this.statement
      })
    } else if(form.value.filter_type == 'lead_age'  || form.value.filter_type == 'duration' || form.value.filter_type == 'amount' || form.value.filter_type == 'tranches_count' || form.value.filter_type == 'tenure_extended' || form.value.filter_type == 'discount_value') {
        this.filterData["advance_filters"].push({
          filter_type: form.value['filter_type'], 
          comparator: form.value['comparator'],
          value: form.value['value'],
          statement: this.statement
        })
    } else if(form.value.filter_type == 'status_same_month' || form.value.filter_type == 'status_tenure_extended') {
      this.filterData["advance_filters"].push({
        filter_type: form.value['filter_type'], 
        status: Number(form.value['status']),
        statement: this.statement
      })
    }
    else if(form.value.filter_type == 'discount_status') {
      this.filterData["advance_filters"].push({
        filter_type: form.value['filter_type'], 
        status: Number(form.value['status1']),
        statement: this.statement
      })
    }

    // if(form.value['filter_type'] =='overperformed' || form.value['filter_type'] =='underperformed') {
      // this.filterData["advance_filters"].push({
      //     filter_type: form.value['filter_type'], 
      //     comparison_with: form.value['comparison_with'],
      //     value: form.value['value'],
      //     statement: this.statement
      //   })
    //   }
    //   else if(form.value['filter_type'] =='live' || form.value['filter_type'] =='exited') {
    //     this.filterData["advance_filters"].push({
    //         filter_type: form.value['filter_type'], 
    //         transition_to: form.value['transition_to'],
    //         statement: this.statement
    //       })
    //   } 
    //   else if(form.value['filter_type'] =='fundamental_score') {
    //     this.filterData["advance_filters"].push({
    //         filter_type: form.value['filter_type'], 
    //         value_start: form.value['value_start'],
    //         value_end: form.value['value_end'],
    //         statement: this.statement
    //       })
    //     }
  }

  editFilter(data:any,index:any) {
    debugger

    // let valueArray = [];

    // if (data.filter_type == "counsellor_id" || data.filter_type == "product_id") {
    //   if (data.value_list.length > 0) {
    //     data.value_list.forEach(element => {
    //       valueArray.push(element.toString())
    //     });
    //   }
    // }

    this.didEditSelected = true;
    this.selectedIndex = index;

    this.selectedType = data.filter_type;
    this.selectedCategory = data.value_list;
    this.start_date = data.start_date;
    this.end_date = data.end_date;
    this.selectedComparator = data.comparator;
    this.selectedValue = data.value;
    this.selectedStatus = data.status;
    this.selectedStatus1 = data.status1;
    this.selectedProduct = data.value_list;
  }

  deleteFilter(index: number) {
    debugger
    this.filterData["advance_filters"].splice(index, 1);
  }

  submit(form:any) {
    debugger

    if (!this.filterData) {
      this.filterData = {
        advance_filters: []
      }
    }
    // this.filterData.operator = form.value.operator;

    if(this.filterData && this.filterData['advance_filters'].length==0) {
      this.filterData = null
    }
    
    console.log(this.filterData);

    this.incentiveService.RPost('salesDetails',{
      "search": this.prevFilter,
      "advance_filters": this.filterData['advance_filters']
    }).pipe(
      finalize(() => {
        //this.serviceFactory.loadingStop(".sales-detail", "");
      })
    ).subscribe((data)=> {
      console.log(data);
      this.dialogRef.close(data);
    })
    
    // this.categoryService.categoryOverviewAPI({
    //   "stock_status": this.prevFilter.stock_status,
    //   "transition_type": this.transition_type,
    //   "mode": this.prevFilter.mode,
    //   "start_date": moment(this.prevFilter.start_date).format('YYYY-MM-DD'),
    //   "end_date": moment(this.prevFilter.end_date).format('YYYY-MM-DD'),
    //   "advance_filters": this.filterData
    // }).subscribe((data) => {
    //   console.log(data);
    //   this.dialogRef.close(data);
      
    // })

  }
}
