
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
// import { element } from 'protractor';
import { fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators';
// import { CommonService } from 'src/app/service/api/common.service'; 
//import { AddSalesComponent } from './dialog/add-sales/add-sales.component';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
// import { LoginService } from 'src/app/service/api/login.service';
//import { LtAddSalesComponent } from './dialog/lt-add-sales/lt-add-sales.component';
import { DwnAddSalesComponent } from './dialog/dwn-add-sales/dwn-add-sales.component';
import { AdvanceFilterComponent } from './dialog/advance-filter/advance-filter.component';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { IncentiveService } from 'src/services/api/informed.service';
//import { CommonService } from 'src/services/api/common.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { CommonService } from 'src/services/api/common.service';
import { TrachesComponent } from './dialog/traches/traches.component';

// export const MY_FORMATS = {
//   parse: {
//     dateInput: 'MM/YYYY',
//   },
//   display: {
//     dateInput: 'MM/YYYY',
//     monthYearLabel: 'MMM YYYY',
//     dateA11yLabel: 'LL',
//     monthYearA11yLabel: 'MMMM YYYY',
//   },
// };
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-sales-details',
  templateUrl: './sales-details.component.html',
  styleUrls: ['./sales-details.component.scss'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
export class SalesDetailsComponent implements OnInit {
  // displayedColumns: string[] = ['position', 'Lead Number', 'Sale Date' , 'Counselor Name' , 'Customer Name' , 'Email' , 'Contact Number' , 'Lead Age' , 'Same Month?' , 'Lead Type' , 'Product Type' , 'Subscription Plan in Years' , 'Selling Price' , 'Price Excluding GST' , 'Number of Tranches' , 'Tenure Extended ?' , 'Duration Offered' , 'Challenge Given ?' , 'Refund Given ?' ,'Gift Shares Given ?' , 'Upgrade Amount' , 'Count Calculated' , 'Lead Referred/Shared with team' , 'Lead Referred/Shared with Consellor' , 'Shared Revenue' , 'Discount Provided'];

  displayedColumns: string[] = ['position', 'lead_id', 'counsellor_name' , 'sale_date' ,'lead_age', 'status_same_month' , 'product_name' , 'plan_duration' , 'selling_price' , 'price_excluding_gst' , 'tranches_count' , 'status_tenure_extended' , 'extended_duration' , 'status_iir', 'iir_selling_price', 'discount_value' ];
  
  displayLtColumn: string[] = [
    'lead_id',
    'lead_No',
    'sale_date',
    'counsellor_name',
    'lead_centre_name',
    'cst_feedback',
    'onboarding_month',
    'first_product_name',
    'first_subscription_amount',
    'portfolio_type',
    'upgrade_product_name',
    'campaign_id',
    'status_revenue_shared',
    'center_revenue_shared',
    'counsellor_revenue_shared',
    'amount_revenue_shared',
    'premium_first_tranch',
    'revenue_first_tranch_bangalore',
    'final_selling_price',
    'amount_remaining',
    'Tenure_Tranches',
    'status_tranches_remaining',
    'count_tranches_remaining',
    'secrets_pitches',
    'status_secrets_sold',
    "Total Secret Amount",
    'status_agreement_generated',
    'status_agreement_accepted',
    // 'first_tranch_remaining_date',
    // 'second_tranch_remaining_amount',
    // 'second_tranch_remaining_date',
    // 'third_tranch_remaining_amount',
    // 'third_tranch_remaining_date',
    // 'other_tranch_remaining_amount',
    // 'other_tranch_remaining_date',
    
    
  ]

  displayedColumnsDWN: string[] = [
    'position', 
    'lead_id', 
    'customer_phone' , 
    'counsellor_name' , 
    'sale_date' ,
    'lead_age', 
    'status_same_month' , 
    'product_name' , 
    'plan_duration' , 
    'selling_price' , 
    'price_excluding_gst' , 
    'tranches_count' , 
    'status_tenure_extended' , 
    'extended_duration' ,
    'status_iir', 
    'iir_selling_price',
    'discount_value'
  ];

  getCurrentUser:any = {};

  Advancefilter_Array: any ={};
  dataSource_lt: any
  LTcommentList: any = []

  dataSource_dwn: any
  DWNcommentList: any
  dataSource: any
  commentList: any
  selectedMonthName: any
  year_months_list: any
  searchdt: any
  filter_type: any
  selected_month: any

  filterData:any = []
  isFilterData = false
  searchValue: any
  counsellor_count: any
  totale_revenue: any = 0;
  sp_excl_gst: any =0;

  @ViewChild(MatSort) sort: MatSort;

  @ViewChild('picker') datePicker: MatDatepicker<any>;


  select_filter_list: any[] = [
    { value: 'monthly', viewValue: 'Month' },
    { value: 'date_range', viewValue: 'Date Range' },
  ];

  form_filter_Data:any = {}
  date = new FormControl(moment());
  from_date: any
  to_date: any
  branch: any

  advance_filters: any
  overviewData:any = {};

  constructor(
    public commonService: CommonService,
     private serviceFactory: ServiceFactory,
     private dataFactory: DataFactoryService, 
    // private dialog: MatDialog,
    // private loginService: LoginService,
    private route:ActivatedRoute, 
    // private titlecasePipe:TitleCasePipe,
    private dialog: MatDialog,
    private incentiveService: IncentiveService,
    //private commonService: CommonService
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
    // this.branch = this.loginService.getBranch();
    
    
  }

  @ViewChild('search') input: ElementRef;

  openDatePicker(picker1: any) {
    debugger
    picker1.open();
    // this.selected_month = 
  }

  closeDatePicker(normalizedMonth: moment.Moment, datepicker: MatDatepicker<moment.Moment>) {
    debugger
    // this.selected_month = moment(eventData).format('YYYY-MM');
    // picker1.close();    
    const ctrlValue = this.date.value;
    ctrlValue.month(normalizedMonth.month());
    this.date.setValue(ctrlValue);
    datepicker.close();
  }
 
  chosenYearHandler(normalizedYear: moment.Moment) {
    const ctrlValue = this.date.value;
    ctrlValue.year(normalizedYear.year());
    this.date.setValue(ctrlValue);
  }

  chosenMonthHandler(normalizedMonth: moment.Moment, datepicker: MatDatepicker<moment.Moment>) {
    const ctrlValue = this.date.value;
    ctrlValue.month(normalizedMonth.month());
    this.date.setValue(ctrlValue);
    datepicker.close();
  }

  ngOnInit(): void {
    this.salesDetails(null);
  }

  // ngAfterViewInit() {
  //   debugger
  //   this.salesDetails();

  //   fromEvent(this.input.nativeElement, 'keyup')
  //     .pipe(
  //       debounceTime(250),
  //       distinctUntilChanged(),
  //       tap(() => {
  //         debugger
  //         this.commonService.salesDetails({"search": this.input.nativeElement.value,}).subscribe((data)=> {
  //           this.commentList = data;
  //           this.bind_userlist_Data(data.result);
  //           this.dataSource.sort = this.sort;
  //         })
  //       })
  //     )
  //     .subscribe();
  // }

  salesDetails(advance_filters: any) {
    debugger
    if(this.getCurrentUser.team_id== 4) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('pmp/salesDetails',{}).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data: any)=> {
        this.getNumbers(data)
        let array = data.result;
        this.counsellor_count = array.length;
        this.LTcommentList = data.result;
        this.lt_bind_userlist_Data(data.result);
        this.dataSource_lt.sort = this.sort;
      })
    } else if(this.getCurrentUser.team_id== 3) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");

      // this.commonService.DWNsalesDetails({}).subscribe((data)=> {
      //   this.DWNcommentList = data.result;
      //   this.dwn_bind_userlist_Data(data.result);
      //   this.dataSource_dwn.sort = this.sort;
      // })
      this.incentiveService.RPost('dwn/salesDetails',{
        "advance_filters": advance_filters,
        "search": this.searchValue
      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data: any)=> {
        let array = data.result;
        this.counsellor_count = array.length;
        this.commentList = data.result;
        this.dwn_bind_userlist_Data(data.result);
        this.dataSource_dwn.sort = this.sort;

        if(data['advance_filters'] != null) {
          this.isFilterData = true;
          this.filterData = data['advance_filters'];
        }
      })
    } else {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('salesDetails',{
        "advance_filters": advance_filters,
        "search": this.searchValue
      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data: any)=> {
        this.getNumbers(data)
        let array = data.result;
        this.overviewData = data;
        this.counsellor_count = array.length;
        this.commentList = data.result;
        this.bind_userlist_Data(data.result);
        this.dataSource.sort = this.sort;

        if(data['advance_filters'] != null) {
          this.isFilterData = true;
          this.filterData = data['advance_filters'];
        }
      })
    }
    
  }
  
  bind_userlist_Data(data: any) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    // this.dataSource.sort = this.sort;
  }

  lt_bind_userlist_Data(data: any) {
    this.dataSource_lt = new MatTableDataSource(data);
    this.dataSource_lt.sort = this.sort;
    // this.dataSource.sort = this.sort;
  }

  dwn_bind_userlist_Data(data: any) {
    this.dataSource_dwn = new MatTableDataSource(data);
    this.dataSource_dwn.sort = this.sort;
    // this.dataSource.sort = this.sort;
  }

  
  

  

  


  onSubmit(form: any) {
    debugger
    this.serviceFactory.loadingStart("body","Please wait while loading...","")
    let month = form.value.month
    let year = form.value.year

    this.selected_month = year + '-' + month + '-' + "01";

    if(this.getCurrentUser.team_id== 4) {
      if(form.value.filter_type == "monthly") {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/salesDetails',{
          "filter_type": "monthly",
          "selected_month": this.selected_month,
          "search": this.input.nativeElement.value
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data: any)=> {
          this.getNumbers(data)
          this.commentList = data.result;
          this.lt_bind_userlist_Data(data.result);
          this.dataSource.sort = this.sort;
        })
      } else {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/salesDetails',{
          "filter_type": "date_range",
          "from_date": moment(form.value.from_date).format('YYYY-MM-DD'),
          "to_date": moment(form.value.to_date).format('YYYY-MM-DD'),
          "search": this.input.nativeElement.value
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data: any)=> {
          this.getNumbers(data)
          this.commentList = data.result;
          this.lt_bind_userlist_Data(data.result);
          this.dataSource.sort = this.sort;
        })
      }
    } 
    
  }

  clear(searchdt: any) {
    this.input.nativeElement.value = '';
    searchdt.reset();
    this.isFilterData =false;
    this.salesDetails(null);

  }

  dateRangeChange(dateRangeStart: HTMLInputElement, dateRangeEnd: HTMLInputElement) {
    debugger
    this.from_date = dateRangeStart.value;
    this.to_date = dateRangeEnd.value

   // console.log(this.from_date);
   // console.log(this.to_date);
    
    
  }

  searchAPI(form: any, event: any) {
    debugger
    this.searchValue = event.target.value;
    this.serviceFactory.loadingStart("retails","Please wait while loading...","")
    if(this.getCurrentUser.team_id== 4) {
      if(form.value.filter_type == "monthly") {
        let month = form.value.month
        let year = form.value.year
        this.selected_month = year + '-' + month + '-' + "01";
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/salesDetails',{
          "filter_type": "monthly",
          "selected_month": this.selected_month,
          "search": event.target.value
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data: any)=> {
          this.getNumbers(data)
          let array = data.result;
        this.counsellor_count = array.length;
          this.commentList = data;
          this.lt_bind_userlist_Data(data.result);
          this.dataSource.sort = this.sort;
        })
      } else if(form.value.filter_type == "date_range"){
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/salesDetails',{
          "filter_type": "date_range",
          "from_date": moment(form.value.from_date).format('YYYY-MM-DD'),
          "to_date": moment(form.value.to_date).format('YYYY-MM-DD'),
          "search": event.target.value
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data: any)=> {
          this.getNumbers(data)
          let array = data.result;
          this.counsellor_count = array.length;
          this.commentList = data.result;
          this.lt_bind_userlist_Data(data.result);
          this.dataSource.sort = this.sort;
        })
      } else {
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RPost('pmp/salesDetails',{
          "search": event.target.value
        }).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data: any)=> {
          this.getNumbers(data)
          let array = data.result;
          this.counsellor_count = array.length;
          this.commentList = data.result;
          this.lt_bind_userlist_Data(data.result);
          this.dataSource.sort = this.sort;
        })
      }
    } else if(this.getCurrentUser.team_id== 3) {
      debugger
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('dwn/salesDetails',{
        "search": event.target.value,
        "advance_filters": this.advance_filters
      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data: any)=> {
        this.getNumbers(data)
        let array = data.result;
        this.overviewData = data;
        this.counsellor_count = array.length;
        this.commentList = data.result;
        this.dwn_bind_userlist_Data(data.result);
        this.dataSource_dwn.sort = this.sort;
      })
    } else {
      debugger
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RPost('salesDetails',{
        "search": event.target.value,
        "advance_filters": this.advance_filters
      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data: any)=> {
        this.getNumbers(data)
        let array = data.result;
        this.overviewData = data;
        this.counsellor_count = array.length;
        this.commentList = data.result;
        this.bind_userlist_Data(data.result);
        this.dataSource.sort = this.sort;
      })
    }
  }
  tranches(form: any){
    debugger
    const dialogRef = this.dialog.open(TrachesComponent, {
      width: '35%',
      autoFocus: false,
      data: form
  
    });
  }

  advanceFilter(form: any) {
    debugger

    const dialogRef = this.dialog.open(AdvanceFilterComponent, {
      width: '100%',
      autoFocus: false,
      data: { overviewData: this.overviewData}
  
    });
    dialogRef.beforeClosed().subscribe(result => {
      debugger
      if (result) {
        this.advance_filters = result.advance_filters
        this.salesDetails(result.advance_filters);
        // this.Advancefilter_Array = result.advance_filters;
      }
  
    })
  }
  getNumbers(data: any) {
    debugger
    console.log(data);
    
    this.counsellor_count = data.result.length
    this.sp_excl_gst = data.total_sp_amount
    console.log(this.sp_excl_gst);
    
    this.totale_revenue = 0;

    data.result.forEach((element:any) => {
      //console.log(element);
      this.totale_revenue += element.amount;
    });
  }

}
