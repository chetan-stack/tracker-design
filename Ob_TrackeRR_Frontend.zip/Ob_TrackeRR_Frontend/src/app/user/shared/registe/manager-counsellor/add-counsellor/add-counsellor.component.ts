import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IncentiveService } from 'src/services/api/informed.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
 

@Component({
  selector: 'app-Add-counsellor',
  templateUrl: './Add-counsellor.component.html',
  styleUrls: ['./Add-counsellor.component.scss']
})
export class AddCounsellorComponent implements OnInit {

  managerList:any = []
  dataListObj:any = {}
  userData:any = {}
  title: string = 'Add Counsellor';
  action: String = 'Add';
  enablePlaceholder: boolean = true;

  separateDialCode = false;
  dropdoemData:any;
  passforshow:any;
  apiMessage:any;
  isMessage = false;
  lead_age:any = []
  priceExcludingGST:any;
  

  selectedSameMonth: String

  counsellerList = []
  productListArray = []

  constructor(
    // private userManagementService: UserManagementService,
    private serviceFactory: ServiceFactory,
    private incentiveService: IncentiveService,
    public dialogRef: MatDialogRef<AddCounsellorComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData:any
    ) {
    if (dialogData) {
      // debugger
      if (this.dialogData.type == 'edit') {
        this.userData = dialogData.element;
        // console.log(dialogData);
      }
    }
  }

  ngOnInit(): void {

    this.managerPopup();
   
    // this.AddUserDropdown();
    if (this.dialogData.type == 'edit') {
      this.title = 'EDIT Counsellor';
      this.action = 'Proceed';
      this.passforshow = "*****"
    } else {
      this.title = 'Add Counsellor';
      this.action = 'Add';
    }
  }

  managerPopup() {
    debugger
    this.incentiveService.RGet('managerPopup').subscribe((data)=> {
      this.managerList = data.result;
    })
  }

  onConfirm(form:any) {
    debugger

    if (this.dialogData.type == 'edit') { 
      let formdata = form.value;
      formdata['counsellor_id'] = this.userData["counsellor_id"]
      this.incentiveService.RPost('editCounsellor',formdata).subscribe((result)=> {
        this.dialogRef.close(result);
        this.serviceFactory.notification(result['message'], result['status']);
      })
    } else {
      this.incentiveService.RPost('addCounsellor',form.value).subscribe((result)=> {
        this.dialogRef.close(result);
        this.serviceFactory.notification(result['message'], result['status']);
      })
    }
    
  }

}
