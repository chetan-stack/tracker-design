import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerCounsellorComponent } from './manager-counsellor.component';

describe('ManagerCounsellorComponent', () => {
  let component: ManagerCounsellorComponent;
  let fixture: ComponentFixture<ManagerCounsellorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerCounsellorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerCounsellorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
