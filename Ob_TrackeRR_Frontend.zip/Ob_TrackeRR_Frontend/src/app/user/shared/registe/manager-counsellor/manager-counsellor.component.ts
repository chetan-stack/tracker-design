import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table'; 
import { ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { AddCounsellorComponent } from './add-counsellor/add-counsellor.component';
 

@Component({
  selector: 'app-manager-counsellor',
  templateUrl: './manager-counsellor.component.html',
  styleUrls: ['./manager-counsellor.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ManagerCounsellorComponent implements OnInit {

  datasource:any
  counsellorListArray:any= [];
  expandedElement: PeriodicElement | null;
  
  displayedColumns: string[] = [
    'sNo',
    'month',
    'totalarft',
    'total_revenue_month',
    'totalarpa',

  ];
  subdispalytable: string[] = [
    'counsellor_name',
    'Leads_assigned',
    'Accounts',
    'Conv_rate',
    'ARFT',
    'ARPA',

  ];
  getCurrentUser:any = {};


  constructor(
    private incentiveService: IncentiveService,
    private serviceFactory: ServiceFactory,
    private dialog: MatDialog,
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService,
    public commonService: CommonService,
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }
  isExpansionDetailRow = (index: any, row: any) => row.hasOwnProperty('detailRow');

  ngOnInit(): void {
    this.counsellorList();
  }

  
  searchAPI(form:any, event:any){
    debugger
    let searchValue = event.target.value;
    this.counsellorList();
  }



  counsellorList() {
    debugger
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.incentiveService.RGet('pmp/monthlydata').pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((data)=> {
      this.counsellorListArray = data.result['final_data'];
      this.bindTable(data.result['final_data']);
    })
  }

  bindTable(data:any) {
    this.datasource = new MatTableDataSource(data);
  }


}

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  description: string;
}
