import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared.module';
import { DemoMaterialModule } from 'src/app/material-module';


import { RegisteRoutingModule,RegisteModuleConst } from './registe-routing.module'; 
///import { AddSalesComponent } from './sales-details/dialog/add-sales/add-sales.component';
//import { CustomDateFormat1, CustomDateFormat2, LtAddSalesComponent } from './sales-details/dialog/lt-add-sales/lt-add-sales.component';
import { DwnAddSalesComponent } from './sales-details/dialog/dwn-add-sales/dwn-add-sales.component';
import { AdvanceFilterComponent } from './sales-details/dialog/advance-filter/advance-filter.component';
import { AddCounsellorComponent } from './manager-counsellor/add-counsellor/add-counsellor.component';
import { TrachesComponent } from './sales-details/dialog/traches/traches.component';
import { Cdkdiretive } from './cdkdiretive';



  

@NgModule({
    declarations: [
        RegisteModuleConst,
        // AddSalesComponent, 
        // LtAddSalesComponent,
        DwnAddSalesComponent,
        // CustomDateFormat1, 
        // CustomDateFormat2, 
        AdvanceFilterComponent,
        AddCounsellorComponent,
        TrachesComponent,
        Cdkdiretive,
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        SharedModule,
        DemoMaterialModule,
        RegisteRoutingModule,
    ]
})
export class RegisteModule { }
