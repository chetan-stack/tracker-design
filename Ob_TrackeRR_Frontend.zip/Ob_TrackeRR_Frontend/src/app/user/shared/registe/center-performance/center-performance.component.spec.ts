import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CenterPerformanceComponent } from './center-performance.component';

describe('CenterPerformanceComponent', () => {
  let component: CenterPerformanceComponent;
  let fixture: ComponentFixture<CenterPerformanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CenterPerformanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CenterPerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
