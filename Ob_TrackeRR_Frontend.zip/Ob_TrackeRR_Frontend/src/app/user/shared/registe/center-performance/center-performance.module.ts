import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CenterPerformanceRoutingModule } from './center-performance-routing.module';
import { CenterPerformanceComponent } from './center-performance.component';
import { MaterialModule } from 'src/app/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [CenterPerformanceComponent],
  imports: [
    CommonModule,
    CenterPerformanceRoutingModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
  ]
})
export class CenterPerformanceModule { }
