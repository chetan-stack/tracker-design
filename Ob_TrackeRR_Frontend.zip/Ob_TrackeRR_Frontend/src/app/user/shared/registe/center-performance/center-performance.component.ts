import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
 

@Component({
  selector: 'app-center-performance',
  templateUrl: './center-performance.component.html',
  styleUrls: ['./center-performance.component.scss']
})
export class CenterPerformanceComponent implements OnInit {
  displayedColumns: string[] = ['sNo', 'month', 'total_revenue',  'total_sales' , 'lead', 'conversion', 'workable_count' ,  'non_workable_count' , 'arpa' , 'tenure_vs_sales' , 'combos_sold' , 'combo_sold_vs_total_sales', 'fif_sold', 'fif_sold_vs_total_sales', 'mpo_sold', 'mpo_sold_vs_total_sales', 'dwn_sold', 'dwn_sold_vs_total_sales', 'pmp_sold', 'pmp_sold_vs_total_sales' ];
  dataSource:any;

  displayLtColumn: string[] = [
    "sNo",
    "month",
    "total_revenue",
    "total_sales",
    "arpa",
    "first_tranch_revenue",
    "arft",
    "Secret_Pitched",
    "Secret_Sold",
    "total_secret_amount",
    "agreement_not_generated",
    "agreement_not_accepted"
  ];
  dataSource_lt:any;

  displayedColumns_dwn: string[] = ['sNo', 'month', 'total_revenue', 'total_sales' , 'workable_count' , 'non_workable_count' , 'arpa' , 'tenure_vs_sales' , 'combos_sold' , 'combo_sold_vs_total_sales', 'fif_sold', 'fif_sold_vs_total_sales', 'mpo_sold', 'mpo_sold_vs_total_sales', 'dwn_sold', 'dwn_sold_vs_total_sales', 'pmp_sold', 'pmp_sold_vs_total_sales' ];
  dataSource_dwn:any;
  displayedColumns_renewal: string[] = ['sNo', 'month', 'Lead_Size', 'Total_Sales' , 'Conv_Rate' ,  'Total_Rev' , 'Total_No_of_Non_LT' , 'Revenue_of_Non_LT' , 'ARPA_Non_LT_Excl_GST' , 'Combo_Sold1', 'Combo_Sold', 'Combo_Sold_ARPA', '5in5_Sold1', '5in5_Sold', '5in5_Sold_ARPA', 'MPO_Sold1', 'MPO_Sold', 'MPO_Sold_ARPA', 'Dhanwaan_Sold1', 'Dhanwaan_Sold', 'DWN_Sold_ARPA', 'Total_PMP', 'PMP_Sold', 'Revenue_Product', 'Revenue_First_Tranch',  'ARPA_Excl_GST', 'ARFT' ];
  dataSource_renewal:any;
  centerList:any = [];
  @ViewChild(MatSort) sort: MatSort;
  branch:any;
  getCurrentUser:any = {};


  constructor(
    public commonService: CommonService,
    private incentiveService: IncentiveService,
    private serviceFactory: ServiceFactory,
    //private loginService: LoginService,
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
   // this.branch = this.loginService.getBranch();
    console.log(this.branch);
  }
  // @ViewChild('search') input: ElementRef;

  ngOnInit(): void {
    this.center_per_list();
  }


  clear(monthrange: any) {
    debugger
    // this.input.nativeElement.value = '';
    monthrange.reset();
    this.center_per_list();
    

  }
  center_per_list() {
    debugger
    
    if(this.getCurrentUser.team_id== 4) {
      debugger
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet('pmp/centerPerformance',{

      }).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.centerList = data.result;
        this.lt_bind_userlist_Data(data.result);
      })
    } else if(this.getCurrentUser.team_id== 3) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet('dwn/centerPerformance').pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.centerList = data.result;
        this.dwn_bind_userlist_Data(data.result);
      })
    }else if(this.getCurrentUser.team_id== 2) {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet('renewal/centerPerformance').pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.centerList = data.result;
        this.rene_bind_userlist_Data(data.result);
      })
    } else {
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet('centerPerformance').pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.centerList = data.result;
        this.bind_userlist_Data(data.result);
      })
    }
  }

  onSubmit(form:any) {
    debugger
    let from = form.value.selectedYear1  + "-" + form.value.selectedMonth1
    let to = form.value.selectedYear2  + "-" + form.value.selectedMonth2
    
      if(this.getCurrentUser.team_id== 4){
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RGet('pmp/centerPerformance?start_date=' +from+  '&end_date='+to).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.centerList = data.result;
        this.lt_bind_userlist_Data(this.centerList);
      })
    }
      else if(this.getCurrentUser.team_id== 1){
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RGet('centerPerformance?start_date=' +from+  '&end_date='+to).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.centerList = data.result;
        this.bind_userlist_Data(this.centerList);
      })
    }
    else if(this.getCurrentUser.team_id== 2){
      this.serviceFactory.loadingStart("body","Please wait while loading...","");
      this.incentiveService.RGet('renewal/centerPerformance?start_date=' +from+  '&end_date='+to).pipe( 
        finalize(() => {  
          this.serviceFactory.loadingStop("body","");
        })
      ).subscribe((data)=> {
        this.centerList = data.result;
      this.rene_bind_userlist_Data(this.centerList);
    })
  }
      else{
        this.serviceFactory.loadingStart("body","Please wait while loading...","");
        this.incentiveService.RGet('dwn/centerPerformance?start_date=' +from+  '&end_date='+to).pipe( 
          finalize(() => {  
            this.serviceFactory.loadingStop("body","");
          })
        ).subscribe((data)=> {
          this.centerList = data.result;
        this.dwn_bind_userlist_Data(this.centerList);
      })
    }
    

  }
  
  bind_userlist_Data(data:any) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
  }

  lt_bind_userlist_Data(data:any) {
    this.dataSource_lt = new MatTableDataSource(data);
    this.dataSource_lt.sort = this.sort;
  }

  dwn_bind_userlist_Data(data:any) {
    this.dataSource_dwn = new MatTableDataSource(data);
    this.dataSource_dwn.sort = this.sort;
  }
  rene_bind_userlist_Data(data:any) {
    this.dataSource_renewal = new MatTableDataSource(data);
    this.dataSource_renewal.sort = this.sort;
  }


 
  

}

