import { Component, OnInit } from '@angular/core'; 
import { ActivatedRoute } from '@angular/router'; 
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service'; 
 
import { TitleCasePipe } from '@angular/common';  
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { BreakpointObserver } from '@angular/cdk/layout';
 

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    //{provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
})
 
export class HomeComponent implements OnInit {
  getCurrentUser: any ={};
 
  currentMonth:any = new Date().toISOString();  

  storeTop5Data:any = []; 
  centerColor:any ={};

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService,  
    private commonService: CommonService,  
    private titlecasePipe:TitleCasePipe,
    public mediaQ: BreakpointObserver 
 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = this.route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
    //this.dataFactory.setPageTitle({PageTitle: this.titlecasePipe.transform(this.getCurrentUser.activeRole)+" "+PageTitle});
    this.centerColor = this.dataFactory.all_centerColor;
  
  }
 

  ngOnInit(): void { 
    this.dataFactory.get_TopFiveList().subscribe((top5:any) => {
      this.storeTop5Data =top5
    })
  }

  ngAfterViewInit(){
    
  }
   
 
}
