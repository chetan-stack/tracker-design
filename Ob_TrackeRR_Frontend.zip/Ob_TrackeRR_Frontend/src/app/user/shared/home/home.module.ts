import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';

  import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared.module'; 
import { HomeModuleConst, HomeRoutingModule } from './home-routing.module';
import { TargetAchievementComponent } from './components/target-achievement/target-achievement.component';
import { TopFiveListComponent } from './components/top-five-list/top-five-list.component';
 import { SalesPerformanceComponent } from './components/sales-performance/sales-performance.component';
import { MetricsDataComponent } from './components/metrics-data/metrics-data.component';
import { MetricsDataTeamWiseComponent } from './components/metrics-data-team-wise/metrics-data-team-wise.component';
import { TargetAchievementTeamWiseComponent } from './components/target-achievement-team-wise/target-achievement-team-wise.component';
import { SalesBibleComponent } from './components/sales-bible/sales-bible.component';
import { BibleSummaryModule } from '../sales-bible/bible-summary/bible-summary.module';
 
 

@NgModule({
  declarations: [ 
    HomeModuleConst,
    TargetAchievementComponent,
    TopFiveListComponent,
    SalesPerformanceComponent, 
    MetricsDataComponent,
    MetricsDataTeamWiseComponent,
    SalesBibleComponent,
    TargetAchievementTeamWiseComponent,   
  ],
  imports: [
    CommonModule, 
    SharedModule,   
    HomeRoutingModule, 
    BibleSummaryModule
  ],
  providers: [TitleCasePipe]
})
export class HomeModule { }
  