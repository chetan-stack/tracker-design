import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service'; 

@Component({
  selector: 'app-top-five-list',
  templateUrl: './top-five-list.component.html',
  styleUrls: ['./top-five-list.component.scss']
})
export class TopFiveListComponent implements OnInit {
  getCurrentUser: any ={};
  currentMonth:any = new Date().toISOString(); 
  storeTop5Data:any = [];

  centerColor:any ={}; 
  teamColor:any; 
  salesType_list:any={}; 

  constructor( 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver   
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.centerColor = this.dataFactory.all_centerColor;
    this.teamColor = this.dataFactory.all_team_color; 
    this.salesType_list = this.dataFactory.salesType_list; 
  }

  ngAfterViewInit(){
    setTimeout(()=>{ 
      this.lodeTopFiveCounsellorList(this.currentMonth);
      
    });
    
  }

  lodeTopFiveCounsellorList(date:any){  
    
    let filter =  {
       month:new Date(date).getMonth()+1,
       year:new Date(date).getFullYear(), 
    }  
    this.serviceFactory.loadingStart(".topFive_card","Please wait while loading...","");
     this.commonService.post('sales/topFiveCounsellorList',filter).pipe( 
       finalize(() => {  
         this.serviceFactory.loadingStop(".topFive_card","");
       })
     ).subscribe((res:any) => {
      // debugger
       if(res.status && res.data.length>0){ 
         this.storeTop5Data = res.data;
         
         this.dataFactory.get_TopFiveList().subscribe((top5:any) => {
          if(top5.length==0){  
             this.dataFactory.set_TopFiveList(res.data); 
          }
        })

         
       }
     })
  }
 

  ngOnInit(): void {
  }

  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }

}
