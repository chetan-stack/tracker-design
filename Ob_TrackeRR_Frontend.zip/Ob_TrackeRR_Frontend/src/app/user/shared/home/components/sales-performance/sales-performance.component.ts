import { Component, HostListener, OnInit } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as echarts from 'echarts'; 

@Component({
  selector: 'app-sales-performance',
  templateUrl: './sales-performance.component.html',
  styleUrls: ['./sales-performance.component.scss']
})
export class SalesPerformanceComponent implements OnInit {
  getCurrentUser: any ={}; 
  currentMonth:any = new Date().toISOString(); 
  storeSalesPerformanceData:any=[];  
  DivIDSalesPerformanceChart:any;
  constructor( 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,    
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    
  }

  ngAfterViewInit(){
    setTimeout(()=>{  
      this.lodeSalesPerformance(this.currentMonth);
    }); 
  }

  lodeSalesPerformance(date:any){ 
    //debugger  
   
    let filter =  {
      from_date:this.getStartEndDays(date).start,
      to_date:this.getStartEndDays(date).end, 
   }
   

      this.serviceFactory.loadingStart(".salesPerformance_card","Please wait while loading...","");
    this.commonService.post('sales/salesPerformance',filter).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop(".salesPerformance_card","");
      })
    ).subscribe((res:any) => {
        if(res.status){
          this.storeSalesPerformanceData = res.data;
          setTimeout(()=>{  
            this.bindSalesPerformanceData(res.data);
          });
           
       }else{
         this.storeSalesPerformanceData = []; 
       }
    })
     
    

  }
 

  bindSalesPerformanceData(allData:any){
    //debugger 
    const saturation = "85%";
    const lightness = "65%"

    let forThis = this;
    let totalSalesSum = 0;
    let totalShareSum = 0;
    let bar_ChartLabels:any = [];
    let salesData:any = [];
    let shareData:any = [];
  
    allData.forEach(function(item:any,i:any) { 
        // The magic piece of code
        const hue = i * 137;
        const hueMod360 = hue % 360;
 

      bar_ChartLabels.push(item.label); 
      shareData.push(item.share); 
      salesData.push({
        value: item.sales,  
        itemStyle: {
          color: `hsl(${hueMod360}, ${saturation}, ${lightness})`,
          //color: randomColor(),  
        },
      });

      totalSalesSum = totalSalesSum+item.sales;
      totalShareSum = totalShareSum+item.share;
    })
  
  
 
  
  
  this.DivIDSalesPerformanceChart = echarts.init((document.getElementById('DivIDSalesPerformanceChart')) as any);
  
    let option = { 
      tooltip: {
        trigger: 'item',
        formatter: '<strong>Date : </strong> {b} <br/> <strong>{a} :</strong> {c} ',
        backgroundColor:"#fff",
        borderColor: "#333",
        borderWidth: 1,
        textStyle: {
          color: "rgba(0, 0, 0, 1)",
          fontSize: 13
        }
        },
      grid: {
        show:false,
        top: 50,
        left: 20,
        right: 10,
        bottom: 10,
        containLabel: true
      },
      legend: {
        itemGap: 15,
        textStyle: {
          color: "rgba(0, 0, 0, 1)"
        },
        formatter: function (name: string) {
           if(name=="My Sales"){
             return name +" ("+totalSalesSum+")";
           }else if(name=="Shared Sales"){
            return name +" ("+totalShareSum+")";
           }else{
            return name;
           }
          
         }
      },
      xAxis: {
              type: 'category', 
              data: bar_ChartLabels,  
              axisTick: {
                show: false
              },
              axisLine: {
                show: true,
                lineStyle: {
                  type: "dashed", 
                  color: "rgba(0, 0, 0, 0.4)",
                  width: 0.5
                }
              }
         
      },
      yAxis: {
        type: 'value',
        minInterval:1,  
        splitLine: {
          show: true,
          lineStyle: {
            color: "rgba(244, 244, 244, 1)"
          }
        },
        axisLine: {
          show: true,
          lineStyle: {
            type: "dashed", 
            color: "rgba(0, 0, 0, 1)",
            width: 1
          }
        }
    },
      series: [ 
          {
            name: 'My Sales',
            type: 'bar',
            stack: 'total', 
            barMaxWidth: 40,
            data: salesData
         },
         {
          name: 'Shared Sales',
          type: 'bar', 
          stack: 'total',
          barMaxWidth: 40,
          data: shareData,
          itemStyle: {
            color: "#d0d3de",   
          },
      }
      ]
  };
  
  
   
  this.DivIDSalesPerformanceChart.setOption(option,true);

 

}

  ngOnInit(): void {
  } 
  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }
  @HostListener('window:resize', ['$event'])
  onResize() { 
    this.DivIDSalesPerformanceChart?.resize();
  }
}
