import { Component, OnInit } from '@angular/core'; 
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { CookieService } from 'ngx-cookie-service';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service'; 
 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

@Component({
  selector: 'app-metrics-data-team-wise',
  templateUrl: './metrics-data-team-wise.component.html',
  styleUrls: ['./metrics-data-team-wise.component.scss'], 
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    //{provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
})  
export class MetricsDataTeamWiseComponent implements OnInit {
  getCurrentUser: any ={};  
  currentMonth:any ={
    from_date:this.getStartEndDays(new Date().toISOString()).start,
    to_date:this.getStartEndDays(new Date().toISOString()).end, 
  }; 
  moment = moment; 
  storeSalesMetricData:any;  
  filteredMonth:any
  centerColor:any ={}; 
  teamColor:any; 
  salesType_list:any={}; 
  constructor(
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    private cookieService: CookieService, 
    private router: Router,
    private route:ActivatedRoute,  
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
 
    this.centerColor = this.dataFactory.all_centerColor;
    this.teamColor = this.dataFactory.all_team_color; 
    this.salesType_list = this.dataFactory.salesType_list; 
    
    const ifDateCount = this.cookieService.get('filtered_date_Metrics');
    debugger
    if(ifDateCount){
     const parsCount = JSON.parse(ifDateCount)
     this.currentMonth.from_date = parsCount.from_date;
     this.currentMonth.to_date = parsCount.to_date;   
    }

  
  }
  ngAfterViewInit(){
    setTimeout(()=>{   
      this.lodeSalesMetricData()  
    });  
  }
  ngOnInit(): void {

  }

  dateInputChange(val:any){{
    if(val){ 
      this.cookieService.set( 'filtered_date_Metrics', JSON.stringify({
        from_date:this.currentMonth.from_date,
        to_date:this.currentMonth.to_date,
      }),1,'/');  
      this.lodeSalesMetricData()  
    }
  }
    
  }

  lodeSalesMetricData(){  
   // debugger 
   if(!this.currentMonth.to_date){
    return
  }

  let dataOpt ={
    from_date:moment(this.currentMonth.from_date).format('YYYY-MM-DD'),
    to_date:moment(this.currentMonth.to_date).format('YYYY-MM-DD'),
  }; 



  this.serviceFactory.loadingStart(".Metrics_card","Please wait while loading...","");
  this.commonService.post('sales/getSalesMetricDataTeamWise',dataOpt).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop(".Metrics_card","");
      })
    ).subscribe((res:any) => {
        if(res.status && res.data.length>0){
          this.storeSalesMetricData = res.data; 
       } else{
        this.storeSalesMetricData = undefined
       }
    })
  
  }

  refreshData(){
    this.currentMonth  ={
      from_date:this.getStartEndDays(new Date().toISOString()).start,
      to_date:this.getStartEndDays(new Date().toISOString()).end, 
    };
    
    this.cookieService.delete('filtered_date_Metrics','/');   
    this.lodeSalesMetricData(); 
  }

  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }

 
  

  jsonS(data:any){
    return data?JSON.stringify(data):""    
  
  }
  getBtoa(data:string){
    return btoa(data);
    }

    
}
