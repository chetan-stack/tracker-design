import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as echarts from 'echarts'; 

@Component({
  selector: 'app-target-achievement-team-wise',
  templateUrl: './target-achievement-team-wise.component.html',
  styleUrls: ['./target-achievement-team-wise.component.scss']
})
export class TargetAchievementTeamWiseComponent implements OnInit {
  getCurrentUser: any ={}; 
  currentMonth:any = new Date().toISOString(); 
  storeSalesPerformanceData:any=[];
  storeAllCounsellorPerformanceData:any; 
  DivIDAllCounsellorPerformanceChart:any;
  DivIDSalesPerformanceChart:any;

  @ViewChild('DivIDPerformanceChart') private DivIDPerformanceChart: any;

  constructor( 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,     
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    
  }

  ngAfterViewInit(){
    setTimeout(()=>{  
      this.lodeAllCounsellorPerformance(this.currentMonth);
    }); 
  }

 

  lodeAllCounsellorPerformance(date:any){ 
    //debugger  
   
    let filter =  {
      from_date:this.getStartEndDays(date).start,
      to_date:this.getStartEndDays(date).end, 
   } 
  
    this.serviceFactory.loadingStart(".AllCounsellorPerformance_Card","Please wait while loading...","");
    this.commonService.post('sales/allCounsellorPerformance',filter).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop(".AllCounsellorPerformance_Card","");
      })
    ).subscribe((res:any) => {
        if(res.status && res.data.length>0){
          this.storeAllCounsellorPerformanceData = res.data;
          setTimeout(()=>{  

            // sort by value
            res.data.sort(function (a: { completed: number; }, b: { completed: number; }) {
              return a.completed - b.completed;
            });

            this.bindAllCounsellorPerformance(res.data);
         }); 
       }else{ 
         this.storeAllCounsellorPerformanceData = undefined; 
       }
    })
     
  }

  bindAllCounsellorPerformance(allData:any){
     debugger
     
    let forThis = this; 
   
    let ChartData:any = [];  
  
    allData.forEach(function(item:any,i:any) { 
      
      if(item.completed>0 && item.target==0){
        item.target = item.completed
     }

      let totalTarget = item.target; 
      let totalCompleted = item.completed; 
      let totalLeft = totalTarget-totalCompleted; 

 
      let totalExtraDone = 0;  


      if(totalCompleted>totalTarget){
        totalLeft = 0; 
        totalExtraDone = totalCompleted-totalTarget;   
        totalCompleted = totalTarget; 
       } 

      
     ChartData.push({ 
       name: item.name,
       completed:totalCompleted, 
       extra:totalExtraDone, 
       target:totalLeft
      }); 
    
  })
  
 
  if (this.DivIDPerformanceChart.nativeElement) {
    this.DivIDPerformanceChart.nativeElement.style.minHeight = ChartData.length*40+"px"; 
  }   

  this.DivIDAllCounsellorPerformanceChart = echarts.init((document.getElementById('DivIDAllCounsellorPerformanceChart')) as any);
  
  let option =  { 
    color:['#23BF6D', '#109CF1', '#F55B5D'],
    tooltip : {
      trigger: 'axis',
      axisPointer: {
          animation: true
      },
      formatter: function (params: any[]) {
        debugger
          var colorSpan = (color: string) => '<span style="display:inline-block;border-radius:10px;width:9px;height:9px;background-color:' + color + '"></span>';
          var seriesHtml ='';
          let totalAch = 0;
          let totalTrg = 0; 
          let totalAchColor = '';
          let totalTrgColor = '';

          params.forEach(item => {
              if(item.seriesName=="Achievement"){
                totalAch = totalAch+item.data; 
                totalTrg = totalTrg+item.data;
                totalAchColor = totalAchColor + colorSpan(item.color)+'+';
                totalTrgColor = totalTrgColor + colorSpan(item.color)+'+';
              }
              if(item.seriesName=="Extra"){
                totalAch = totalAch+item.data;
                totalAchColor = totalAchColor + colorSpan(item.color);
              }
              if(item.seriesName=="Left"){ 
                totalTrg = totalTrg+item.data;
                totalTrgColor = totalTrgColor + colorSpan(item.color);
              }
              seriesHtml += '<p class="mb-1">'   + colorSpan(item.color) + ' ' + item.seriesName + ' : ' + item.data + '</p>'
           }); 
          let html = '<p class="mb-1"><b>Counsellor : </b>' + params[0].axisValue + '</p>';
          html += '<p class="mb-1"><b>Total Achievement : </b>' + totalAch + '</p>';
          html += '<p class="mb-2"><b>Total Target : </b>' + totalTrg + '</p><hr>';
          html += seriesHtml;

          return html;
      }        
  },
    legend: {top: "0"},
    grid: {
      left: '0',
      right: '15px',
      top: '40px',
      bottom: '0',
      containLabel: true
    },
    xAxis: {
      type: 'value'
    },
    yAxis: {
      type: 'category',
      data: ChartData.map((x:any) => x.name),
      axisLabel: {
        formatter: (function(value: any){ 
         // debugger 
          const name = value.split(' '); 
            return name[0] + ' '+name[1]?.slice(0, 3)+'...'; 
         }) 
       },
    },
    series: [
      {
        name: 'Achievement',
        type: 'bar',
        stack: 'total',  
        data: ChartData.map((x:any) => x.completed),
        label: {
          show: true,
          color: "rgba(255, 255, 255, 1)",
          formatter: (function(value: any){  
            if(value.value>0){
              return value.value;
             }else{
              return "";
             } 
           }) 
         } 
      }, 
      {
        name: 'Extra',
        type: 'bar',
        stack: 'total', 
        data: ChartData.map((x:any) => x.extra),
        label: {
          show: true,
          color: "rgba(255, 255, 255, 1)",  
          formatter: (function(value: any){  
            if(value.value>0){
              return value.value;
             }else{
              return "";
             } 
           }) 
         }, 
      },
      {
        name: 'Left',
        type: 'bar',
        stack: 'total', 
        data: ChartData.map((x:any) => x.target),
        label: {
          show: true,
          color: "rgba(255, 255, 255, 1)", 
          formatter: (function(value: any){  
            if(value.value>0){
              return value.value;
             }else{
              return "";
             } 
           }) 
         }, 
      } 
    ]
  };
  
  this.DivIDAllCounsellorPerformanceChart.setOption(option,true);
  
  }

 
  ngOnInit(): void {
  } 
  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }
  @HostListener('window:resize', ['$event'])
  onResize() {
   // this.DivIDAllCounsellorPerformanceChart?.resize();
   // this.DivIDSalesPerformanceChart?.resize();
  }
}
