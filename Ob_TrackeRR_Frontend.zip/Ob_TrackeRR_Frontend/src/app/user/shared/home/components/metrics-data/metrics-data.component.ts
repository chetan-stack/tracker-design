import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service'; 

@Component({
  selector: 'app-metrics-data',
  templateUrl: './metrics-data.component.html',
  styleUrls: ['./metrics-data.component.scss']
})
export class MetricsDataComponent implements OnInit {
  getCurrentUser: any ={}; 
  currentMonth:any = new Date().toISOString(); 
  filteredMonth_Sales:any
  storeSalesMetricData:any; 

  filteredMonth_Ob:any
  storeObMetricData:any; 

  centerColor:any ={}; 
  teamColor:any; 
  salesType_list:any={}; 
  salesType_Color:any={};
  
  getStatusMasterList:any = []
 
  
  constructor(
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
    private router: Router,
    private route:ActivatedRoute, 
    public mediaQ: BreakpointObserver 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();

    this.centerColor = this.dataFactory.all_centerColor;
    this.teamColor = this.dataFactory.all_team_color; 
    this.salesType_list = this.dataFactory.salesType_list; 
    this.salesType_Color = this.dataFactory.salesType_Color; 
 
  }
  ngAfterViewInit(){
    setTimeout(()=>{ 
      this.lodeSalesMetricData(this.currentMonth);
      this.lodeObMetricData(this.currentMonth);  
    });  
  }
  ngOnInit(): void {
    this.commonService.get('onboarding/getUserStatusMasterList',{}).subscribe((res:any) => {
      if(res.status){
        this.getStatusMasterList = res.data;
      } 
   })
  }

  getObStatusArr(filterType:any,ob_type:any){
   let statusArr: any = [];

    if(filterType=='signed'){
      if(ob_type=='retail_new' || ob_type =='retail_renewal'){  
        statusArr = this.getStatusMasterList.filter((elm:any) => elm.id !=7 && elm.id > 4 && elm.ob_type=="retail").map((x:any) => x.id);
      }
      if(ob_type=='dwn_new' || ob_type =='dwn_renewal'){
        statusArr = this.getStatusMasterList.filter((elm:any) => elm.id !=8 && elm.id > 5 && elm.ob_type=="dwn").map((x:any) => x.id);
      }
      if(ob_type=='pmp_lt' || ob_type =='dwn_lt'){
        statusArr = [2,4]
      }
       
    }else if(filterType=='not_signed'){
      if(ob_type=='retail_new' || ob_type =='retail_renewal'){  
        statusArr = this.getStatusMasterList.filter((elm:any) => elm.id==7 || elm.id < 5 && elm.ob_type=="retail").map((x:any) => x.id);
      }
      if(ob_type=='dwn_new' || ob_type =='dwn_renewal'){
        statusArr = this.getStatusMasterList.filter((elm:any) => elm.id==8 || elm.id < 6 && elm.ob_type=="dwn").map((x:any) => x.id);
      }
      if(ob_type=='pmp_lt' || ob_type =='dwn_lt'){
        statusArr = [1,3]
      }
    }else{
      statusArr = []
    }

  return statusArr
 
    
  }

  lodeSalesMetricData(date:any){  
    //debugger 
    let filter =  { 
      from_date:this.getStartEndDays(date).start,
      to_date:this.getStartEndDays(date).end, 
    }
    let stringify = JSON.stringify(filter);
    this.filteredMonth_Sales = JSON.parse(stringify);
  
   this.serviceFactory.loadingStart(".Sales_Metrics_card","Please wait while loading...","");
    this.commonService.post('sales/getSalesMetricData',filter).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop(".Sales_Metrics_card","");
      })
    ).subscribe((res:any) => {
      if(res.status && res.data.length>0){
        this.storeSalesMetricData = res.data[0]; 
     } else{
      this.storeSalesMetricData = undefined
     }
    })
  
  }

  lodeObMetricData(date:any){  
    //debugger 
    let filter =  { 
      from_date:this.getStartEndDays(date).start,
      to_date:this.getStartEndDays(date).end, 
    }
    let stringify = JSON.stringify(filter);
    this.filteredMonth_Ob = JSON.parse(stringify);
  
   this.serviceFactory.loadingStart(".Ob_Metrics_card","Please wait while loading...","");
    this.commonService.post('sales/getSalesMetricData',filter).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop(".Ob_Metrics_card","");
      })
    ).subscribe((res:any) => {
      if(res.status && res.data.length>0){
        this.storeObMetricData = res.data[0]; 
     } else{
      this.storeObMetricData = undefined
     }
    })
  
  }

  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }

  removeElmFromArray (elm:any,data:any){

    const index = data.indexOf(elm);
    if (index > -1) {
     return data.splice(index, 1);
    }else{
      return data
    }
  } 

  
  jsonS(data:any){
    return data?JSON.stringify(data):""    
  
  }
  getBtoa(data:string){
    return btoa(data);
    }

}
