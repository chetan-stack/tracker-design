import { Component, HostListener, OnInit } from '@angular/core';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as echarts from 'echarts'; 
import { BreakpointObserver } from '@angular/cdk/layout';
declare const navigator: any;
@Component({ 
  selector: 'app-target-achievement',
  templateUrl: './target-achievement.component.html',
  styleUrls: ['./target-achievement.component.scss']
})
export class TargetAchievementComponent implements OnInit {
  getCurrentUser: any ={};
  currentMonth:any = new Date().toISOString()
  filter_Team_Target:any = {};
  storedAllTargetAchivement:any = [];
  showTargetAchivementChart:any = false;
  currentMonthTotalSales:any;
  targetChartElm:any;
  ninjaChartInterval:any; 
  constructor( 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
    public mediaQ: BreakpointObserver 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    
  }

  ngAfterViewInit(){
    setTimeout(()=>{ 
      this.lodeCurrentMonthTarget(this.currentMonth);  
    });  
  }

  lodeCurrentMonthTarget(date:any){
   // debugger
   
    let filter =  {
      from_date:this.getStartEndDays(date).start,
      to_date:this.getStartEndDays(date).end, 
   }
    
    let apiUrl:any;
    if(this.getCurrentUser.activeRole=='counsellor' || this.getCurrentUser.activeRole=='manager' || this.getCurrentUser.activeRole=='saleshead'){
     apiUrl = "sales/targetAchivement"
   }
   if(this.getCurrentUser.activeRole=='account' || this.getCurrentUser.activeRole=='ops'){
     apiUrl = "sales/getTargetAchivementTeamWise";  
   }

     
   this.serviceFactory.loadingStart(".Target_card","Please wait while loading...","");
   this.commonService.post(apiUrl,filter).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop(".Target_card","");
    })
  ).subscribe(async (res:any) => {
    if(res.status){
      let bindedData:any = [];

      if(apiUrl == "sales/targetAchivement"){ 
        this.filter_Team_Target = res.data;
        this.storedAllTargetAchivement = [res.data];  
      }
      if(apiUrl == "sales/getTargetAchivementTeamWise"){ 
        
        this.filter_Team_Target = res.data.filter((elm:any) => elm.target>0 || elm.completed>0)[0]; 
        this.storedAllTargetAchivement = res.data;  
      }
      this.showTargetAchivementChart = true;
      setTimeout(()=>{   
        this.bindTargetChart(this.filter_Team_Target);
      },50);  

    }else{
        this.filter_Team_Target = {}; 
        this.storedAllTargetAchivement = [];  
        this.showTargetAchivementChart = false;
       
    }
  }) 
   
      
  }
  
  bindTargetChart(res:any){
    //debugger
 
  
    let forThis = this;
 
    if(res.completed>0 && res.target==0){
       res.target = res.completed
    }
    if(res.completed==0 && res.target==0){
     this.showTargetAchivementChart = false;
     forThis.serviceFactory.loadingStop(".Target_card","");
     return
   }else{
     this.showTargetAchivementChart = true;
   }
    
    
    
    
     let totalTarget = res.target; 
     let totalCompleted = res.completed; 
     let totalLeft = totalTarget-totalCompleted; 
    
     let totalExtraTarget = Number((totalTarget*20/100).toFixed());
     let totalExtraDone = 0; 
     let totalExtraLeft = totalExtraTarget; 
     
     
 
      
      
      if(totalCompleted>totalTarget){
       totalLeft = 0; 
       totalExtraDone = totalCompleted-totalTarget;   
       totalCompleted = totalTarget; 
      } 
 
      if(totalExtraDone>=totalExtraTarget){
       totalExtraLeft = 5;     
      } 
 
      
      let splitNumber = totalCompleted + totalLeft + totalExtraDone + totalExtraLeft;
      this.currentMonthTotalSales = totalCompleted+totalExtraDone;
      
      navigator.setAppBadge(totalCompleted);
      
      var chartDom:any = document.getElementById('DivIDTargetChart');
      //var myChart = echarts.init(chartDom);
  
   //let chartElm = echarts.init((document.getElementById('DivIDTargetChart')) as any);
  
   this.targetChartElm = echarts.init(chartDom, 'null', {renderer: 'svg'});
 
   let option:any = {
     color:['#23BF6D', '#F55B5D', '#18a45a' , '#109CF1'],
     grid: {
       left: 10,
       top: 35,
       right: 20,
       bottom: 30, 
     },
      legend: {show: false},

      xAxis: {
        type: 'value',
        max: splitNumber,
         //splitNumber: splitNumber, 
        // interval:Number((splitNumber/20).toFixed()), 
       axisLabel: {
         show: true,
         color: "#525252",  
         fontSize: 13,  
        },
        splitLine: {
          show: false
        }
      },
      yAxis: {
        type: 'category', 
        show: false,
       
      },
      series: [
        { 
          name: 'Achievement',
          type: 'bar',
          stack: '1',
          barWidth: "100%",  
          data: [totalCompleted,0],
          label: {
           show: true,
           color: "rgba(255, 255, 255, 1)", 
           fontWeight: "bold",
           fontSize: 14, 
          formatter: (function(value: any){ 
            let d = (totalCompleted/totalTarget)*100;
            if(value.value>0){
             return Number(d.toFixed())+"%";
            }else{
             return "";
            }
          
          })
         },
          itemStyle: { 
           borderColor: '#fff',
           borderWidth: 1
          },
          
        },
         { 
          name: 'Target',
          type: 'bar',
          stack: '1',  
          barWidth: "100%",
          data: [totalLeft,0],
          label: {
           show: true,
           color: "rgba(255, 255, 255, 1)", 
           fontWeight: "bold",
           fontSize: 14,
          // formatter: '{c}%',
           formatter: (function(value: any){ 
             let d =(totalCompleted/totalTarget)*100; 
             if(value.value>0){
               return Number((100-d).toFixed())+"%";
              }else{
               return "";
              } 
            })
         },
          itemStyle: { 
           borderColor: '#fff',
           borderWidth: 1
          },
         
          markPoint: { 
          // animation:false,
           data: [{
               label: {
                 show: true,
                 position: [-20, -15], 
                 formatter: 'Target - '+totalTarget,
                 color: "#FF3E3E", 
                 fontWeight: "bold", 
                 fontSize: 14,
               },
               coord: [totalTarget, 0], 
               y: 50, 
               symbol: "image://./assets/images/ninja/red-flag.gif",
               symbolOffset: [16, 0],
               symbolSize:[56, 70],
           }],
           
           /*
           data: [ 
              { 
                type: 'max', 
                y: 40,
                symbol: "image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAA9CAYAAAAwJ0B7AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAHvSURBVHgB7ZY9bsIwGIY/B4uxojfgCAwdGAAxMdMb0KUzV+gJWg5Q0Yzdwt4KIxBipCcoNyhDlwoS93P4Cy2gYL4kHvxIjhJ+pEfW974OazTuJSDXge+9vj3fgoE4m5sb+d2UtdqnrFa7slKpg0HwP89FYKylFgrPQUoPP+tBLieYEHPICH7iu0IoDNCCIADc4ZXwYiHYZDKDFOGxf8lYE69NyOeVsMB7Ny3h+JJRGKvjtR4K12pTHAsXfF+w8XgKCaAnuU8JpUvAuRKe4bOH49Fjo5EAIigkoxRxtcFx2qGwlELt8qXC1JJRDjXFAJvCO7cpHEiHwlq4i6PwhcHr42rJcrkY589J7uRxosFbNYWqNu9YU2QjGWUn/Bg2BYCA5dKNNkX2kvuUwsX5Lni+30lrJnVYBY/zvmk7uY/aSZxXEyVVPXWwBcSmX02RVGIuinmHij9LSVXw6tx/wLmbnir49CXXc4Ynz0vckycdSSXG2ADP9Cedl+ckJf8FQBdqyZMB0IVCMnYAdNGX1AiALudJXhgAXeJIkgVAl2OSiQRAl63kDziJB0CXreSQX3nsfXgHBmLy++QWK0mFlaTCSlJhJamwklRYSSqsJBVWkgorSYWVpMJKUmElqbCSVFhJKqwkFVxKJtRNEPgfYCi/Ug3mzdgnn4IAAAAASUVORK5CYII=",
                symbolOffset: [19, 16],
                symbolKeepAspect: true,
                symbolSize: 61
                }
           ]*/
          },
        },
         { 
          name: 'Extra Achievement',
          type: 'bar',
          stack: '1', 
          barWidth: "100%", 
          data: [totalExtraDone,0],
          label: {
           show: true,
           color: "rgba(255, 255, 255, 1)", 
           fontWeight: "bold",
           fontSize: 14,
           formatter: (function(value: any){  
             let d =((totalCompleted+totalExtraDone)/totalTarget)*100;  
             if(value.value>0){
               return Number((d-100).toFixed(2))+"%";
              }else{
               return "";
              } 
 
            })
         },
          itemStyle: { 
           borderColor: '#fff',
           borderWidth: 1
          },
         },
         { 
           name: 'Celebration Zone',
           type: 'bar',
           stack: '1', 
           barWidth: "100%", 
           data: [totalExtraLeft,0],
           label: {
            show: true,
            color: "rgba(255, 255, 255, 1)", 
            fontWeight: "bold",
            fontSize: 14,
            formatter: forThis.mediaQ.isMatched('(min-width: 991px)') ? 'Celebration Zone':''
          },
           itemStyle: { 
            borderColor: '#fff',
            borderWidth: 1
           },
          },
         
      ]
    };
 
 
 //    for(var i = 0; i < totalCompleted/4; i++){
 //      setTimeout(function(){
 //       option.series[0].markPoint.data[0].coord = [i,0];     
 //       myChart.setOption(option, true); 
 //     },i * 1000)
 // }
 
   this.targetChartElm.setOption(option, true);
  
    setTimeout(function(){
     option.animation =false;
     forThis.ninjaGoToTotalSales(splitNumber,totalCompleted,totalExtraDone,option);
     forThis.serviceFactory.loadingStop(".Target_card","");
    },500)
  

  } 

  ninjaGoToTotalSales(splitNumber:any,totalCompleted:any,totalExtraDone:any,option:any){
   // debugger
    option.series[0].markPoint = { 
     data: [{
       label: {
         show: true,
         position: [-20, -15],
       // distance: 0,
         formatter: 'Achievement - '+totalCompleted,
         color: "#23BF6D",
         fontWeight: "bold",
         fontSize: 14,
       },
       coord: [0, 1],
       y: 50,  
       symbol:'image://./assets/images/ninja/completed.gif',
       symbolOffset: [0, 0],
       symbolSize:[56, 70],
     }],
    
 }; 
 
 
 let forThis = this; 
 let totalCount=0; 
    this.ninjaChartInterval = setInterval(function(){ 
  // debugger   
       option.series[0].markPoint.data[0].coord = [totalCount,0]; 
 
       if(totalCount==totalCompleted && totalExtraDone==0){  
         clearInterval(forThis.ninjaChartInterval);
         option.series[0].markPoint.data[0].symbol = 'image://./assets/images/ninja/attack.gif';  
       }else if(totalCount==totalCompleted+totalExtraDone && totalExtraDone>0){  
         clearInterval(forThis.ninjaChartInterval); 
         option.series[0].markPoint.data[0].label = {
           show: true,
           formatter: 'Hurray! We have overachieved our targets',
           position: [-2, -15], 
           overflow: "breakAll",
         
           //color: "#23BF6D"
         },
         option.series[0].markPoint.data[0].symbol = 'image://./assets/images/ninja/extra_completed.gif';  
       }
       forThis.targetChartElm.setOption(option, true); 
       totalCount++;  
 
 }, 1000/(totalCompleted+totalExtraDone));
  
  }

  ngOnInit(): void {
  }
  onChange_Team_Target(data:any){ 
    debugger
    if(this.ninjaChartInterval){
      clearInterval(this.ninjaChartInterval); 
    }
    
    this.serviceFactory.loadingStart(".Target_card","Please wait while loading...",""); 
    
    this.bindTargetChart(data); 
     
    
  }

  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }

  
  @HostListener('window:resize', ['$event'])
  onResize() {
    this.targetChartElm?.resize();

  }

}
