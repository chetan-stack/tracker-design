import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';    
import { SecretsListComponent } from './secrets-list/secrets-list.component';
import { SecretsComponent } from './secrets.component'; 
 
 
 
const routes: Routes = [ 
  {
    path: '', component: SecretsComponent,  
    data:{pageType:'secrets'},   
     children: [    
              {path: 'list', component: SecretsListComponent, data:{title: 'Secrets'}}, 
              {path: '', redirectTo: 'list', pathMatch: 'full'},  
        ],  
     }, 
        
];  

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecretsRoutingModule { }
export const SecretsModuleConst = [  
  SecretsComponent,  
  SecretsListComponent
];