import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
 
import { SharedModule } from '../shared.module';  
import { SecretsModuleConst, SecretsRoutingModule } from './secrets-routing.module';
import { SendSecretRequestComponent } from './secrets-list/send-secret-request/send-secret-request.component';
import { ChangeSecretStatusComponent } from './secrets-list/change-secret-status/change-secret-status.component'; 
import { ViewUserInfoModule } from '../dialog/view-user-info/view-user-info.module';
 
//TargetRoutingModule

@NgModule({
    declarations: [
        SecretsModuleConst,
        SendSecretRequestComponent,
        ChangeSecretStatusComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        SecretsRoutingModule,
        ViewUserInfoModule
    ]
})
export class SecretsModule { }
