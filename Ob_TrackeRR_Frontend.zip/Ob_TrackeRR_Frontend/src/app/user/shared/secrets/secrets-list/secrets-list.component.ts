import { Component, ElementRef, OnInit, ViewChild } from '@angular/core'; 
import { MatTableDataSource } from '@angular/material/table';
import {MatSort, Sort} from '@angular/material/sort'; 
 
import { ActivatedRoute } from '@angular/router';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2'; 
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';   
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators';

import { SendSecretRequestComponent } from './send-secret-request/send-secret-request.component';
import { ChangeSecretStatusComponent } from './change-secret-status/change-secret-status.component';
import { MatPaginator } from '@angular/material/paginator';
import { fromEvent, merge } from 'rxjs';
import { BreakpointObserver } from '@angular/cdk/layout';
 
 


@Component({
  selector: 'app-secrets-list',
  templateUrl: './secrets-list.component.html',
  styleUrls: ['./secrets-list.component.scss']
})
export class SecretsListComponent implements OnInit {
  getCurrentUser:any = {}; 
  pageType:string;
  
  filter_Search:string = ""; 
  filter_Status:any = []; 
  filter_secrets_categories:any = []; 

  gridDataSource = new MatTableDataSource(); 
  displayedColumns:any = [
    "id",
    "customer_name",
    "customer_id", 
    "customer_email",
    "customer_phone",
    "forwarded_on",
   
    "status", 
    "action"
  ]
 

 

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}  
 
  storedAllData: any; 

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver, 
    private dialog: MatDialog ,
  ) {

    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
       

    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon; 


    route.queryParams.subscribe(p => {   
      this.refreshGrid("route"); 
      this.loadGrid_Data();
   });

   }
 
  ngOnInit(): void {
    
  }
  ngAfterViewInit(): void {
  

    fromEvent(this.textSearch_main.nativeElement, 'keyup').pipe(debounceTime(250),distinctUntilChanged(),tap(() => {
      debugger
      this.paginator.pageIndex = 0,
       this.loadGrid_Data();
    })
  ).subscribe();
  
  
  
      // reset the paginator after sorting
   this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
  
   // on sort or paginate events, load a new page
   merge(this.sort.sortChange, this.paginator.page)
   .pipe(
       tap(() => this.loadGrid_Data())
   )
   .subscribe();
  }
 

  onFilterGrid() { 
      this.loadGrid_Data();
  }
  
  loadGrid_Data() { 

    let dataOption:any = {
      search: this.filter_Search,
      status: this.filter_Status,
      secrets_categories: this.filter_secrets_categories,
       
      short_key: this.sort?this.sort.active:"",
      short_order: this.sort?this.sort.direction:"",
      page: this.paginator?this.paginator.pageIndex:0,
      perpage: this.paginator?this.paginator.pageSize:20,
     }
  
        
   
  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post_alphabet('trackerr/secrets/requestedProspects',dataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      if(res.status){
        this.storedAllData = res.data;
        this.bindGridData(res.data.dataobject);
      }else{
        this.storedAllData = undefined;
        this.bindGridData([]);
      }
  
    })
  }

   
  bindGridData(data:any) {
    this.gridDataSource = new MatTableDataSource(data);
    this.gridDataSource.sort = this.sort;
    this.bindTableGridWidth();
  }
 
  
 

  refreshGrid(mode:any) {
     if(this.paginator){
      this.paginator.pageIndex = 0;
      this.filter_Search="";  
      this.filter_Status = [];
      this.filter_secrets_categories = []; 
      this.sort.active = "";
      this.sort.direction = ""; 
    }
    
  
  if(mode=="reset"){
    this.loadGrid_Data();
  }
    
  
  }

 
  
 

  showDialog_SecretRequest(type:any,elm:any){
    debugger 
    let stringify = JSON.stringify(elm);
    const dialogRef = this.dialog.open(SendSecretRequestComponent,{ 
      width:'700px',  
     // disableClose: true, 
      data:{
        type: type, 
        data:JSON.parse(stringify)
      }, 
    });
    dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      this.loadGrid_Data(); 
    }       
  }) 
  }


  showDialog_SecretStatus(type:any,elm:any){
    debugger 
     let stringify = JSON.stringify(elm);
    const dialogRef = this.dialog.open(ChangeSecretStatusComponent,{ 
      width:'700px', 
     // disableClose: true, 
      data:{
        type: type, 
        data:JSON.parse(stringify)
      }, 
    });
    dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      this.loadGrid_Data(); 
    }       
  }) 
  }


  bindTableGridWidth(){
    debugger
 
    let w = 0;  
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number  = string.replace("%", ""); 
      w = w + Number(number);
    } 
 
    if(this.data_table._elementRef.nativeElement){
      this.data_table._elementRef.nativeElement.style.minWidth = w+'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w+'px';
       
    }   
     
  }
 

}
