import { KeyValue } from '@angular/common';
import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-change-secret-status',
  templateUrl: './change-secret-status.component.html',
  styleUrls: ['./change-secret-status.component.scss']
})
export class ChangeSecretStatusComponent implements OnInit {
  getCurrentUser: any ={};  

  SecretFormData:any = {};
  counsellorList:any =[];

  @ViewChild('ngElmSendRequest') public ngElmSendRequest: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;

  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<ChangeSecretStatusComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
  ) {
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser();  
     this.SecretFormData = this.AddEditData.data;
  }
 
  
  ngOnInit(): void {

  }


  ngAfterViewInit(){ 
   
  } 
 
 
  hasErrorPhone(ngModel:any,hasAction:any){ 
    debugger
   if(!hasAction){
     ngModel.control.setErrors({'incorrect': true}); 
   }else{
     ngModel.control.setErrors({'incorrect': false});
   } 
}
setInputVal(ngModel:any,value:string){  
  ngModel.control.setValue(value); 
}


onSubmit(Form_Group:any){
    debugger 
     
      
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value; 
  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('miscellaneous/approveSecretData',elmForm).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res); 
      } 
     }) 
     
  
     
     
 }
 
}
