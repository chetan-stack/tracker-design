import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-send-secret-request',
  templateUrl: './send-secret-request.component.html',
  styleUrls: ['./send-secret-request.component.scss']
})
export class SendSecretRequestComponent implements OnInit {
  getCurrentUser: any ={};
  pageTypeMode:string; 

  SecretFormData:any = {};
 

  @ViewChild('ngElmSendRequest') public ngElmSendRequest: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;

  @ViewChild('customer_search') customer_search: ElementRef;



  isLoading = false;
  dataNotAvailable:any = false;

  customer_List:any = [];
  customer_AllData:any;

  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<SendSecretRequestComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
  ) {
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.pageTypeMode = AddEditData.type;  
 
  }
 
  
  ngOnInit(): void {

  }


  ngAfterViewInit(){ 
   
  } 
 
  // { 
  //   active_role_id: 2
  //   active_user_id: 14 
  //   customer_id: 1111 
  //   comments
  //   }


  keyPressAutocomplete(selectedValue:any){
    debugger
    this.ngElmSendRequest.form.controls.customer.setErrors({ notSelected: true });

    if(selectedValue != "" && selectedValue.length>3){
      //debugger
      this.isLoading = true;
      this.dataNotAvailable  = false; 

      this.commonService.post_alphabet('trackerr/secrets/searchProspects',{search:selectedValue}).pipe( 
        finalize(() => {  
          this.isLoading = false;
        })
       ).subscribe((res:any) => { 

         if(res.status){
           this.customer_List=res.result;
         }else{
          this.dataNotAvailable = res.message;
         } 
       
        }        
      ); 
    }

  }


  validate_maxlength(event:any,max:any){ 
    // //debugger
     let inputValue: string =  event.target.value.concat(event.key); 
 
     if(inputValue.length>max){
       event.preventDefault();
       //this.serviceFactory.notification('Max. Character Limit is '+max+'.','error');  
     }
   }


   optionSelected(event: MatAutocompleteSelectedEvent): void {
    debugger 
    this.customer_AllData =event.option.value; 

    this.ngElmSendRequest.form.controls.customer.setValue(event.option.value.customer_name,{emitEvent: false, onlySelf: true});
    this.ngElmSendRequest.form.controls.customer.setErrors(null);
  }
   
 


onSubmit(Form_Group:any){
    debugger 
     
      
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value; 
    elmForm['customer_id'] = this.customer_AllData.customer_id;
    delete elmForm.customer;
    

 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post_alphabet('trackerr/secrets/forwardProspect',elmForm).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res); 
      } 
     }) 
     
  
     
     
 }

 displayFn(user: any) {
  if (user) { return user; }
}
}
