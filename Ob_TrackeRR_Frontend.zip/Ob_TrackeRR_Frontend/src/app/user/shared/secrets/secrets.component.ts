import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';

@Component({
  selector: 'app-secrets',
  templateUrl: './secrets.component.html',
  styleUrls: ['./secrets.component.scss']
})
export class SecretsComponent implements OnInit {
  getCurrentUser:any = {}; 
  constructor(
    private commonService: CommonService,
    private router: Router,
    private route:ActivatedRoute,
  ) { 
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser(); 
    
    const result = this.getCurrentUser.sales_type.filter((elm:any) => elm.access_name=='pmp_lt');
   
    // if(this.getCurrentUser.activeRole=='ops' || (this.getCurrentUser.activeRole=='manager' && result.length>0)  || (this.getCurrentUser.activeRole=='counsellor' && this.getCurrentUser.secrets_calling_access)){
     
    // }else{
    //   this.router.navigate(['../'],{ 
    //     relativeTo: this.route
    //   });
    // }
  }

 

  ngOnInit(): void {
  }

}
