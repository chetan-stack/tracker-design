import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-view-user-info',
  templateUrl: './view-user-info.component.html',
  styleUrls: ['./view-user-info.component.scss']
})
export class ViewUserInfoComponent implements OnInit {
  userInfo_Data
  constructor(
    @Inject(MAT_DIALOG_DATA) private userData: any,
    private dialogRef: MatDialogRef<ViewUserInfoComponent>,
    private dialog: MatDialog,
    
    
  ) { 
    this.userInfo_Data = userData
  }

  ngOnInit(): void {
  }

}
