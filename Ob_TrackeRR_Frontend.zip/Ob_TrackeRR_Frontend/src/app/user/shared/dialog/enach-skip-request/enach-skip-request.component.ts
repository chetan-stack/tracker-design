import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-enach-skip-request',
  templateUrl: './enach-skip-request.component.html',
  styleUrls: ['./enach-skip-request.component.scss']
})
export class EnachSkipRequestComponent implements OnInit {
  getCurrentUser: any ={}; 

  constructor(
    private commonService:CommonService,
    private serviceFactory: ServiceFactory,
    public dialogRef: MatDialogRef<EnachSkipRequestComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any, 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
  }

  ngOnInit(): void {
  }
 

  onAction(Form_Group:any,action_mode:any){
    debugger  
     
     
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value;
    
    elmForm['sales_type_id'] = this.dialogData.sales_type_id; 
    elmForm['counsellor_id'] = this.dialogData.counsellor_id;
    elmForm['lead_id'] = this.dialogData.lead_id; 
    elmForm['customer_id'] = this.dialogData.customer_id;
    elmForm['sale_source_id'] = this.dialogData.id;

    elmForm['action_mode'] = action_mode; 

     let SwalMsg ="";
     let apiUrl ="";  
    if(this.getCurrentUser.activeRole=="manager"){ 
      elmForm['enach_skip_request'] = true;  
      apiUrl = "autopayment/saveCustomerAutoPaymentDtl";
   
      SwalMsg = 'Are you sure you want to send E-Nach skip request?'; 
    }else if(this.getCurrentUser.activeRole=="account"){ 
        SwalMsg = action_mode=='approve'?'Are you sure you want to approve E-Nach skip request?':'Are you sure you want to reject E-Nach skip request?';
        apiUrl = "autopayment/enachSkipReqestAction";
        elmForm['enach_dtl_id'] = this.dialogData.enach_dtl_id; 
        
      }else{

     }
   
     
     

    Swal.fire({ 
      title:'E-Nach Skip!',
      html: SwalMsg,
      icon: 'warning', 
      customClass: {
        confirmButton: 'mat-flat-button mat-button-base mat-'+(action_mode=='New' || action_mode=='skip'?'primary':action_mode=='approve'?'warn':'primary'),
        cancelButton: 'mat-stroked-button mat-button-base ',
        container: 'modal-yes-no Modal_Delete', 
        actions: 'modal-btn-yes-no mb-4',
        //  header: 'pt-4', 
      },
      width: '36em',
      showCloseButton: true,
      buttonsStyling: false,
      showCancelButton: true,
      confirmButtonText:action_mode=='New' || action_mode=='skip'?'Send':action_mode=='approve'?'Approve':'Reject',
      cancelButtonText: 'Cancel' , 
      focusConfirm:false, 
      focusCancel:true,     
      }).then((result) => {
        debugger
        if (result.isConfirmed) {
          this.serviceFactory.loadingStart("body","Please wait while loading...","");
          this.commonService.post(apiUrl,elmForm).pipe(  
            finalize(() => {  
              this.serviceFactory.loadingStop("body","");
            })
          ).subscribe((res:any) => {
            this.serviceFactory.notification(res.message,res.status); 
            if(res.status){
              this.dialogRef.close(res); 
            } 
           }) 
        }
      })  
     
 }

 
}
