
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
 

@Component({
  selector: 'app-remark-history',
  templateUrl: './remark-history.component.html',
  styleUrls: ['./remark-history.component.scss']
})
export class RemarkHistoryComponent implements OnInit {
  getCurrentUser: any ={}; 
  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}
  constructor(
    private commonService:CommonService,
    //private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    public dialogRef: MatDialogRef<RemarkHistoryComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any, 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon;  
  }

  ngOnInit(): void {
  }

}
