import { Component, OnInit, ViewChild, TemplateRef, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';  
import Swal from 'sweetalert2'
import { Router } from '@angular/router';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { CommonService } from 'src/services/api/common.service';
import { finalize } from 'rxjs/operators';
 
type AOA = any[][];
@Component({
  selector: 'app-bulk-upload',
  templateUrl: './bulk-upload.component.html',
  styleUrls: ['./bulk-upload.component.scss']
})
export class BulkUploadComponent implements OnInit {
 
    fileformatError:any;
    fileUploaded:any; 
    @ViewChild('input_xlsx_FileField') input_xlsx_FileField: any;  

  constructor(
    @Inject(MAT_DIALOG_DATA) public dialogData: any={},
    private dialogRef: MatDialogRef<BulkUploadComponent>,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    private dialog: MatDialog,
    private router: Router,
    ) { }

  ngOnInit() { 
    
  }
   
   

     upload_xlsx_file(elm:any) {
      //debugger 
      
        var ext = elm[0].name.substring(elm[0].name.lastIndexOf('.') + 1);
        
        if (ext.toLowerCase() == 'xlsx' || ext.toLowerCase() == 'xls') { 
           this.fileformatError=false;        
           this.fileUploaded=elm[0].name; 
           const file = elm[0];
           
           var formData = new FormData();
           formData.append(this.dialogData.keyName, file); 


           Swal.fire({ 
            title:'Bulk Upload',
            //html: 'Since you are going to mark verify to the customer.',
            html: 'Are you sure you want to upload data in bulk.',
            icon: 'warning', 
            customClass: {
              confirmButton: 'mat-flat-button mat-button-base mat-primary',
              cancelButton: 'mat-stroked-button mat-button-base ',
              container: 'modal-yes-no Modal_Delete', 
              actions: 'modal-btn-yes-no mb-4',
              //  header: 'pt-4', 
            },
            width: '36em',
            showCloseButton: true,
            buttonsStyling: false,
            showCancelButton: true,
            confirmButtonText:'Yes',
            cancelButtonText: 'Cancel' , 
            focusConfirm:false, 
            focusCancel:true,     
            }).then((result) => {
              debugger
              if (result.isConfirmed) {
                  this.serviceFactory.loadingStart("body","Please wait while loading...","");
                  this.commonService.post(this.dialogData.api,formData).pipe( 
                  finalize(() => {  
                    this.serviceFactory.loadingStop("body","");
                  })
                  ).subscribe((res:any) => {  
                    debugger 
                    this.serviceFactory.notification(res.message,res.status); 
                    if(res.status){  
                      this.dialogRef.close(res);
                    }
            
                }) 
              }
            })   
 
        }else{   
            this.fileformatError = "File format is not supported. Please select .xlsx or .xls file only."; 
            this.fileUploaded =false;      
            return false;
        }
       
    }

 
 

}
