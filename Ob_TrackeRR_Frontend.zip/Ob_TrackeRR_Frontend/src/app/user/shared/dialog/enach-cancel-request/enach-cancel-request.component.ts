
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-enach-cancel-request',
  templateUrl: './enach-cancel-request.component.html',
  styleUrls: ['./enach-cancel-request.component.scss']
})
export class EnachCancelRequestComponent implements OnInit {
  getCurrentUser: any ={};  
  product_color:any= {}
  product_label:any= {}  
  moment = moment; 
  constructor(
    private commonService:CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    public dialogRef: MatDialogRef<EnachCancelRequestComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any, 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.product_label = this.dataFactory.all_product_label;
    this.product_color = this.dataFactory.all_product_color;
  }

  ngOnInit(): void {
  }
 
 
  onAction(Form_Group:any){
    debugger  
     
     
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let SwalMsg ="Are you sure you want to send cancel E-Nach request?";  
    
    let elmForm = Form_Group.value;
    elmForm['sales_id'] = this.dialogData.sales_id; 
    elmForm['customer_id'] = this.dialogData.customer_id;
   
    elmForm['action_mode'] = this.dialogData.action_mode;
 

    let confirmButton = 'primary'; 
    

   
    if(this.getCurrentUser.activeRole=='account'){ 
      confirmButton = 'warn'
    }

    if(elmForm.first_tranche_date){
      elmForm['cancelled_date'] = moment(elmForm.first_tranche_date).format('YYYY-MM-DD'); 
    }
    
 

     
    // if(this.getCurrentUser.activeRole=="ops"){ 
    //   //SwalMsg = 'Are you sure you want to send cancel E-Nach request?'; 
    // }else if(this.getCurrentUser.activeRole=="account"){ 
    //   //  SwalMsg = elmForm['action_mode']=='approve'?'Are you sure you want to approve E-Nach cancel request?':'Are you sure you want to reject E-Nach cancel request?';
    //  }else{

    //  }
   
    
     

    Swal.fire({ 
      title:'E-Nach Cancelation!',
      html: SwalMsg,
      icon: 'warning', 
      customClass: {
        confirmButton: 'mat-flat-button mat-button-base mat-'+confirmButton,
        cancelButton: 'mat-stroked-button mat-button-base ',
        container: 'modal-yes-no Modal_Delete', 
        actions: 'modal-btn-yes-no mb-4',
        //  header: 'pt-4', 
      },
      width: '36em',
      showCloseButton: true,
      buttonsStyling: false,
      showCancelButton: true,
      confirmButtonText:'Yes',
      cancelButtonText: 'Cancel' , 
      focusConfirm:false, 
      focusCancel:true,     
      }).then((result) => {
        debugger
        if (result.isConfirmed) {
          this.serviceFactory.loadingStart("body","Please wait while loading...","");
          this.commonService.post('autopayment/saveEnachCancelRequest',elmForm).pipe(  
            finalize(() => {  
              this.serviceFactory.loadingStop("body","");
            })
          ).subscribe((res:any) => {
            this.serviceFactory.notification(res.message,res.status); 
            if(res.status){
              this.dialogRef.close(res); 
            } 
           }) 
        }
      })  
     
 } 
 
jsonS(data:any){
  return data?JSON.stringify(data):""    

}
}
