import { Component, OnInit, Inject } from '@angular/core';
 import * as moment from 'moment';
// import { Workbook } from 'exceljs'; 

import { Workbook } from 'exceljs';
import * as FileSaver from 'file-saver'; 

 

import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog'; 
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { CommonService } from 'src/services/api/common.service';
import { finalize } from 'rxjs/operators';

 
  
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.scss'], 
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
})
 
export class DownloadComponent implements OnInit {
  downloadformData:any={}
  header:any = {}; 


  product_label:any = {}
  product_color:any= {} 
  getPaymentType:any={}

  salesType_list:any;
  salesType_key:any = {};
  salesType_color:any = {};
 
 

   

  
  
  constructor(
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    private commonService: CommonService, 
    public dialogRef: MatDialogRef<DownloadComponent>,    
    @Inject(MAT_DIALOG_DATA) public componenData: any
    ) {
       debugger
       
       let fileName = ""+componenData.fileName+'_List'; 


       this.downloadformData['name'] = this.removeSpecialCharsAndSpace(fileName)+'_'+ moment().format("DD_MM_YYYY"); 
      
       
       //this.downloadformData['filter_from_date'] = componenData.filter.start_date==""?moment().subtract(1, 'months'):componenData.filter.start_date;
       //this.downloadformData['filter_to_date'] = componenData.filter.end_date==""?moment():componenData.filter.end_date;
       
       this.header =  componenData.colShow;

      

       /******** */

       this.product_label = this.dataFactory.all_product_label;
       this.product_color = this.dataFactory.all_product_color; 
   
       this.getPaymentType= this.dataFactory.all_payment_type; 

       this.salesType_list = dataFactory.salesType_list; 
       this.salesType_key = dataFactory.get_salesType_key;
       this.salesType_color = dataFactory.salesType_Color;
  }

  

  ngOnInit(): void {
  }
  


downloadFile(form_Group:any){
  debugger
 
  if (form_Group.invalid) {
    return;
   }
   let myDictionary = form_Group.value 
   this.serviceFactory.loadingStart('mat-dialog-container','Please wait..',''); 
   let dataOption = this.componenData.dataOption
   //dataOption['start_date'] = myDictionary['filter_from_date'];
   //dataOption['end_date'] = myDictionary['filter_to_date'];
   dataOption['perpage'] = 10000000;


 
   this.serviceFactory.loadingStart("body","Please wait while loading...","");
   this.commonService.post(this.componenData.endPoint,dataOption).pipe( 
     finalize(() => {  
       this.serviceFactory.loadingStop("body","");
     })
   ).subscribe((res:any) => {
     if(res.status){
      this.serviceFactory.loadingStop('mat-dialog-container','');  
      this.all_Portfolio_xlsx_Data(res.data.dataobject.reverse(),this.header);
     } 
 
   })




   
 


 

  //   if(downloadStatus){
  //     setTimeout(()=>{
  //       this.serviceFactory.loadingStop('mat-dialog-container','');        
  //       this.dialogRef.close(downloadStatus);
  //       downloadStatus = false;
  //  }, 600);
      
  //   }   
  }

  /*************************/

 
 
/******************************** */
  async all_Portfolio_xlsx_Data(data:any,header:any){
  debugger
   
  let forThis = this;
   
  let displayedCol = header.map((itm:any) =>itm.label);
  const index = displayedCol.indexOf("Actions");
  if (index > -1) {
    displayedCol.splice(index, 1);
  }

  let bodyCol:any = []

  data.forEach((eml:any, index:any)  =>{
    let row:any =[]
    header.forEach((head:any) => {  
      if(head.name=="action"){
       return
      } 
 

      if(head.name=="id"){
        row.push(index+1)
      }else if(head.name=="customer_name"){
        row.push((eml[head.name].replace(/  +/g, ' ')).trim()) 
      } else if(head.name=="customer_id" || head.name=="payment_received_date" || head.name=="secrets_categories"){
        row.push(eml[head.name]?eml[head.name]:'N/A')
      }else if(head.name=="product"){
        row.push(forThis.product_label[JSON.stringify(eml[head.name])]) 
      }else if(head.name=="access_name"){
        debugger
        row.push(forThis.salesType_list[eml[head.name]]) 
      }else if(head.name=="informed_investor" || head.name=="tenure_extended" || head.name=="client_gst" || head.name=="secrets"){
        row.push(eml[head.name]==1?'Yes':'No')
      }else if(head.name=="duration"){
        row.push(eml[head.name]+' Year')
      }else if(head.name=="agreement_file"){
        row.push('Yes')
      }else if(head.name=="amount_with_gst"){ 
        row.push(forThis.getNumber(eml.amount) + forThis.getGST(eml.amount))
      }else{
        row.push(eml[head.name])
      } 
    })
    
    bodyCol.push(row)
  })

 
 

  //Create workbook and worksheet
  let workbook = new Workbook();
  let worksheet = workbook.addWorksheet('Sheet_1'); 


     let headerRow = worksheet.addRow(displayedCol); 
     headerRow.eachCell((cell, number) => {      
      if (number == 1) {
          cell.alignment = {horizontal: 'center', vertical: 'middle' } 
        }else{
          cell.alignment = {horizontal: 'left',  vertical: 'middle' }; 
        }

      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '002979FF' }
      }
      cell.font = {color: {argb: "FFFFFFFF"}, family: 4, size: 12, bold: true};
      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    })
      headerRow.height = 25;
      
    // worksheet.addRows(data);

    // Add Data and Conditional Formatting
    bodyCol.forEach((d:any) => { 
      let row = worksheet.addRow(d);
       row.eachCell((cell, number) => {        
        if (number == 1) {
            cell.alignment = {horizontal: 'center', vertical: 'middle' } 
          }else{
            cell.alignment = {horizontal: 'left',    }; 
          }
        });  
    });

 

    worksheet.columns.forEach(function (column, i) { 
      //column.width = 30
      column.width = Math.round(forThis.componenData.cellW[i]/6)
      if(i==0){
       // column.width = 10
      }
    });
   
   

    worksheet.addRow([]);

    
    //Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      FileSaver.saveAs(blob, this.removeSpecialCharsAndSpace(this.downloadformData['name'])+'.xlsx');
    })
  





  return true
}

removeSpecialCharsAndSpace(str:any) {
  debugger;
  return str.replace(/[' ']|[*]|[?]|[\[]|[\]]|[/]|[:]|[\\]/g, '_');
}

 /*****************************/
    /************** */

    getBase64ImageFromURL(url:any) {
      return new Promise((resolve, reject) => {
        var img = new Image();
        img.setAttribute("crossOrigin", "anonymous");
        img.onload = () => {
          var canvas = document.createElement("canvas");
          canvas.width = img.width;
          canvas.height = img.height;
          var ctx:any = canvas.getContext("2d");
          ctx.drawImage(img, 0, 0);
          var dataURL = canvas.toDataURL("image/png");
          resolve(dataURL);
        };
        img.onerror = error => {
          reject(error);
        };
        img.src = url;
      });
    }




  

      textMask(type:any,value:any){
        //debugger
        if(type=='phone' && value){
           var part1, part2;
           part1 = value.slice(0, 3);
           part2 = value.toString().substr(-2);
           return part1 + "********" + part2;
        }else if(type=='email' && value){
          
         var avg, splitted, part1, part2;
         splitted = value.split("@");
         part1 = splitted[0];
         part1 = part1.slice(0, 3);
         part2 = splitted[1].substr(-4);
         return part1 + "*******@****" + part2;
        }else{
          return value
        }
     }

     getGST(val: any){
      //debugger
       var get_GST = (Number(val) * 18)/100;
       return Number(get_GST.toFixed())
    }
    getNumber(val:any){
      return Number(val);
     }
  }

 