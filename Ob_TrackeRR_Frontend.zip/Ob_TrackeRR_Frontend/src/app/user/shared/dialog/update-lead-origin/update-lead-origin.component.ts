import { KeyValue } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-lead-origin',
  templateUrl: './update-lead-origin.component.html',
  styleUrls: ['./update-lead-origin.component.scss']
})
export class UpdateLeadOriginComponent implements OnInit {
  getCurrentUser: any ={}; 

  product_color:any= {}
  product_label:any= {} 

  salesType_list:any = {};
  salesType_key:any = {};
  salesType_color:any = {};

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}

  getTeamListData:any=[];
  lead_Identifier_List:any = [];
  lead_Identifier_Origin_List:any = [];
  counsellorListByCenter_List:any = [];
  center_list:any={};
  center_color:any={};

  generateOnBoard:any = {}
  disabledChanges:any = true;
  disabledOnfecthLeadDetails:any = false;
  constructor(
    private commonService:CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    public dialogRef: MatDialogRef<UpdateLeadOriginComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any, 
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();

    this.center_list = dataFactory.all_centerList;
    this.center_color = dataFactory.all_centerColor;

    this.salesType_list = dataFactory.salesType_list; 
    this.salesType_key = dataFactory.get_salesType_key;
    this.salesType_color = dataFactory.salesType_Color;


    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon;  
    this.product_label = this.dataFactory.all_product_label;
    this.product_color = this.dataFactory.all_product_color;
    
 
    this.dataFactory.get_TeamList().subscribe((res: any) => { 
      this.getTeamListData = res; 
   })

if(this.dialogData.origin_FromType!='SalesForm'){
  this.loadLeadOriginDtlBySalesId();
}

   
this.loadLeadIdentifierOrigin();


   if(this.getCurrentUser.activeRole =='counsellor' && (dialogData.status=='Pending' || dialogData.status=='Reject by Manager')){
    this.disabledChanges = false;
   }else if(this.getCurrentUser.activeRole =='manager' && (dialogData.status=='New' || dialogData.status=='Reject by Accounts')){
    this.disabledChanges = false;
   }else if(this.getCurrentUser.activeRole =='account'){
    this.disabledChanges = false;
   }else if(this.dialogData.origin_FromType=='SalesForm'){
    this.disabledChanges = false;
  }else{
    this.disabledChanges = true;
   }
   
  
 
  }

  ngOnInit(): void {
    
  }
 
  loadLeadOriginDtlBySalesId() { 
    this.commonService.post('sales/getLeadOriginDtlBySalesId',{sales_id:this.dialogData.id}).subscribe((res:any) => {
       if(res.status){
        let data = res.data;
        this.generateOnBoard = data; 
        if(data.lead_origin_center_id){
         this.loadCounsellorListByCenter(data.lead_origin_center_id);
        }
       }
    })
  }
  
   /*************************** */
   onChangeLeadIdentifier(event:any){
     
  }
  onChangeLeadIdentifierOrigin(event:any){ 

  }

  onChangeLeadIdentifierCenter(event:any){
    debugger
     this.loadCounsellorListByCenter(event.value);
  }
  
  loadCounsellorListByCenter(id:any) { 
    this.commonService.post('userProfile/getCounsellorListByCenter',{center_id:id,team_id:this.generateOnBoard['lead_origin_id']}).subscribe((res:any) => {
      this.counsellorListByCenter_List = res.data.sort((a:any, b:any) => a.name.localeCompare(b.name));  
    })
  }
 

  loadLeadIdentifierOrigin() { 
    this.commonService.post('onboarding/getLeadOriginListTeamIdentifierWise',{
      team_id:this.dialogData.team_id, 
      // sales_type_id:this.salesType_id[this.salestype_Params ],
      sales_type_id:this.dialogData.sales_type_id
    }).subscribe((res:any) => {
      if(res.status){ 
       let data = res.data;
       let identifier_List:any = {};  
       data.forEach((elm: any) => { 
         const pushSubArr = {
           lead_origin_name:elm.lead_origin_name,
           lead_origin_id:elm.lead_origin_id
         } 
         if(!identifier_List[elm.identifier_id]){
           identifier_List[elm.identifier_id] = {
              identifier_name:elm.identifier_name,
              identifier_id:elm.identifier_id,
              origin_list:[pushSubArr]
           }
         }else{
           identifier_List[elm.identifier_id].origin_list.push(pushSubArr)
         }
       }); 
       this.lead_Identifier_List = identifier_List; 
      }
     
   })
  }
 

/************************************ */

onSubmit(form_Group:any){
  debugger 
    
  // stop here if form is invalid 
  if (form_Group.invalid) {
      return;
  }
   let formElmValue = form_Group.value; 

   formElmValue['sales_id'] =  this.dialogData.id;
   formElmValue['sales_type_id'] =  this.dialogData.sales_type_id;
   formElmValue['sale_source_id'] =  this.dialogData.sale_source_id;
   formElmValue['team_id'] =  this.dialogData.team_id;
   formElmValue['leadId'] =  this.dialogData.leadId;
   formElmValue['customer_email_id'] =  this.dialogData.customer_email_id;
   formElmValue['customer_name'] =  this.dialogData.customer_name;
   formElmValue['customer_phone_no'] =  this.dialogData.customer_phone_no;
   formElmValue['counsellor_id'] =  this.dialogData.counsellor_id; 
  
  
 
   this.serviceFactory.loadingStart("body","Please wait while loading...","");
   this.commonService.post('sales/saveLeadOriginDtlFromSalesList',formElmValue).pipe( 
     finalize(() => {  
       this.serviceFactory.loadingStop("body","");
     })
   ).subscribe((res:any) => {
    this.serviceFactory.notification(res.message,res.status); 
    if(res.status){ 
      this.dialogRef.close(res); 
    }
   })
   
    
}

/******************************/

 // Preserve original property order
 originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
  return 0;
}
getNumber(val:any){
 return Number(val);
}
 
jsonS(data:any){
  return data?JSON.stringify(data):""    

}

}
