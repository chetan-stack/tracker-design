import { Component, HostBinding, Inject, OnInit, Renderer2 } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
 

@Component({
  selector: 'app-file-preview',
  templateUrl: './file-preview.component.html',
  styleUrls: ['./file-preview.component.scss']
})
export class FilePreviewComponent implements OnInit {  
  fileData:any={};
  pdf_file:any;
  img_file:any;
  fileType:any;
  constructor(
    @Inject(MAT_DIALOG_DATA) public componentData: any, 
    private dialogRef: MatDialogRef<FilePreviewComponent>,
    private sanitized: DomSanitizer,
    private renderer: Renderer2,
  ) {
     
 
    }
  ngOnInit(): void {
    if(this.componentData.file){
      this.fileType = this.componentData.file.split('.').pop(); 
      if(this.fileType=='pdf'){  
        this.dialogRef.updateSize("1000px", "calc(100vh - 90px)");
        this.pdf_file = this.componentData.file;
      }else if(this.fileType=='png' || this.fileType=='jpg' || this.fileType=='jpeg'){
        this.img_file = this.componentData.file
      }else{
        
      }

    }
  }
  @HostBinding('class') colorClass = 'red';

  pageRendered() {
    debugger
    this.colorClass ='loaded'
   // this.renderer.addClass(pdfviewerBody, 'loaded'); 
  }
  
}
