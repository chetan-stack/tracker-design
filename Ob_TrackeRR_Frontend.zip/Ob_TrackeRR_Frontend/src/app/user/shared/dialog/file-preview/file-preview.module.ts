import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { FilePreviewComponent } from './file-preview.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';



@NgModule({
    declarations: [FilePreviewComponent],
    imports: [
        CommonModule,
        MatButtonModule,
        MatIconModule,
        MatDialogModule,
        PdfViewerModule
    ]
})
export class FilePreviewModule { } 
