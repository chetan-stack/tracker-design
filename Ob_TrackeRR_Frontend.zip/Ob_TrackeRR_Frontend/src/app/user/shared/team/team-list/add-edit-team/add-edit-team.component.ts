import { Component, ElementRef, Inject, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import * as _moment from 'moment'; 
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service'; 
import { ServiceFactory } from 'src/services/factory/service-factory.service';   
import { CommonService } from 'src/services/api/common.service';
import { MatSelect } from '@angular/material/select';
import { KeyValue } from '@angular/common';
import { finalize } from 'rxjs/operators';

const moment = _moment; 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

 
  
@Component({
  selector: 'app-add-edit-team',
  templateUrl: './add-edit-team.component.html',
  styleUrls: ['./add-edit-team.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    //{provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
})
export class AddEditTeamComponent implements OnInit {
  getCurrentUser: any ={};
  getUserProfile:any = {};

  pageTypeMode:string;
  dialogType:string;
  dialogTypeTitle:string;
   addEditFormData:any = {
    banned:1,
    password:'Abcde@123',
    process_adherence:'yes'
  }
  addTeamRoleList:any=[]; 
  validIndicator:any = [] 
  salesType_list:any;
  center_list:any = {};
  center_color:any={};
  getParentTeam:any;
  ifExistsParentTeam:any; 
  getRoleMasterList:any=[]; 
  getTeamListData:any=[];
  storedAccessMasterList:any=[];
  getAccessListData:any=[];  
  constructor(
    @Inject(MAT_DIALOG_DATA) private AddEditData: any,
    private dialogRef: MatDialogRef<AddEditTeamComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
  ) {
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.pageTypeMode = AddEditData.type; 
     this.salesType_list = dataFactory.salesType_list;
     this.center_list = dataFactory.all_centerList;
     this.center_color = dataFactory.all_centerColor;

       this.dataFactory.get_Profile().subscribe(res => { 
          if(this.AddEditData.type=="Add"){
            this.addEditFormData['center_id'] = res.center_id;
            this.addEditFormData['status'] = 1;
            if(this.getCurrentUser.activeRole =='admin'){
              this.addEditFormData['role_id'] = 4
            }
            if(this.getCurrentUser.activeRole =='saleshead') {
              this.addEditFormData['role_id'] = 5
            }
            if(this.getCurrentUser.activeRole =='manager') {
              this.addEditFormData['role_id'] = 6
            }
            
          }
      })
     
    

     if(this.getCurrentUser.activeRole !="admin"){  
        this.addEditFormData['team_id'] = this.getCurrentUser.team_id;
        this.getAccessListData = this.getCurrentUser.sales_type; 
        this.addEditFormData['access_type_id'] = this.getCurrentUser.sales_type.map((x:any) => x.id);
      } 

      


    if(this.AddEditData.type!="Add"){  
      this.load_UserById(this.AddEditData.id);
     } 

    
     
     
     this.dataFactory.get_TeamList().subscribe(res => {
      this.getTeamListData = res;
    })

    this.dataFactory.get_AccessMasterList().subscribe(res => {
      this.storedAccessMasterList = res;
    })

   }


  ngOnInit(): void {

     
  }

 
 
 

   async onBindAccessType(){
     debugger

     if(!this.addEditFormData['team_id']){
       return
     }
     let getTeam = await this.getTeamListData.filter((elm:any) =>  elm.id == this.addEditFormData['team_id'])[0].access_id;
    
     let access:any = []; 
     this.storedAccessMasterList.forEach((element:any) => {
       if(getTeam.includes(element.id)){
        access.push(element);
       }
     }); 
     this.addEditFormData['access_type_id'] = access.map((x:any) => x.id);
     this.getAccessListData = access
   }
    
  load_UserById(id: any){ 
    debugger  
    this.commonService.post('userProfile/getUserById',{user_id:id}).subscribe(async (res:any) => {
      if(res.status){
        let data = res.data[0]; 
        //data['role_id'] = data.role_id[0];  
        data['role_id'] = data.role_id?data.role_id[0]:null;
        this.addEditFormData = data;
        if(this.getCurrentUser.activeRole !='manager'){
          this.loadParentTeamList(data['role_id']);
        } 
        this.onBindAccessType()
       }else{
        this.serviceFactory.notification(res.message,res.status); 
       }
     }) 

   
      
   }

 
   async onChangeRoleType(event:any, myselect:MatSelect){
     debugger 
 
     this.loadParentTeamList(myselect.value); 
 
     
   }

   loadParentTeamList(team:any) {
     debugger

    if(team!=6){
      this.getParentTeam =  undefined;
      return
    }

    let dataOption:any = { 
     parent_id:this.getCurrentUser.id 
    }
  

    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe(async (res:any) => { 
       if(res.status && res.data.length>0){ 
         let cList:any = [];
         if(team==6){
           res.data.forEach((element:any) => {
             if(element.role_id && element.role_id.includes(5)){
              cList.push(element)
             }
           });
           this.getParentTeam = cList
         }else{
          this.getParentTeam =  res.data;
         }
        
        
       } 
      
   
    })
 }
 
  
   onSubmit(Form_Group:any){
    debugger  

    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value;
  
    elmForm["role_id"] = [elmForm.user_role_id];
    
    elmForm['mode']= this.AddEditData.type=="Add"? "insert":"update";
    if(!elmForm["parent_id"]){
      elmForm["parent_id"] = this.getCurrentUser.id;
    }
    
    elmForm["team_id"] = elmForm.team_id?elmForm.team_id:null;
    elmForm["access_type_id"] = elmForm.access_type_id?elmForm.access_type_id:null;
   
    this.commonService.post('userProfile/manageUser',elmForm).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res);
      } 
     }) 
     
  
     
     
 }
 
 
 getEventVal(event:any){
  debugger
   return event.target.value
}
 
 
  async removeValFromArr(dataArr:any,key:any,removeArr:any){ 
    debugger
   dataArr = await dataArr.filter(function(elm:any, index:any) { 
        return removeArr.indexOf(elm[key]) == -1;
    }) 
    return dataArr;
   
}
 
hasErrorPhone(ngModel:any,hasAction:any){ 
  //debugger
  if(!hasAction){
    ngModel.control.setErrors({'incorrect': true}); 
  }else{
    ngModel.control.setErrors(null);
  } 
}

setInputVal(ngModel:any,value:string){ 
  debugger
  if(ngModel.value=="" || ngModel.value==null || ngModel.value==undefined){
    ngModel.control.setValue(value);
  }
   
}

 // Preserve original property order
 originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
  return 0;
}
getNumber(val:any){
 return Number(val);
}

}
