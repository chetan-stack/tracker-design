import { Component, OnInit, ViewChild, HostListener, ElementRef } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import {MatSort, Sort} from '@angular/material/sort';
import { MatSelect } from '@angular/material/select'; 
 
import { ActivatedRoute } from '@angular/router';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2'; 
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';
import { AddEditTeamComponent } from './add-edit-team/add-edit-team.component';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ColDef, GetDataPath, GridApi, GridReadyEvent } from 'ag-grid-community';
import 'ag-grid-enterprise';

var rowDataElm = [
  {
    orgHierarchy: ['Erica Rogers'],
    jobTitle: 'CEO',
    employmentType: 'Permanent',
  },
  {
    orgHierarchy: ['Erica Rogers', 'Malcolm Barrett'],
    jobTitle: 'Exec. Vice President',
    employmentType: 'Permanent',
  },

  {
    orgHierarchy: ['Erica Rogers', 'Malcolm Barrett', 'Esther Baker'],
    jobTitle: 'Director of Operations',
    employmentType: 'Permanent',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Esther Baker',
      'Brittany Hanson',
    ],
    jobTitle: 'Fleet Coordinator',
    employmentType: 'Permanent',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Esther Baker',
      'Brittany Hanson',
      'Leah Flowers',
    ],
    jobTitle: 'Parts Technician',
    employmentType: 'Contract',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Esther Baker',
      'Brittany Hanson',
      'Tammy Sutton',
    ],
    jobTitle: 'Service Technician',
    employmentType: 'Contract',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Esther Baker',
      'Derek Paul',
    ],
    jobTitle: 'Inventory Control',
    employmentType: 'Permanent',
  },

  {
    orgHierarchy: [
      'Erica Rogers', 
      'Malcolm Barrett', 
      'Francis Strickland'
    ],
    jobTitle: 'VP Sales',
    employmentType: 'Permanent',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Francis Strickland',
      'Morris Hanson',
    ],
    jobTitle: 'Sales Manager',
    employmentType: 'Permanent',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Francis Strickland',
      'Todd Tyler',
    ],
    jobTitle: 'Sales Executive',
    employmentType: 'Contract',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Francis Strickland',
      'Bennie Wise',
    ],
    jobTitle: 'Sales Executive',
    employmentType: 'Contract',
  },
  {
    orgHierarchy: [
      'Erica Rogers',
      'Malcolm Barrett',
      'Francis Strickland',
      'Joel Cooper',
    ],
    jobTitle: 'Sales Executive',
    employmentType: 'Permanent',
  },
];


@Component({
  selector: 'app-team-list',
  templateUrl: './team-list.component.html',
  styleUrls: ['./team-list.component.scss']
})
export class TeamListComponent implements OnInit {

  getCurrentUser: any ={};
  // {
  //   orgHierarchy: ['Erica Rogers'],
  //   jobTitle: 'CEO',
  //   employmentType: 'Permanent',
  // },

  private gridApi!: GridApi;

  public columnDefs: ColDef[] = [
    // we're using the auto group column by default!
    { field: 'name' },
    { field: 'email' },
    { field: 'phone_no' },
    { field: 'role_names' },
    { field: 'center_name' },
    { field: 'team_name' },
    { field: 'access_names' },
    { field: 'status' }, 
  ];
  
 

  public defaultColDef: ColDef = {
    flex: 1,
  };

  public rowData: any[] = [];
  public groupDefaultExpanded = 2;

  public autoGroupColumnDef: ColDef = {
    headerName: 'Organisation Hierarchy',
    minWidth: 300,
    cellRendererParams: {
      suppressCount: true,
    },
  };

  public getDataPath: GetDataPath = function (data) {
    return data.parent_id;
  };




  onFilterTextBoxChanged() {
    this.gridApi.setQuickFilter(
      (document.getElementById('filter-text-box') as any).value
    );
  }

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
  }

































  textSearch:string;
  textFilterStatus:string;
  textFilterProduct:string;

  center_list:any = {};
  center_color:any = {};
  
  salesType_list:any;
  salesType_key:any = {};
  salesType_color:any = {};
  
  gridDataSource = new MatTableDataSource(); 
  displayedColumns:any = ["id","name","email", "phone_no","role_names", "center_name", "team_name", "access_names",  "status"]

 

  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  
  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver,
    private dialog: MatDialog ,
  ) {

    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 

    this.salesType_list = dataFactory.salesType_list; 
    this.salesType_key = dataFactory.get_salesType_key;
    this.salesType_color = dataFactory.salesType_Color;
    this.center_list = dataFactory.all_centerList;
     this.center_color = dataFactory.all_centerColor;
     
  if(this.getCurrentUser.activeRole=='saleshead' || this.getCurrentUser.activeRole=='manager'){
    this.displayedColumns.push("action")
  }

   }
 
  ngOnInit(): void {
 
    this.loadGrid_Data(); 

  }

  ngAfterViewInit(): void {
    this.bindTableGridWidth();
  }
  
  
  loadGrid_Data(){ 
    debugger  
    let dataOption:any = { 
      parent_id:this.getCurrentUser.id
    }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
      if(res.status){
        this.bindGridData(res.data);
        this.rowData = res.data
      }else{
        this.bindGridData([]);
      }
     })   
   }

   bindGridData(data:any){
    debugger
    this.gridDataSource = new MatTableDataSource(data);   
    this.gridDataSource.sort = this.sort; 
    this.bindTableGridWidth(); 
   }

 
  
  

  searchUserFilter(filterValue:any) {  

    //this.textSearch = ""; 
    this.textFilterStatus = "";
    this.textFilterProduct = "";

    this.gridDataSource.filterPredicate = function(data:any, filter: string): boolean {
      debugger
      return data['name'].toLowerCase().includes(filter) ||
       data['email'].toLowerCase().includes(filter);
    };

    this.gridDataSource.filter = filterValue.trim().toLowerCase();
   }



   refreshGrid(){
    debugger
    // this.filterOnDateRange.setValue({  
    //   from_date:null,  
    //   to_date:null,   
    //  });
    this.textSearch = ""; 
    this.textFilterProduct = "";
    this.textFilterStatus = ""; 
	if(this.sort){ 
      this.sort.sort({id: '', start: 'asc', disableClear: false});
     }
    this.loadGrid_Data();
  }
 

  
  onClickdeleteSalesUser(id:any){ 
    debugger 

      Swal.fire({ 
        title: 'Delete This Counsellor',
        html: 'Are you sure you want to delete this counsellor?',
        
        imageUrl:'assets/images/Delete_icon.png',
        customClass: { 
          container: 'modal-yes-no Modal_Delete',
          confirmButton: 'mat-raised-button mat-button-base mat-warn',
          cancelButton: 'mat-raised-button mat-button-base mat-accent',
          actions: 'modal-btn-yes-no mb-4',
          image: 'modal-icon-top',
        },
        width: '36em',
        showCloseButton: false,
        buttonsStyling: false,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        cancelButtonText: 'Cancel', 
        preConfirm: (preStatus) => {
          debugger
          return new Promise((resolve) => {
            this.commonService.post('userProfile/manageUser',{ parent_id:this.getCurrentUser.id, id:id,mode:"delete"}).subscribe((res:any) => {
              resolve(res) ;  
              this.loadGrid_Data();  
             })  
          
        })

        },    
    }).then((result) => {
      debugger 
      if(result.value){
        let data:any = result.value;
        this.serviceFactory.notification(data.message,data.status);  
        
       }
    }) 
      
  } 
  
  
 

  showDialog_AddEditTeam(type:any,id:any){
    debugger 
    const dialogRef = this.dialog.open(AddEditTeamComponent,{ 
      width:'800px', 
      //disableClose: true, 
      data:{
        type: type, 
        id:id
      }, 
    });
    dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      this.loadGrid_Data(); 
    }       
  })
  }
  bindTableGridWidth(){
    debugger
 
    let w = 0;  
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number  = string.replace("%", ""); 
      w = w + Number(number);
    } 
 
    if(this.data_table._elementRef.nativeElement){
      this.data_table._elementRef.nativeElement.style.minWidth = w+'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w+'px';
       
    }   
     
  }

}
