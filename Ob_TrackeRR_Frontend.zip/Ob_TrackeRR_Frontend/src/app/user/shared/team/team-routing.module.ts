import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/auth/auth.guard';
import { TeamComponent } from './team.component'; 
import { TeamListComponent } from './team-list/team-list.component';
 
 
 
const routes: Routes = [ 
  {
    path: '', component: TeamComponent,  
    data:{pageType:'team'},   
     children: [    
            {path: 'team', component: TeamListComponent ,data:{title: 'Team Management'}},
            {path: '', redirectTo: 'team', pathMatch: 'full'}, 
        ],  
     }, 
       
]; 

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TeamRoutingModule { }
export const TeamModuleConst = [  
  TeamComponent,  
  TeamListComponent, 
];