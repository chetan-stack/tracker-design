import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TeamModuleConst, TeamRoutingModule } from './team-routing.module';
import { TeamListComponent } from './team-list/team-list.component';
import { AddEditTeamComponent } from './team-list/add-edit-team/add-edit-team.component';
import { SharedModule } from '../shared.module'; 
import { AgGridModule } from 'ag-grid-angular';
 


@NgModule({
    declarations: [
        TeamModuleConst,
        TeamListComponent,
        AddEditTeamComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        TeamRoutingModule,
        AgGridModule
    ]
})
export class TeamModule { }
  