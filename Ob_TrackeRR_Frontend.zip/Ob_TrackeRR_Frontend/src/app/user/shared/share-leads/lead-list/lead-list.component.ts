import { Component, OnInit, ViewChild, HostListener, ElementRef } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import {MatSort, Sort} from '@angular/material/sort';
import { MatSelect } from '@angular/material/select'; 
 
import { ActivatedRoute } from '@angular/router';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2'; 
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service'; 
import { SentRequestComponent } from './sent-request/sent-request.component'; 
import { AssignRequestComponent } from './assign-request/assign-request.component';
import { finalize } from 'rxjs/operators';
import { BreakpointObserver } from '@angular/cdk/layout';
import { ViewUserInfoComponent } from '../../dialog/view-user-info/view-user-info.component';
 
 


@Component({
  selector: 'app-lead-list',
  templateUrl: './lead-list.component.html',
  styleUrls: ['./lead-list.component.scss']
})
export class LeadListComponent implements OnInit {
  getCurrentUser:any = {}; 
  pageType:string;
  

  textSearch:string;
  textFilterStatus:string;
  textFilterProduct:string; 
  filter_Status:any = []; 

  gridDataSource = new MatTableDataSource(); 
  displayedColumns:any = [
    "id",
    "customer_name",
    "lead_id",
    "shared_type",
    "shared_by", 
    "shared_date", 
    "center",
    "team",
    "assigned_to",
    "assigned_date",
    "status", 
     "action"
  ]
 

  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}
 

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver, 
    private dialog: MatDialog ,
  ) {

    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
       

    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon; 


    route.queryParams.subscribe(p => {   
      this.refreshGrid("route"); 

      const countFilteredData = p.sales_countFiltered?JSON.parse(atob(p.sales_countFiltered)):null;
      if(countFilteredData?.status){   
        this.filter_Status = countFilteredData['status']
      }
      if(countFilteredData?.date){   
 
      }
   });

   }
 
  ngOnInit(): void {
 
    this.loadGrid_Data(); 

  }

  ngAfterViewInit(): void {
    this.bindTableGridWidth();
  }
  onFilterGrid() { 
      this.loadGrid_Data();
  }
  
  loadGrid_Data(){ 
    debugger  
    let dataOption:any = { 
      parent_id:this.getCurrentUser.id,
      status: this.filter_Status 
    } 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('sharedleads/getSharedLeadList',dataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      if(res.status){
        this.bindGridData(res.data);
      }else{
        this.bindGridData([]);
      }
     })   
   }

   bindGridData(data:any){
    debugger
    this.gridDataSource = new MatTableDataSource(data);   
    this.gridDataSource.sort = this.sort; 
    this.bindTableGridWidth(); 
   } 

 
  
  

  searchUserFilter(filterValue:any) {  

    //this.textSearch = ""; 
    this.textFilterStatus = "";
    this.textFilterProduct = "";

    this.gridDataSource.filterPredicate = function(data:any, filter: string): boolean {
      debugger
      return data['customer_name'].toLowerCase().includes(filter) ||
       data['customer_email'].toLowerCase().includes(filter);
    };

    this.gridDataSource.filter = filterValue.trim().toLowerCase();
   }



   refreshGrid(mode:any) {
    debugger
    // this.filterOnDateRange.setValue({  
    //   from_date:null,  
    //   to_date:null,   
    //  });
    this.textSearch = ""; 
    this.textFilterProduct = "";
    this.textFilterStatus = ""; 
    this.filter_Status = [];
	if(this.sort){ 
      this.sort.sort({id: '', start: 'asc', disableClear: false});
     }

     if(mode=="reset"){
      this.loadGrid_Data();
    }
    
  }
 

  
  onClickdeleteSalesUser(id:any){ 
    debugger 

      Swal.fire({ 
        title: 'Delete This Counsellor',
        html: 'Are you sure you want to delete this counsellor?',
        
        imageUrl:'assets/images/Delete_icon.png',
        customClass: { 
          container: 'modal-yes-no Modal_Delete',
          confirmButton: 'mat-raised-button mat-button-base mat-warn',
          cancelButton: 'mat-raised-button mat-button-base mat-accent',
          actions: 'modal-btn-yes-no mb-4',
          image: 'modal-icon-top',
        },
        width: '36em',
        showCloseButton: false,
        buttonsStyling: false,
        showCancelButton: true,
        confirmButtonText: 'Delete',
        cancelButtonText: 'Cancel', 
        preConfirm: (preStatus) => {
          debugger
          return new Promise((resolve) => {
            this.commonService.post('userProfile/manageUser',{ parent_id:this.getCurrentUser.id, id:id,mode:"delete"}).subscribe((res:any) => {
              resolve(res) ;  
              this.loadGrid_Data();  
             })  
          
        })

        },    
    }).then((result) => {
      debugger 
      if(result.value){
        let data:any = result.value;
        this.serviceFactory.notification(data.message,data.status);  
        
       }
    }) 
      
  } 
  
  
 

  showDialog_ShareRequest(type:any,elm:any){
    debugger 
    let stringify = JSON.stringify(elm);
    const dialogRef = this.dialog.open(SentRequestComponent,{ 
      width:'700px', 
      disableClose: true, 
      data:{
        type: type, 
        data:JSON.parse(stringify)
      }, 
    });
    dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      this.loadGrid_Data(); 
    }       
  }) 
  }


  showDialog_AssignRequest(type:any,elm:any){
    debugger 
    let stringify = JSON.stringify(elm);
    const dialogRef = this.dialog.open(AssignRequestComponent,{ 
      width:'700px', 
      disableClose: true, 
      data:{
        type: type, 
        data:JSON.parse(stringify)
      }, 
    });
    dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      this.loadGrid_Data(); 
    }       
  }) 
  }


  bindTableGridWidth(){
    debugger
 
    let w = 0;  
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number  = string.replace("%", ""); 
      w = w + Number(number);
    } 
 
    if(this.data_table._elementRef.nativeElement){
      this.data_table._elementRef.nativeElement.style.minWidth = w+'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w+'px';
       
    }   
     
  }
  
  openDialogUserInfo(element:any){
    debugger
    const dialogRef = this.dialog.open(ViewUserInfoComponent, {
      height: 'auto',
      width: '610px',
      data: {
        name:element.customer_name,
        email:element.customer_email,
        phone:element.customer_phone
      }, 
    });
  }

}
