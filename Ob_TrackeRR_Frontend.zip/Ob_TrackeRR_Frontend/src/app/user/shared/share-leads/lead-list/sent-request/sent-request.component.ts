import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-sent-request',
  templateUrl: './sent-request.component.html',
  styleUrls: ['./sent-request.component.scss']
})
export class SentRequestComponent implements OnInit {
  getCurrentUser: any ={};
  pageTypeMode:string;
   
  salesType_list:any;

  leadIdData:any = {
    lead_data:{},
    lead_share_with:[],
  };
  

  @ViewChild('ngElmSendRequest') public ngElmSendRequest: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;

  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<SentRequestComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
  ) {
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.pageTypeMode = AddEditData.type; 
     this.salesType_list = dataFactory.salesType_list;

 

  }

  
  ngOnInit(): void {

  }


  ngAfterViewInit(){
    setTimeout(()=>{ 
      debugger 
      if(this.AddEditData.type=="Edit"){ 
        this.ngElmSendRequest.form.controls.leadId.setValue(this.AddEditData.data.lead_id); 
      }                   
       
     }, 50); 

     setTimeout(()=>{ 
      debugger                    
       if(this.AddEditData.type=="Edit"){ 
             this.fetchLeadDetail('edit');
        }
     }, 100);
   
  } 
 
 

  fetchLeadDetail(action:any){
    debugger

    let control_lead_no = this.ngElmSendRequest.form.controls.leadId; 
 
    if(control_lead_no.invalid){
      this.elm_lead_no.nativeElement.focus()
     return false
    }  
     
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('sharedleads/leadfetchdetails',{
      leadId:control_lead_no.value,
      action:action 
     }).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => { 
      this.serviceFactory.notification(res.message,res.status); 
     
      if(res.status){ 
         control_lead_no.setErrors(null);
         let data = res.data; 
         this.leadIdData = data[0]; 
         if(this.AddEditData.type=="Edit"){  
          this.ngElmSendRequest.form.controls.team_shared_with.setValue(this.AddEditData.data.shared_with.id);
        }
          
      }else{
        control_lead_no.setErrors({'incorrect': true});
        this.elm_lead_no.nativeElement.focus(); 
        this.leadIdData = {
          lead_data:{},
          lead_share_with:[],
        }; 
      }
      
    });

  }



  onSubmit(Form_Group:any){
    debugger 
     
      
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value;
 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('sharedleads/saveSharedLead',elmForm).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res); 
      } 
     }) 
     
  
     
     
 }
}
