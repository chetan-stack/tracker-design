import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-assign-request',
  templateUrl: './assign-request.component.html',
  styleUrls: ['./assign-request.component.scss']
})
export class AssignRequestComponent implements OnInit {
  getCurrentUser: any ={};
  pageTypeMode:string;
   
  salesType_list:any;

  CounsellorList:any = [];
  
  leadIdData:any = {};

  @ViewChild('ngElmSendRequest') public ngElmSendRequest: NgForm;
  @ViewChild('elm_lead_no') public elm_lead_no: ElementRef;

  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<AssignRequestComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
  ) {
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.pageTypeMode = AddEditData.type; 
     this.salesType_list = dataFactory.salesType_list;

     this.commonService.post('sharedleads/getCounsellor',{}).subscribe((res:any) => {
     // this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.CounsellorList = res.data;
      } 
     }) 

     if(this.AddEditData.type=="Edit"){
       this.leadIdData['assigned_to'] = this.AddEditData.data.assigned_to.id
      }
     
  }

  
  ngOnInit(): void {
  }


 


  onSubmit(Form_Group:any){
    debugger 
     
      
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value;
    elmForm['id'] = this.AddEditData.data.id;
   
    this.commonService.post('sharedleads/updateAssignSharedLead',elmForm).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res);
      } 
     }) 
     
  
     
     
 }
}
