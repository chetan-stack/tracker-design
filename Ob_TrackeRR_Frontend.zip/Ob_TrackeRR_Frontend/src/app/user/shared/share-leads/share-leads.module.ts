import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
 
import { SharedModule } from '../shared.module'; 
import { ShareLeadsModuleConst, ShareLeadsRoutingModule } from './share-leads-routing.module';  
import { LeadListComponent } from './lead-list/lead-list.component'; 
import { AssignRequestComponent } from './lead-list/assign-request/assign-request.component';
import { SentRequestComponent } from './lead-list/sent-request/sent-request.component';   
import { ViewUserInfoModule } from '../dialog/view-user-info/view-user-info.module';

@NgModule({
    declarations: [
        ShareLeadsModuleConst,
        LeadListComponent,
        SentRequestComponent,
        AssignRequestComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        ShareLeadsRoutingModule,
        ViewUserInfoModule
    ]
})
export class ShareLeadsModule { }
  