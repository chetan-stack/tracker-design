import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';   
import { LeadListComponent } from './lead-list/lead-list.component';
import { ShareLeadsComponent } from './share-leads.component';
 
 
 
const routes: Routes = [ 
  {
    path: '', component: ShareLeadsComponent,  
    data:{pageType:'shareLeads'},   
     children: [    
              {path: 'list', component: LeadListComponent ,data:{pageType:'sent', title: 'Share Leads'}}, 
              {path: '', redirectTo: 'list', pathMatch: 'full'},  
        ],  
     }, 
        
];  

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ShareLeadsRoutingModule { }
export const ShareLeadsModuleConst = [  
  ShareLeadsComponent,  
  LeadListComponent  
];