import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-leads',
  templateUrl: './share-leads.component.html',
  styleUrls: ['./share-leads.component.scss']
})
export class ShareLeadsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
