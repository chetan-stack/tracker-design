import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-nach',
  templateUrl: './e-nach.component.html',
  styleUrls: ['./e-nach.component.scss']
})
export class ENachComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
