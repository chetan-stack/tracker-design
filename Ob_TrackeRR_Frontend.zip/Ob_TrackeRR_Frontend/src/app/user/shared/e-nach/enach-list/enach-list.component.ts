import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core'; 
import { MatTableDataSource } from '@angular/material/table';
import {MatSort, Sort} from '@angular/material/sort'; 
 
import { ActivatedRoute } from '@angular/router';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2'; 
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';  
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators'; 
import { MatPaginator } from '@angular/material/paginator';
import { fromEvent, merge } from 'rxjs';
import { BreakpointObserver } from '@angular/cdk/layout'; 
import { ViewUserInfoComponent } from '../../dialog/view-user-info/view-user-info.component';
import { EnachSkipRequestComponent } from '../../dialog/enach-skip-request/enach-skip-request.component';
import { RemarkHistoryComponent } from '../../dialog/remark-history/remark-history.component';
import { KeyValue } from '@angular/common';
import * as moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DownloadComponent } from '../../dialog/download/download.component';
import { EnachCancelRequestComponent } from '../../dialog/enach-cancel-request/enach-cancel-request.component';
import { MarkEnachPaymentComponent } from '../../dialog/mark-enach-payment/mark-enach-payment.component';
 
const columns_show:any = {
  skip_list:{
  'id': 'S No.',
  'customer_name': 'Customer Name', 
  'lead_id': 'Lead No.', 
  'customer_email_id':'Email',
  'customer_phone_no':'Phone',
  'counsellor_name': 'Manager', 
  'skip_request_date': 'Request Date', 
  'enach_skip_date': 'Skip Date', 
  'product': 'Product', 
  'center':'Center',
  'status': "Status", 
  'action': 'Actions'
  },
  cancel_list:{
    'id': 'S No.',
    'customer_name': 'Customer Name', 
    'customer_id': 'Cust. ID', 
    'customer_email_id':'Email',
    'customer_phone_no':'Phone',
    'umn':'UMRN No.', 
    'requested_from': 'Requested From', 
    'cancel_request_date': 'Request Date', 
    'product': 'Product',
    'cancelled_date':'Cancelled Date', 
    'status': "Status", 
    'action': 'Actions'
    },
    tranch_list:{ 
      'id': 'S No.',
      'customer_name': 'Customer Name', 
      'customer_id': 'Cust. ID', 
      'customer_email_id':'Email',
      'customer_phone_no':'Phone',
      'umn':'UMRN No.',
      'bank_code':'Bank Code', 
      'mandate_ref_no':'Mandate Ref. No',
      'transaction_ref_no':'Trxn Ref. No', 
      'product': 'Product',
      'access_name':'Sales Type',
      'due_amount':'Due Amount', 
      'due_date':'Due Date',
      'payment_received_date': 'Payment Rec. Date', 
      //'due_day':'Due Day',
      'tranche_type': 'Payment Type', 
      'authentication_mode':'Authenticatio Mode', 
      'status': "Status", 
      'action': 'Actions'

      // "id", 
      // "customer_name",
      // "customer_id",
      // "umn",
      // "bank_code",
      // "trxn_batch_no",
      // "transaction_ref_no",
      // "mandate_ref_no",
      // "product",
      // "due_amount", 
      // "due_date",  
      // "due_day",
      // "authentication_mode",
      // "status", 
      // "action"
      },
  
}
 
const ColumnDefaultShow:any  =  {
  skip_list:[
    "id",
    "customer_name",
    "lead_id",
    "counsellor_name",
    "product",  
    "skip_request_date",
    "enach_skip_date", 
    "status", 
    "action"
  ],
  cancel_list:[
    "id",
    "customer_name",
    "customer_id", 
    "umn",
    "requested_from",
    "cancel_request_date",
    "product",
    "cancelled_date", 
    "status", 
    "action"
  ],
  tranch_list:[
    "id", 
    "customer_name",
    "customer_id",
    "umn",
    "bank_code",
    //"trxn_batch_no",
    "transaction_ref_no",
    "mandate_ref_no",
    //"product",
    "access_name",
    "due_amount", 
    "due_date", 
    "payment_received_date", 
   // "due_day",
   "tranche_type",
    "authentication_mode",
    "status", 
    "action"
  ]
}
const filterForm:any = { 
  filter_Status:[], 
  filter_access_ids:[],
 
  filter_enach_skip:{
    start_date:null,
    end_date:null,
  }, 
  filter_payment_due_date:{
    start_date:null,
    end_date:null,
  }, 
  filter_payment_date:{
    start_date:null,
    end_date:null,
  },
  filter_enach_cancel:{
    start_date:null,
    end_date:null,
  },
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
selector: 'app-enach-list',
templateUrl: './enach-list.component.html',
styleUrls: ['./enach-list.component.scss'],
providers: [
  {
    provide: DateAdapter,
    useClass: MomentDateAdapter,
    deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
  },
   { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
   { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
],
})
export class EnachListComponent implements OnInit {
  selectedRowIndex:any;
  getCurrentUser:any = {}; 
  pageType:string;
  moment = moment;

  gridDataSource = new MatTableDataSource();
  allColumnsForShow:any = {}
  Column_type_defaultShow:any = []


  filter_Search:string = ""; 
  
  filter_fieldData:any = JSON.parse(JSON.stringify(filterForm));
  filter_ApplyedCount:any = 0;

  
  
 
 

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}  
  product_label:any={};
  product_color:any = {};

  salesType_list:any;
  salesType_key:any = {};
  salesType_color:any = {};

  access_list:any=[]; 

  storedAllData: any; 
  filterApiDataOption:any = {};

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver, 
    private dialog: MatDialog ,
  ) {
    debugger

    this.pageType = route.snapshot.data['type'];  

    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
       

    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon;
    this.product_color = this.dataFactory.all_product_color;
    this.product_label = this.dataFactory.all_product_label;

    this.salesType_list = dataFactory.salesType_list; 
    this.salesType_key = dataFactory.get_salesType_key;
    this.salesType_color = dataFactory.salesType_Color;  

    this.allColumnsForShow = columns_show[this.pageType];

    route.queryParams.subscribe(p => {   
      this.refreshGrid("route"); 
      this.loadGrid_Data();
     });

  //    this.dataFactory.get_TeamList().subscribe((res: any[]) => { 
  //     if(res.length>0){ 
  //        let teamData = res.filter((elm:any) => elm.id == Number(this.team_Params))[0];  
  //        this.access_list =  teamData.access_id;
  //        this.loadGrid_Data();  
  //     } 
  //  })
  
   }
 
  ngOnInit(): void {
    this.Column_type_defaultShow = ColumnDefaultShow[this.pageType];
  }
  ngAfterViewInit(): void {
  

    fromEvent(this.textSearch_main.nativeElement, 'keyup').pipe(debounceTime(250),distinctUntilChanged(),tap(() => {
      debugger
      this.paginator.pageIndex = 0,
       this.loadGrid_Data();
    })
  ).subscribe();
  
  
  
      // reset the paginator after sorting
   this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
  
   // on sort or paginate events, load a new page
   merge(this.sort.sortChange, this.paginator.page)
   .pipe(
       tap(() => this.loadGrid_Data())
   )
   .subscribe();
  }
 

 
  
  loadGrid_Data() { 

    this.filterApiDataOption = {
      search: this.filter_Search,
      status: this.filter_fieldData.filter_Status.toString(),  
      short_key: this.sort?this.sort.active:"",
      short_order: this.sort?this.sort.direction:"",
      page: this.paginator?this.paginator.pageIndex:0,
      perpage: this.paginator?this.paginator.pageSize:20,
   
      access_ids :this.filter_fieldData.filter_access_ids,

      enach_sign_skip_from_date: this.filter_fieldData.filter_enach_skip.start_date ? moment(this.filter_fieldData.filter_enach_skip.start_date).format('YYYY-MM-DD') : '',
      enach_sign_skip_from_to: this.filter_fieldData.filter_enach_skip.end_date ? moment(this.filter_fieldData.filter_enach_skip.end_date).format('YYYY-MM-DD') : '',
 

      from_due_date: this.filter_fieldData.filter_payment_due_date.start_date ? moment(this.filter_fieldData.filter_payment_due_date.start_date).format('YYYY-MM-DD') : '',
      to_due_date: this.filter_fieldData.filter_payment_due_date.end_date ? moment(this.filter_fieldData.filter_payment_due_date.end_date).format('YYYY-MM-DD') : '',


      payment_from_date: this.filter_fieldData.filter_payment_date.start_date ? moment(this.filter_fieldData.filter_payment_date.start_date).format('YYYY-MM-DD') : '',
      payment_from_to: this.filter_fieldData.filter_payment_date.end_date ? moment(this.filter_fieldData.filter_payment_date.end_date).format('YYYY-MM-DD') : '',
 
      enach_sign_cancel_from_date: this.filter_fieldData.filter_enach_cancel.start_date ? moment(this.filter_fieldData.filter_enach_cancel.start_date).format('YYYY-MM-DD') : '',
      enach_sign_skip_to_date: this.filter_fieldData.filter_enach_cancel.end_date ? moment(this.filter_fieldData.filter_enach_cancel.end_date).format('YYYY-MM-DD') : '',


     }


     
   let apiUrl = '';
    if(this.pageType=='skip_list') {
      apiUrl = 'autopayment/getEnachSkipRequestList'
    }else if(this.pageType=='cancel_list') {
      apiUrl = 'autopayment/getEnachCancelRequestList'
    }else if(this.pageType=='tranch_list') {
      apiUrl = 'admin/getEnachTranchDataList'
    }
  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post(apiUrl,this.filterApiDataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      if(res.status){
        this.storedAllData = res.data;
        this.bindGridData(res.data.dataobject);
      }else{
        this.storedAllData = undefined;
        this.bindGridData([]);
      }
  
    })

    this.filter_ApplyedCount = this.serviceFactory.getFilterAppliedCount(this.filter_fieldData);
  }

   
  bindGridData(data:any) {
    this.gridDataSource = new MatTableDataSource(data);
    this.gridDataSource.sort = this.sort;
    this.bindTableGridWidth();
  }
 
  changeColumnFilter(event: any,elm:any){
    debugger 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");  
    setTimeout(() => {
      let selected:any = []; 
      elm.options._results.forEach((element:any) => {
        if(element.selected){
           selected.push(element.value)
        }
      });
      this.Column_type_defaultShow = selected;
      this.serviceFactory.loadingStop("body","");
       debugger
    }, 200);

    setTimeout(() => {
      this.bindTableGridWidth();
    }, 700);
    
  }
 
  onFilterGrid() {
    this.paginator.pageIndex = 0,
      this.loadGrid_Data();
  }

  onFilter_SalesDateRange_Grid(data:any){ 
    if(data.value){
      this.onFilterGrid()
    }
  }

  refreshGrid(mode:any) {

    let stringifyColumn:any = JSON.stringify(ColumnDefaultShow);
    this.Column_type_defaultShow = JSON.parse(stringifyColumn)[this.pageType];


    if(this.paginator){
      this.paginator.pageIndex = 0;  
      this.sort.active = "";
      this.sort.direction = ""; 
      
      this.filter_Search="";
      this.filter_fieldData = JSON.parse(JSON.stringify(filterForm));
    }
 

    if(mode=="reset"){
      this.loadGrid_Data();
    }
    
  
  }

  bindTableGridWidth(){
    debugger 
    let w = 0;  
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number  = string.replace("%", ""); 
      w = w + Number(number);
    } 
 
    if(this.data_table._elementRef.nativeElement){
      this.data_table._elementRef.nativeElement.style.minWidth = w+'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w+'px';
       
    }  
  }


  /****************/

  openDialogUserInfo(element:any){
    debugger
    const dialogRef = this.dialog.open(ViewUserInfoComponent, {
      height: 'auto',
      width: '610px',
      data: {
        name:element.customer_name,
        email:element.customer_email_id,
        phone:element.customer_phone_no
      }, 
    });
  }

 

  showDialog_RequestAction(elm:any){
    debugger 
    elm['customer_full_name']=elm.customer_name 
   let stringify = JSON.stringify(elm);
   const dialogRef = this.dialog.open(EnachSkipRequestComponent,{ 
     width:'700px',  
    // disableClose: true, 
     data:JSON.parse(stringify), 
   });
   dialogRef.beforeClosed().subscribe(result => {
   if(result){
     debugger 
     this.loadGrid_Data(); 
   }       
 }) 
  }


 



 
  showRemarkHistory(element:any){
 
    debugger 
    let dialogRef; 
   
    this.commonService.post('autopayment/getEnachSkipComments',{enach_dtl_id:element.enach_dtl_id}).subscribe((res:any) => {  
      debugger 
      if(res.status){ 
          dialogRef = this.dialog.open(RemarkHistoryComponent, {
            height: 'auto',
            width: '900px',
            data: {title:'e-Nach Status Remarks History', data:res.data}, 
          });
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
      
  
    }) 
   
     
  }

  showCancelRemarkHistory(element:any){
 
    debugger 
    let dialogRef; 
   
    this.commonService.post('autopayment/getEnachCancelComments',{cancel_request_id:element.cancel_request_id}).subscribe((res:any) => {  
      debugger 
      if(res.status){ 
          dialogRef = this.dialog.open(RemarkHistoryComponent, {
            height: 'auto',
            width: '900px',
            data: {title:'e-Nach Status Remarks History', data:res.data}, 
          });
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
      
  
    }) 
  
  
     
  }
  
  jsonS(data:any){
    return data?JSON.stringify(data):""    
  
  }

    // Preserve original property order
    originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
      return 0;
    }


    downloadPdf(){
      debugger 
      let stringify = JSON.stringify(this.Column_type_defaultShow);
      let parse = JSON.parse(stringify);
    
      
      let colShow:any = []
        parse.forEach((element:any) => {
          colShow.push({name:element,label:this.allColumnsForShow[element]})
        });
    
     
        let stringify_dataOption = JSON.stringify(this.filterApiDataOption);
        let dataOption = JSON.parse(stringify_dataOption);  
    
  
    
        let cellW = [];
        let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
        for (let i = 0; i < children.length; i++) {
          let header = children[i].style.minWidth;
          let string = header.replace("px", "");
          var number = string.replace("%", ""); 
         cellW.push(Number(number))
        }
    

        
        
        let apiUrl = '';
        let fileName='';
        if(this.pageType=='skip_list') {
          apiUrl = 'autopayment/getEnachSkipRequestList';
          fileName = 'E-Nach Skip Requests'
        }else if(this.pageType=='cancel_list') {
          apiUrl = 'autopayment/getEnachCancelRequestList';
          fileName = 'E-Nach Cancellation Requests'
        }else if(this.pageType=='tranch_list') {
          apiUrl = 'admin/getEnachTranchDataList';
          fileName = 'E-Nach - Payment List'
        }

    
       const dialogRef = this.dialog.open(DownloadComponent, {
          width:'600px',   
          autoFocus:false, 
          data:{
            endPoint:apiUrl,
            fileName:fileName,
            dataOption:dataOption,
            colShow:colShow,
            cellW:cellW
          },
        });
     
    }



    onSendCancelRequest(elm:any,action_mode:any){
      debugger 
      elm['action_mode'] = action_mode; 
    
      let dialogRef = this.dialog.open(EnachCancelRequestComponent,{ 
        width:'820px',  
        autoFocus:false,
        restoreFocus:false,
        disableClose: false,
        data:elm, 
      });
      
      dialogRef.beforeClosed().subscribe((result: any) => {
        if(result){
          //debugger 
          this.loadGrid_Data(); 
        }       
      }) 
    
    } 



    markPaymentDone(elm:any){ 
      debugger
      elm['type'] = "Add";
      const dialogRef = this.dialog.open(MarkEnachPaymentComponent, {
          width:'820px',  
          autoFocus:false,
          restoreFocus:false,
          disableClose: true,
          //data: elm, 
          data:elm, 
      });
      dialogRef.afterClosed().subscribe((result: any) => {
        if (result) { 
          this.loadGrid_Data();
        }
      });
    }

    getNumber(val:any){
      return Number(val);
     }
  }
