import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ENachRoutingModule, ENachtsModuleConst } from './e-nach-routing.module'; 
import { SharedModule } from '../shared.module';  
import { EnachSkipRequestModule } from '../dialog/enach-skip-request/enach-skip-request.module';
import { RemarkHistoryModule } from '../dialog/remark-history/remark-history.module'; 
import { EnachCancelRequestModule } from '../dialog/enach-cancel-request/enach-cancel-request.module';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { DownloadModule } from '../dialog/download/download.module';
import { MarkEnachPaymentComponent } from '../dialog/mark-enach-payment/mark-enach-payment.component';
 

@NgModule({
  declarations: [
    ENachtsModuleConst,   MarkEnachPaymentComponent
  ],
  imports: [
    SharedModule,
    CommonModule,
    ENachRoutingModule,
    EnachSkipRequestModule, 
    RemarkHistoryModule,
    NgxMatSelectSearchModule,
    EnachCancelRequestModule,
    DownloadModule
  ]
})
export class ENachModule { }  
 