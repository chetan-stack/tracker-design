import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ENachComponent } from './e-nach.component';
import { EnachListComponent } from './enach-list/enach-list.component';
// import { EnachCancelListComponent } from './enach-cancel-list/enach-cancel-list.component'; 
// import { EnachTranchListComponent } from './enach-tranch-list/enach-tranch-list.component';


const routes: Routes = [ 
  {
    path: '', component: ENachComponent,  
    data:{pageType:'enach'},   
     children: [    
              {path: 'skip-list', component: EnachListComponent ,data:{type:'skip_list', title: 'E-Nach Skip Requests'}},
              {path: 'cancel-list', component: EnachListComponent ,data:{type:'cancel_list', title: 'E-Nach Cancellation Requests'}},
              {path: 'tranch-list', component: EnachListComponent ,data:{type:'tranch_list', title: 'E-Nach - Payment List'}},  
              {path: '', redirectTo: 'skip-list', pathMatch: 'full'},  
        ],  
     }, 
        
];  

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ENachRoutingModule { }
export const ENachtsModuleConst = [  
  ENachComponent,
  EnachListComponent,
  // EnachCancelListComponent, 
  // EnachTranchListComponent
]
