import {NgModule} from '@angular/core';

import { CommonModule } from '@angular/common';
 

 
import { GktTelInput } from 'src/app/directive/phone-input.directive';
import { LocationBackDirective } from 'src/app/directive/location-back.directive';
import { CustomMinDirective } from 'src/app/directive/custom-min-validator.directive';
import { CustomMaxDirective } from 'src/app/directive/custom-max-validator.directive';
import { StrongPasswordDirective } from 'src/app/directive/strong-password-validator.directive';
import { DemoMaterialModule } from 'src/app/material-module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { MultipleFilterPipe } from 'src/app/pipes/multiple-filter.pipe';


 
@NgModule({
    imports:[CommonModule],
    exports: [
     GktTelInput,
     LocationBackDirective,
     CustomMinDirective,
     CustomMaxDirective,
     StrongPasswordDirective ,
     DemoMaterialModule, 
     ReactiveFormsModule,
     FormsModule, 
     MultipleFilterPipe
         
    ],
    declarations: [
     GktTelInput,
     LocationBackDirective,
     CustomMinDirective,
     CustomMaxDirective, 
     StrongPasswordDirective,
     MultipleFilterPipe
    ]
  })
  export class SharedModule {}