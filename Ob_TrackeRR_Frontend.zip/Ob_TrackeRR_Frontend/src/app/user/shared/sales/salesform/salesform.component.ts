import { BreakpointObserver } from '@angular/cdk/layout';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper'; 
import { Component, ElementRef, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators'; 
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';
import { FilePreviewComponent } from '../../dialog/file-preview/file-preview.component';
import { UpdateLeadOriginComponent } from '../../dialog/update-lead-origin/update-lead-origin.component';
import { AccountApproveComponent } from '../dialog/account-approve/account-approve.component';
import { RejectionReasonComponent } from '../dialog/rejection-reason/rejection-reason.component';

const reasonArr = [
  { name:'Offer name mismatch',  value:'Please check the offer name.', selected: false},
  { name:'Wrong address filled',  value:'Please check address.', selected: false }, 
  { name:'Payment mode not updated',  value:'Please update payment mode.', selected: false }, 
  { name:'Part payment not paid',  value:'Please enter the correct amount of payment.', selected: false }, 
  { name:'Wrong GST certificate uploaded',  value:'Please enter correct image of GST certificate.', selected: false },   
  { name:'Subscription duration wrong',  value:'Please check subscription duration.', selected: false }, 
  { name:'Product activation date wrong',  value:'Please check product activation date.', selected: false },
  { name:'Mismatched with leadsquared',  value:'Data fields mismatched with leadsquared.', selected: false }
]

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-salesform',
  templateUrl: './salesform.component.html',
  styleUrls: ['./salesform.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
   // {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}},
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false,showError: true },
    },
  ],
}) 
export class SalesformComponent implements OnInit {  
sale_source_id:any;
ob_data_disabled:boolean =false;
sa_page_Id:any;
getCurrentUser:any = {}; 
pageType:string;
salesTitle:string; 
sales_type:any; 
salestype:any;
moment = moment;
salesformData:any={}; 
product_color:any= {};
product_label:any= {};   
salesType_id:any = {};

@ViewChild('stepper') public myStepper: MatStepper;
varStepChanged:any={};
@ViewChild('prevTemplate') prevTemplate: TemplateRef<any>; 
prevTemplateRef:any;
@ViewChild('backDateTemplate') backDateTemplate: TemplateRef<any>; 
backDateTemplateRef:any;
@Input() description: string = '';

@ViewChild('ngSalesFormElm') public ngSalesFormElm: NgForm;
@ViewChild('ngBackDateFormElm') public ngBackDateFormElm: NgForm;  

countryData:any=[];
getPaymentType:any=[];
counsellorList:any =[]; 
disabledAfterElmBlur:any = {}
  constructor(
    private commonService: CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    public mediaQ: BreakpointObserver,
    private route:ActivatedRoute,
    public dialog: MatDialog,
    private router: Router,
    private el: ElementRef, 
  ) {
    debugger
    this.pageType = route.snapshot.data['type'];   
    this.sale_source_id = this.route.snapshot.params['sale_source_id'];
    
    this.sa_page_Id = this.route.snapshot.params['id'];
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
   
    
    this.product_label = this.dataFactory.all_product_label;
    this.product_color = this.dataFactory.all_product_color;
    this.salesType_id = this.dataFactory.get_salesType_id;

    route.queryParams.subscribe(p => { 
      debugger 
      this.salestype = p.salestype;
    })

    this.loadPaymentType();
    this.loadCountryData()
    

    if(this.getCurrentUser.activeRole!="counsellor"){
      this.loadTeamListByParent();
    }  
}
  
ngAfterViewInit(){
  setTimeout(()=>{   
    if(this.sale_source_id){
      this.fetchLeadDetail(this.sale_source_id);
    }else if(this.sa_page_Id){
       this.loadSalesForm_Data(this.sa_page_Id); 
    }
    else{  
  
    }
  });  
}

  ngOnInit(): void {  
   
  }

  loadTeamListByParent() {
    let dataOption:any = { 
     parent_id:this.getCurrentUser.id
   }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
     this.counsellorList = res.data; 
    })
 }


  loadPaymentType(){
    this.commonService.get('sales/getPaymentList').subscribe((res:any) => { 
      this.getPaymentType = res.data
    })
  }

  loadCountryData(){
    this.commonService.get('sales/countryData').subscribe((res:any) => { 
      if(res.status){
        this.countryData = res.data;
        this.getDataByPinCode();
      }
      
    })
  }

  fetchLeadDetail(sale_source_id: any) { 
    debugger
 

    let  formVal:any = {
      leadId:sale_source_id ,
      sale_source_id:this.sale_source_id
     }
     if(this.salestype=='pmp_lt' || this.salestype=='dwn_lt'){
      formVal  = {
        customer_id:sale_source_id
       } 
     }

     formVal['salestype'] = this.salestype;

    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('sales/getSalesDataByLead',formVal).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body",""); 
      })
    ).subscribe((res:any) => {  
     
      if(res.status){ 
       // control_lead_no.setErrors(null); "[1,12]" 
        let data = res.data; 
        if(this.salestype=='pmp_lt' || this.salestype=='dwn_lt' || this.salestype=='retail_renewal'){
          data['informed_investor_subscribed'] = 1;  
         }
         
         if(this.salestype=='retail_new' || this.salestype=='dwn_new'){
          data['gst'] = this.getGST(data['amount']+data['informed_investor_amount']); 
          
         }else if(this.salestype=='pmp_lt' || this.salestype=='dwn_lt' ){
            if(data['adv_installment'] && data['adv_installment'].length>0){
              let  quarter_no1_amount = data['adv_installment'].filter((elm:any) => elm.adv_quarter_no==1)[0].amount;
              data['gst'] = this.getGST(data['deal_value'] - quarter_no1_amount); 
             }else{
              data['gst'] = this.getGST(data['deal_value']); 
             }
           

         }else{
          data['gst'] = this.getGST(data['amount']);  
         }
        data['product'] = JSON.stringify(data['product']);
        
        data['client_gst'] = 0; 
        
        data['team_id'] = this.getCurrentUser.team_id; 

        let checkNri  = data['customer_phone_no'].split('-');
        if(checkNri[0]=='+91'){
          data['nri_customer'] =  0; 
          data['country'] = 'India'
        }else{
          data['nri_customer'] =  1; 
        } 

      if(this.salestype=='pmp_lt'){
        data['secrets'] =  1;  
      }
      if(this.pageType=="Add"){
        data['sales_type_id'] = this.salesType_id[this.salestype];
      }
    
        
        //data['investment_amount'] = data['investment_amount']?data['investment_amount']:null
   
        this.salesformData = data; 

        if(!this.salesformData.leadOriginStatus){
          this.serviceFactory.notification('Kindly fill the Lead origin details first for generating a sales form.',false,5000); 
           this.updateLeadOrigin(this.salesformData);
        }

        //this.countryNgModel.control.setValue(data['country'])
        this.getDataByPinCode(); 
       
          
      }else{
        this.serviceFactory.notification(res.message,res.status); 
       // control_lead_no.setErrors({'incorrect': true});
       // elm_lead_no.focus();  
       // this.salesformData = {}; 
      }
      
    });
    
  }

  updateLeadOrigin(elm:any){
    debugger 
    
// const opt = {
//   sales_type_id:elm['sales_type_id'],
//   sale_source_id:elm['sale_source_id'],
//   team_id:elm['team_id'],
//   leadId:elm['leadId'],
//   customer_email_id:elm['customer_email_id'],
//   customer_name:elm['customer_name'],
//   customer_phone_no:elm['customer_phone_no'],
//   counsellor_id:elm['counsellor_id'],
//   origin_FromType:'SalesForm',
// }
  elm['origin_FromType'] = 'SalesForm'; 

 

    let dialogRef = this.dialog.open(UpdateLeadOriginComponent,{ 
      width:'800px',  
      autoFocus:false,
      restoreFocus:false,
      disableClose: true,
      data:elm, 
    });
    
    dialogRef.beforeClosed().subscribe((result: any) => {
      if(result){
        debugger 
        this.salesformData.leadOriginStatus = true;
        //this.loadGrid_Data(); 
      }       
    }) 
  }
 
  loadSalesForm_Data(id: any){ 
    debugger  
     

    this.commonService.post('sales/getSalesDataById',{
      sales_id:id,
      salestype:this.salestype 
    }).subscribe((res:any) => {  
      debugger 
      if(res.status){
        let data =res.data; 
        data['product'] = JSON.stringify(data['product']);
        this.salestype = data.sales_type
        this.salesformData = data;
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      } 
     
    })   
   }



  hasErrorPhone(ngModel:any,hasAction:any){ 
     debugger
    if(!hasAction){
      ngModel.control.setErrors({'incorrect': true}); 
    }else{
      ngModel.control.setErrors({'incorrect': false});
    } 
 }
 
 checkSame(val1:any,val2:any,ngModel:any){ 
    // debugger
    setTimeout(()=>{                     
      if(val1==val2){
        ngModel.control.setErrors({'same': true}); 
      } 
     }, 100); 
   
 }
 
 

  async handleFileInput(event:any,ngModel:any){ 
    debugger  
   let validFile =  await this.serviceFactory.fileFalidation(event.target.files[0],5,['png','jpg','jpeg','pdf']); 
   debugger
   if(!validFile){
    debugger
     event.target.value = "";  
   }else{  
        var formData = new FormData();
        formData.append(ngModel, event.target.files[0]);   
        this.commonService.post('sales/saveSalesFormFile',formData).subscribe((res:any) => {  
          debugger 
          this.serviceFactory.notification(res.message,res.status); 
          if(res.status){ 
            this.salesformData[ngModel] = res.data[ngModel];  
          }
      
         })  
   } 
  }





previousData(form:any){
  debugger 
  if (form.invalid) {
    for (let [index, element] of this.myStepper.steps.toArray().entries()) {
       this.myStepper.selectedIndex = index;  
    }

    for (let [index, element] of this.myStepper.steps.toArray().entries()) {
      console.log(index);
      this.myStepper.selectedIndex = index;  
      if(element.hasError){
         this.myStepper.selectedIndex = index;
         break;
       }
    }
     return;
    }
 
    if(!this.salesformData.leadOriginStatus){
      this.serviceFactory.notification('Kindly fill the Lead origin details first for generating a sales form.',false,5000); 
       this.updateLeadOrigin(this.salesformData);
       return
    }

   if(this.getCurrentUser.activeRole=="account"){ 
    this.onAccountApprove_Salesform(form); 
    }else{
      this.prevTemplateRef = this.dialog.open(this.prevTemplate, {
        maxWidth: '1000px',
        maxHeight: 'calc(100vh - 20px)',
        height: '100%',
        width: '1000px', 
      autoFocus:false,
      restoreFocus:false,
      data: {orientation:"vertical"}
      });
    } 
  
}


onClickSaveSalesform(form:any){
 debugger

let sales_date = moment(form.value.leadDetails.sales_date).format('YYYY-MM-DD'); 
 let salesMonth = moment(sales_date).format('YYYY-MM'); 
 let prevMonth = moment().subtract(1, 'months').format('YYYY-MM'); 
  let allowDate = moment().format('DD');
 //let allowDate = moment('2022-01-04').format('DD');
 //this.onSaveSalesform({});
 
 if(this.getCurrentUser.activeRole =='manager' && salesMonth == prevMonth && Number(allowDate)<=4){
  this.backDateTemplateRef = this.dialog.open(this.backDateTemplate, { 
      width: '600px', 
      autoFocus:false,
      restoreFocus:false, 
      disableClose: true,
      data:{
        sales_date:sales_date
      }
    });
 }else{
  this.onSaveSalesform({});
 } 
 

}


onBackDateCheckform(form:any){
  if (form.invalid) {
     return
  }
  this.onSaveSalesform(form.value);

}


onSaveSalesform(fakeData:any){
debugger 
 
this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

  let myDictionary  = this.ngSalesFormElm.value; 
  //let myDictionary:any =  {}; 

  myDictionary = Object.assign(
    myDictionary,
    myDictionary.leadDetails,
    myDictionary.paymentDetails,
    myDictionary.contactDetails
    );
 
   ['leadDetails', 'paymentDetails', 'contactDetails'].forEach(e => delete myDictionary[e]);
    

   let non_ad:any = []
  if(myDictionary.non_adv_installment){ 
    Object.entries(myDictionary.non_adv_installment).forEach(([key, value]) =>{
       non_ad.push(value);
   })
   myDictionary['non_adv_installment'] = non_ad;
  }

  if(myDictionary['adv_installment']){
    let ad:any = []
    Object.entries(myDictionary.adv_installment).forEach(([key, value]) =>{
      ad.push(value);
   })
   myDictionary['adv_installment'] = ad;
  }

 
 if(!Array.isArray(myDictionary['product'])){
   myDictionary['product'] = JSON.parse(myDictionary['product']);
 }

 if(!myDictionary['total_amount'] || myDictionary['total_amount']==0){
  myDictionary['total_amount'] =  myDictionary['amount'];
 }

 myDictionary['payment_file'] = this.serviceFactory.getFileNameByPath(myDictionary['payment_file']);
 myDictionary['gst_certificate_file'] = this.serviceFactory.getFileNameByPath(myDictionary['gst_certificate_file']);  
 myDictionary['sales_date'] = moment(myDictionary['sales_date']).format('YYYY-MM-DD');
 myDictionary['dob'] = moment(myDictionary['dob']).format('YYYY-MM-DD');
 myDictionary['back_sales_date'] = fakeData['back_sales_date']?moment(fakeData['back_sales_date']).format('YYYY-MM-DD'):null;

/********************************/

let my_form_value:any ={ }   

if(this.getCurrentUser.activeRole=="counsellor"){
   if(this.pageType=="Add"){
    my_form_value = myDictionary;
    my_form_value['action'] = "add";

   }else if(this.pageType=="Edit"){
    my_form_value = myDictionary;
    my_form_value['action'] = "update";
   }else{ 
   } 
}

if(this.getCurrentUser.activeRole=="manager"){ 
  my_form_value = myDictionary;
  my_form_value['action'] = "approve";
  my_form_value["manager_id"] = this.getCurrentUser.id;  
}

 my_form_value['salestype'] = this.salestype; 
debugger
  this.commonService.post('sales/saveSalesData',my_form_value).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body",""); 
      })
    ).subscribe((res:any) => {  
    debugger  
    this.serviceFactory.notification(res.message,res.status);
    if(res.status){ 
      this.backDateTemplateRef?.close();
      this.prevTemplateRef.close();
      let queryParams = {}
      if(this.getCurrentUser.activeRole=="account" || this.getCurrentUser.activeRole=="ops"){ 
        queryParams = {team: myDictionary.team_id}
      } 
      this.router.navigate(['../../'],{
        queryParams:queryParams,
        relativeTo: this.route
      });

      
    } 
  })

 
}

 
 

 

onReject_Salesform(SF_form:any){
  debugger
     
  let dialogRef = this.dialog.open(RejectionReasonComponent,{ 
    width:'820px',  
    autoFocus:false,
    restoreFocus:false,
    data:{
      reject_reason_id:this.salesformData['reject_reason_id']?this.salesformData['reject_reason_id']:[],
      reject_reason_comment:this.salesformData['process_comment'],
      sales_id:SF_form.value['sales_id'],
      salestype:this.salestype
    }, 
  });
  
  dialogRef.beforeClosed().subscribe(result => {
    if(result){
      debugger 
      let queryParams = {}
      if(this.getCurrentUser.activeRole=="account" || this.getCurrentUser.activeRole=="ops"){ 
        queryParams = {team: SF_form.value.team_id}
      } 
      this.router.navigate(['../../'],{
        queryParams:queryParams,
        relativeTo: this.route
      });
    }       
  })

  } 

onAccountApprove_Salesform(SF_form:any){
    debugger 
 
    let myDictionary  = SF_form.value;  

    let dialogRef = this.dialog.open(AccountApproveComponent,{ 
      width:'820px',  
      autoFocus:false,
      restoreFocus:false,
      disableClose: true,
      data:{
        type:"Add",
        getPaymentType:this.getPaymentType,
        customer_name:myDictionary.leadDetails.customer_name,
        sales_date:moment(myDictionary.leadDetails.sales_date).format('DD MMM YYYY'),
        mode_of_payment:myDictionary.paymentDetails.mode_of_payment,
        payment_file:myDictionary.paymentDetails.payment_file,
        sales_id:myDictionary['sales_id'],  
        salestype:this.salestype
      }, 
    });
    
    dialogRef.beforeClosed().subscribe(result => {
      if(result){
        debugger 
        let queryParams = {}
        if(this.getCurrentUser.activeRole=="account" || this.getCurrentUser.activeRole=="ops"){ 
          queryParams = {team: SF_form.value.team_id}
        } 
        this.router.navigate(['../../'],{
          queryParams:queryParams,
          relativeTo: this.route
        });
      }       
    })
  
 } 
  
  
 

 
  
getGST(val: any){
  //debugger
   var get_GST = (Number(val) * 18)/100;
   return Number(get_GST.toFixed())
}

 ordinal_suffix_of(i:any) { 
  var j = i % 10,
      k = i % 100;
  if (j == 1 && k != 11) {
      return i + "st";
  }
  if (j == 2 && k != 12) {
      return i + "nd";
  }
  if (j == 3 && k != 13) {
      return i + "rd";
  }
  return i + "th";
} 
setInputVal(ngModel:any,value:string){ 
   debugger
   console.log("ngModel.value====="+ngModel.value)
   console.log("value====="+value)
  if(ngModel.value=="" || ngModel.value==null || ngModel.value==undefined || ngModel.value!=value){
    ngModel.control.setValue(value);
  }
   
}
openDate(elm:any){
  debugger
console.log(elm)
}

 
 

getAge(dateString:any) {
  var today = new Date();
  var birthDate = new Date(dateString);
  var age = today.getFullYear() - birthDate.getFullYear();
  var m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
  }
  return age;
}

async getDataByPinCode(){
    debugger
    if (!this.salesformData['country'] || !this.salesformData['pincode'] || this.countryData.length==0) {
      return
    }

  let getISO2 = this.countryData.filter((elm:any) => elm.name == this.salesformData['country'])[0];

  if(!getISO2){
    return
   }
  this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

  fetch("https://api.worldpostallocations.com/pincode?postalcode="+this.salesformData['pincode']+"&countrycode="+getISO2.iso2).then(response => response.json())
  .then(res => {  
    this.serviceFactory.loadingStop("body","");
    if(res.status && res.result.length>0){
      this.salesformData['state'] = res.result[0].state;
      this.salesformData['city'] =  res.result[0].district;
      this.disabledAfterElmBlur['state'] = true;
      this.disabledAfterElmBlur['city'] = true
     }else{
      this.serviceFactory.loadingStop("body",""); 
      this.salesformData['state'] = "";
      this.salesformData['city'] = "";
      this.disabledAfterElmBlur['state'] = false;
      this.disabledAfterElmBlur['city'] = false 
    }
    
    
  })
  .catch(error => {
    this.serviceFactory.loadingStop("body",""); 
    this.salesformData['state'] = "";
    this.salesformData['city'] = "";
    this.disabledAfterElmBlur['state'] = false;
    this.disabledAfterElmBlur['city'] = false 
  });

 
}
 

viewKyc(){
  debugger

  this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

  this.commonService.post('miscellaneous/getPanfile',{
    leadId:this.salesformData.leadId,
    salesType:this.salestype
  }).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res) => {  
    debugger  
    if(res.status){ 
      let dialogRef = this.dialog.open(FilePreviewComponent,{ 
         maxWidth:'1000px',  
         maxHeight: 'calc(100vh - 90px)',
        autoFocus:false,
        restoreFocus:false,
        panelClass: 'chat-box-container',
        data:{ 
          file:res.data
        }, 
      });
      
      dialogRef.beforeClosed().subscribe(result => {
        if(result){
          debugger 
         
        }       
      })
    }else{
      this.serviceFactory.notification(res.message,res.status); 
    }
  
}) 
   

}

stepChanged(event:any, stepper:any){
  debugger
 // stepper.selected.interacted = false;
 this.varStepChanged[event.previouslySelectedIndex] = true
}

gggggg(){
  debugger
//   for (let [index, element] of this.myStepper.steps.toArray().entries()) {
//     this.myStepper.selectedIndex = index;  
//  }

//  for (let [index, element] of this.myStepper.steps.toArray().entries()) {
//    console.log(index);
//    this.myStepper.selectedIndex = index;  
//    if(element.hasError){
//       this.myStepper.selectedIndex = index;
//       break;
//     }
//  }
}
}
 