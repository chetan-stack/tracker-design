import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalesModuleConst, SalesRoutingModule } from './sales-routing.module'; 
import { SharedModule } from '../shared.module'; 
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { RejectionReasonComponent } from './dialog/rejection-reason/rejection-reason.component';
import { AccountApproveComponent } from './dialog/account-approve/account-approve.component';
import { ViewRiskProfileComponent } from './dialog/view-risk-profile/view-risk-profile.component'; 
import { ViewUserInfoModule } from '../dialog/view-user-info/view-user-info.module';
import { FilePreviewModule } from '../dialog/file-preview/file-preview.module';
import { DownloadModule } from '../dialog/download/download.module';
import { EnachCancelRequestModule } from '../dialog/enach-cancel-request/enach-cancel-request.module'; 
import { ViewPaymentHistoryComponent } from './dialog/view-payment-history/view-payment-history.component';
import { UpdateLeadOriginModule } from '../dialog/update-lead-origin/update-lead-origin.module';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search'; 
import { BulkUploadModule } from '../dialog/bulk-upload/bulk-upload.module';
 
 

@NgModule({
    declarations: [
        SalesModuleConst,
        CustomerDetailsComponent,
        RejectionReasonComponent,
        AccountApproveComponent,
        ViewRiskProfileComponent,
        ViewPaymentHistoryComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        SalesRoutingModule,
        ViewUserInfoModule,
        FilePreviewModule,
        DownloadModule,
        EnachCancelRequestModule,
        UpdateLeadOriginModule,
        NgxMatSelectSearchModule,
        BulkUploadModule
    ]
})
export class SalesModule { }

