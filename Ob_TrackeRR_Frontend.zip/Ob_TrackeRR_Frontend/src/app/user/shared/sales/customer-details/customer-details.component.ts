import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { finalize } from 'rxjs/operators'; 
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';
import { FilePreviewComponent } from '../../dialog/file-preview/file-preview.component';
import { ViewRiskProfileComponent } from '../dialog/view-risk-profile/view-risk-profile.component';
 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
   // {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}},
   
    
  ],
}) 
 
export class CustomerDetailsComponent implements OnInit {

sa_page_Id:any;
team_Params:any;
getCurrentUser:any = {}; 
pageType:string;
moment = moment;
product_color:any= {};
product_label:any= {}; 
countryData:any=[];
getPaymentType:any=[]; 

 
 
  
salesformData:any = { 
  product_detail:[], 
  journey_status:[]
}
selectedTabs:any = 0; 
 @ViewChild('ngSalesFormElm') public ngSalesFormElm: NgForm;
 @ViewChild('elmTabGroup') public elmTabGroup: any;
 salestype:any;
  constructor(
    private commonService: CommonService,
    private serviceFactory: ServiceFactory,
    private dataFactory: DataFactoryService,
    private route:ActivatedRoute,
    public dialog: MatDialog,
    private router: Router,
    private el: ElementRef,
  ) {
    this.sa_page_Id = this.route.snapshot.params['id'];
    route.queryParams.subscribe(p => { 
      debugger  
      if(p.team){  
        this.team_Params = p.team
      }

      this.salestype = p.salestype;
    })

    
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
    this.pageType = route.snapshot.data['type'];  

    this.commonService.get('sales/getPaymentList').subscribe((res:any) => { 
      this.getPaymentType = res.data
    })
   
    this.loadCountryData();
    this.loadCustomerData(); 
  }

  ngOnInit(): void {
      
  }

  ngAfterViewInit(){ 
  }
 

  loadCustomerData(){
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('sales/customerDetailBySalesId',{sales_id:this.sa_page_Id}).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => { 
      if(res.status){ 
        let data = res.data; 
       this.salesformData = data;
       this.loadSalesForm_Data();
      }
      
    })
  }

  
  loadSalesForm_Data(){ 
    debugger   
    this.commonService.post('sales/getSalesDataById',{sales_id:this.sa_page_Id}).subscribe((res:any) => {  
      debugger 
      let data =res.data; 
      this.salestype = data.sales_type
      this.salesformData = Object.assign(this.salesformData, data);
    })   
 }
 
  loadCountryData(){
    this.commonService.get('sales/countryData').subscribe((res:any) => { 
      if(res.status){
       this.countryData = res.data
      }
      
    })
  }

  
  async handleFileInput(event:any,ngModel:any){ 
    debugger  
   let validFile =  await this.serviceFactory.fileFalidation(event.target.files[0],5,['png','jpg','jpeg','pdf']); 
   debugger
   if(!validFile){
    debugger
     event.target.value = "";  
   }else{  
        var formData = new FormData();
        formData.append(ngModel, event.target.files[0]);   
        this.commonService.post('sales/saveSalesFormFile',formData).subscribe((res:any) => {  
          debugger 
          this.serviceFactory.notification(res.message,res.status); 
          if(res.status){ 
            this.salesformData[ngModel] = res.data[ngModel];  
          }
      
         })  
   } 
  }
  onClickStatus(elm:any){
    debugger 

   if(elm.statusName == "KYC Filled"){
    this.viewKyc()
   }else if(elm.statusName == "Risk Profile"){
    this.loadRiskProfile_Data()
   }
   else if(elm.statusName == "Signed Agreement"){
    this.loadAgreementFile_Data()
   }else if(elm.statusName == "Approved From Manager"){
    //this.loadAgreementFile_Data()
   }


  }

  loadAgreementFile_Data(){   
    debugger  
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('miscellaneous/opsAgreementFile',{ 
      sales_id:this.sa_page_Id
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      debugger 
      if(res.status){
        let data =res.data; 

        //var url = window.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = data.agreement_file_name;
       // a.download = "filename.pdf";
        document.body.appendChild(a); // we need to append the element to the dom -> otherwise it will not work in firefox
        a.click();    
        a.remove(); 

      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
     
       
     })   
 }

  loadRiskProfile_Data(){   
    debugger  
    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('miscellaneous/getRiskProfile',{ 
      sales_id:this.sa_page_Id
    }).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {  
      debugger 
      if(res.status){
        let data =res.data; 
        let dialogRef = this.dialog.open(ViewRiskProfileComponent,{ 
          width:'820px',  
          minHeight: '300px',
          autoFocus:false,
          restoreFocus:false,
          data:data, 
        });
        
        dialogRef.beforeClosed().subscribe(result => {
          if(result){
            debugger 
           
          }       
        })
      }else{
        this.serviceFactory.notification(res.message,res.status); 
      }
     
       
     })   
 }

 

 get_total_informed_investor_amount(){
    if (this.salesformData['duration'] == 1) { 
    return this.salesformData['total_informed_investor_amount'] = parseInt(this.salesformData['informed_investor_amount'])*2;
   } else {
      return this.salesformData['total_informed_investor_amount'] = parseInt(this.salesformData['informed_investor_amount'])*10;
   } 
 }

 ordinal_suffix_of(i:any) { 
  var j = i % 10,
      k = i % 100;
  if (j == 1 && k != 11) {
      return i + "st";
  }
  if (j == 2 && k != 12) {
      return i + "nd";
  }
  if (j == 3 && k != 13) {
      return i + "rd";
  }
  return i + "th";
} 
getAge(dateString:any) {
  var today = new Date();
  var birthDate = new Date(dateString);
  var age = today.getFullYear() - birthDate.getFullYear();
  var m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
  }
  return age;
}

onVerify(){
    
  Swal.fire({ 
    title: 'Verify!',
    html: 'Are you sure you want to verified all data?',
    icon: 'warning', 
 customClass: {
   confirmButton: 'mat-flat-button mat-button-base mat-primary',
   cancelButton: 'mat-stroked-button mat-button-base ',
   container: 'modal-yes-no Modal_Delete', 
   actions: 'modal-btn-yes-no mb-4',
   //  header: 'pt-4', 
 },
 width: '36em',
 showCloseButton: true,
 buttonsStyling: false,
 showCancelButton: true,
 confirmButtonText: 'Verify',
 cancelButtonText: 'Cancel' , 
 focusConfirm:false, 
 focusCancel:true,     
}).then((result) => {
  debugger
   if (result.isConfirmed) {
     this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
     let my_form_value:any ={ }  
     my_form_value['action'] = "approve";
     my_form_value['salestype'] = this.salestype;  
     my_form_value['sales_id'] = this.sa_page_Id;  
     
     this.commonService.post('sales/saveSalesData',my_form_value).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body",""); 
      })
    ).subscribe((res:any) => {  
      debugger  
      this.serviceFactory.notification(res.message,res.status);
      if(res.status){ 
        this.router.navigate(['../../'],{
          queryParams:{team: this.salesformData.team_id},
          relativeTo: this.route
        });
  
        
      } 
    }) 
   }
 }) 
}

viewKyc(){
  debugger

  this.serviceFactory.loadingStart("body","Please wait while loading...",""); 

  this.commonService.post('miscellaneous/getPanfile',{
    leadId:this.salesformData.leadId,
    salesType:this.salestype
  }).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res) => {  
    debugger  
    if(res.status){ 
      let dialogRef = this.dialog.open(FilePreviewComponent,{ 
         maxWidth:'1000px',  
         maxHeight: 'calc(100vh - 90px)',
        autoFocus:false,
        restoreFocus:false,
        panelClass: 'chat-box-container',
        data:{ 
          file:res.data
        }, 
      });
      
      dialogRef.beforeClosed().subscribe(result => {
        if(result){
          debugger 
         
        }       
      })
    }else{
      this.serviceFactory.notification(res.message,res.status); 
    }
  
}) 
   

}
}
