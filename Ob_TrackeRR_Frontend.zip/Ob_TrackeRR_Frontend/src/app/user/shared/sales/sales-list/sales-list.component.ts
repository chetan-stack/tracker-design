import { BreakpointObserver } from '@angular/cdk/layout';
import { KeyValue } from '@angular/common';
import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { fromEvent, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';
import { BulkUploadComponent } from '../../dialog/bulk-upload/bulk-upload.component';
import { DownloadComponent } from '../../dialog/download/download.component';
import { EnachCancelRequestComponent } from '../../dialog/enach-cancel-request/enach-cancel-request.component'; 
import { UpdateLeadOriginComponent } from '../../dialog/update-lead-origin/update-lead-origin.component';
import { ViewUserInfoComponent } from '../../dialog/view-user-info/view-user-info.component'; 
import { ViewPaymentHistoryComponent } from '../dialog/view-payment-history/view-payment-history.component';
 
const allStatus_FilterList:any =  {
  1:"New",
  2:"Created",
  3:"Pending",
  4:"Reject by Accounts",
  //5:"Accept by Accounts",
  6:"Reject by Manager",
  7:"Accept by Manager",
  8:"Auto approved by manager",
  'ops_verified':"Verified", 
 }
 
const allStatus_FilterList_byRole:any = {
  counsellor:[1,2,4,6,7],
  manager:[1,2,4,6],
  saleshead:[1,2,4,6,7],
  account:[7,2,4],
  ops:[2,4,7,'ops_verified']
}

const columns_show =  {  
  'id':'S No.', 
  'customer_name':'Name',  
  'customer_email_id':'Email',
  'leadId':'Lead No.',
  'customer_id':'Cust. ID', 
  'customer_phone_no':'Phone',
  'counsellor_name':'Counsellor Name', 
  'center_name':'Center',
  'sales_date':'Sales Date',
  'product':'Product',
  'access_name':'Sales Type',
  'informed_investor':'Informed Investor',
  'duration':'Subscription Duration' , 
  'alternate_email':'Alternate Email ID',
  'address_1':'Address 1',
  'city':'City',
  'pincode':'Pincode ', 
  'state':'State ', 
  'country':'Country ', 
  'tenure_extended':'Tenure Extended',
  'amount':'Amount', 
  'amount_with_gst':'Amount + GST', 
  'mode_of_payment':'Mode of Payment',  
  'payment_received_date':'Payment Rec. Date',
  'enach_sign_skip_date':'Enach Date',
  'client_gst':'Client GST',
  'secrets':'Secrets Pitched', 
  'secrets_categories':'Secrets Categories',
  'financial_planing':'Financial Planning',
  //'agreement_file':'Agreement File',
  'manager_approve_date':'Activation Date',
  'enach_status':'e-Nach Status', 
  'status':'Status',
  'action':'Actions',   
 
}
 
 

const ColumnDefaultShow:any  = {
  counsellor:[
    'id', 
    'customer_name', 
    'customer_email_id', 
    'leadId', 
    'customer_id', 
    'sales_date',
    'product',
    'access_name', 
    'amount', 
    'amount_with_gst', 
    'payment_received_date',
    'enach_sign_skip_date', 
    'enach_status',
    'status',
    'action' 
  ],
 
  manager:[
    'id', 
    'customer_name',  
    'customer_email_id', 
    'leadId', 
    'customer_id', 
    'counsellor_name', 
    'sales_date',
    'product',
    'access_name', 
    'amount', 
    'amount_with_gst',
    'payment_received_date', 
    'enach_sign_skip_date', 
    'enach_status',
    'status',
    'action' 
  ],
  saleshead:[
    'id', 
    'customer_name',  
    'customer_email_id', 
    'leadId', 
    'customer_id', 
    'counsellor_name', 
    'sales_date',
    'product',
    'access_name', 
    'amount', 
    'amount_with_gst',  
    'enach_status',
    'status',
    'action' 
  ],
  account:[
    'id', 
    'customer_name', 
    'customer_email_id', 
    'leadId', 
    'customer_id', 
    'counsellor_name', 
    'center_name',
    'sales_date',
    'product',
    'access_name', 
    'amount', 
    'amount_with_gst',
    'mode_of_payment',
    'payment_received_date', 
    'enach_sign_skip_date', 
    'enach_status',
    'status', 
    'action'  

  ],
  ops:[
    'id', 
    'customer_name', 
    'customer_email_id', 
    'leadId', 
    'customer_id', 
    'counsellor_name', 
    'center_name',
    'sales_date',
    'access_name',
    'product', 
    'amount', 
    'amount_with_gst',
    'payment_received_date',  
    'enach_sign_skip_date',
    'manager_approve_date',
    'enach_status',
    'status',
    'action' 
  ],
  admin:[
    'id', 
    'customer_name', 
    'customer_email_id', 
    'leadId', 
    'customer_id', 
    'counsellor_name', 
    'center_name',
    'sales_date',
    'access_name',
    'product', 
    'amount', 
    'amount_with_gst',
    'payment_received_date',  
    'enach_sign_skip_date',
    'manager_approve_date',
    'enach_status',
    'status',
    'action' 

  ],
  }


const filterForm:any = {
  filter_Counsellor:[], 
  filter_access_ids:[],
  filter_Center:[],
  filter_Status:[],
  filter_Enach:[],
  filter_Product:[], 
  filter_secrets_categories:[],
  filter_lead_origin_id:[],

  filter_sales_date:{
    start_date:null,
    end_date:null,
  }, 
  filter_action_date:{
    start_date:null,
    end_date:null,
  }, 
  
  filter_payment_date:{
    start_date:null,
    end_date:null,
  }, 

  filter_enach_date:{
    start_date:null,
    end_date:null,
  }, 

  filter_financial_planing:null,

  filter_share_data_filter:null,
  is_pmp_service_filter:false,
  identifier_id_filter:null,
}
 

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

@Component({
  selector: 'app-sales-list',
  templateUrl: './sales-list.component.html',
  styleUrls: ['./sales-list.component.scss'], 
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    //{provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
})
export class SalesListComponent implements OnInit {
  selectedRowIndex:any;
  getCurrentUser: any ={};
  moment = moment; 
  product_label:any={};
  product_color:any = {} ; 

  center_list:any = {};
  center_color:any = {};

  salesType_list:any;
  salesType_key:any = {};
  salesType_color:any = {};

  access_list:any=[];
  team_Params:any = [];
  salestype_Params:any;
  getTeamListData:any=[];

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}

  allTeamList:any=[];   

  gridDataSource = new MatTableDataSource();
  allColumnsForShow:any = {}
  Column_type_defaultShow:any = []
   

  allStatus_FilterList:any =  {}
  showStatus_FilterList:any = [];
  filter_product_list:any = [];


  
  filter_Search:string = ""; 
  
  filter_fieldData:any = JSON.parse(JSON.stringify(filterForm));
  filter_ApplyedCount:any = 0;

 
  

  

  storedAllData: any; 
  filterApiDataOption:any = {};
  Show_More_filter:any =false;
  enachStatus_List:any =[]; 
  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;
  @ViewChild('ngFilterFormElm') public ngFilterFormElm: NgForm|any;
  
  constructor(
    private route: ActivatedRoute,
    private dataFactory: DataFactoryService,
    private serviceFactory: ServiceFactory,
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver, 
    private router: Router,
    private dialog: MatDialog,
  ) { 
    
    //this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
    

 
    this.product_color = this.dataFactory.all_product_color;
    this.product_label = this.dataFactory.all_product_label; 
  
    this.salesType_list = dataFactory.salesType_list; 
    this.salesType_key = dataFactory.get_salesType_key;
    this.salesType_color = dataFactory.salesType_Color;
    this.center_list = dataFactory.all_centerList;
     this.center_color = dataFactory.all_centerColor;

     this.Status_Name = this.dataFactory.All_Status_Name;
     this.Status_Color = this.dataFactory.All_Status_Color;
     this.Status_Icon = this.dataFactory.All_Status_Icon;  

    this.allColumnsForShow = columns_show;
    this.allStatus_FilterList = allStatus_FilterList
    
   
    if(this.getCurrentUser.activeRole=="counsellor" || this.getCurrentUser.activeRole=="manager" || this.getCurrentUser.activeRole=="saleshead"){
      
       let access_name = this.getCurrentUser.sales_type.map((x:any) => x.access_name);
       if(access_name.includes('dwn_new') || access_name.includes('dwn_renewal')){
          this.filter_product_list = {
            '[14]':'DWN',
            '[14,12]':'DWN + MPO',
          }
       }else{
        if(access_name.includes('retail_new') || access_name.includes('retail_renewal')){
          this.filter_product_list = {
            '1':'5in5 ',
            '12':'MPO',
            '1,12':'Combo (5in5 + MPO)',
            }
        }
       }
        
     }else{
      this.filter_product_list = {
        '1':'5in5 ',
        '12':'MPO',
        '1,12':'Combo (5in5 + MPO)',
        '[14]':'DWN',
        '[14,12]':'DWN + MPO',
        }
     }


     
     route.queryParams.subscribe((p:any) => {   
       this.refreshGrid("route"); 
        debugger
        
        

        const countFilteredData = p.sales_countFiltered?JSON.parse(atob(p.sales_countFiltered)):null;
        if(countFilteredData?.search){   
          this.filter_Search = countFilteredData['search'];
       }
        if(countFilteredData?.status){   
           this.filter_fieldData.filter_Status = countFilteredData['status']
        }
        if(countFilteredData?.center_id){   
          this.filter_fieldData.filter_Center = countFilteredData['center_id']
        }
        if(countFilteredData?.lead_origin_id){   
          this.filter_fieldData.filter_lead_origin_id = countFilteredData['lead_origin_id']
        }
        if(countFilteredData?.access_ids){   
          this.filter_fieldData.filter_access_ids = countFilteredData['access_ids']
        } 
        if(countFilteredData?.date){   
          this.filter_fieldData.filter_sales_date.start_date = countFilteredData['date'].from_date;
          this.filter_fieldData.filter_sales_date.end_date = countFilteredData['date'].to_date;
        }
        if(countFilteredData?.filter_payment_date){   
          this.filter_fieldData.filter_payment_date.start_date = countFilteredData['filter_payment_date'].from_date;
          this.filter_fieldData.filter_payment_date.end_date = countFilteredData['filter_payment_date'].to_date;
        }
        if(countFilteredData?.share_data_filter){   
          this.filter_fieldData.filter_share_data_filter = countFilteredData?.share_data_filter;
        } 
        if(countFilteredData?.is_pmp_service){   
          this.filter_fieldData.is_pmp_service_filter = countFilteredData?.is_pmp_service;
        }
        if(countFilteredData?.identifier_id){    
          this.filter_fieldData.identifier_id_filter = countFilteredData['identifier_id']
        }
        
        this.dataFactory.set_data('countFilteredData',null);
      


       if(p.team){ //   account || ops 
       // //debugger    
        this.team_Params = p.team.split(',').map((x:any) => Number(x));  
        this.dataFactory.get_TeamList().subscribe((res: any[]) => { 
          if(res.length>0){ 
             let teamData = res.filter((elm:any) => elm.id == Number(this.team_Params))[0];  
             this.access_list =  teamData.access_id;
             this.loadGrid_Data();  
          } 
       })
       }else{
        let teamData = this.getCurrentUser.sales_type.map((x:any) => x.id); 
        this.access_list =  teamData;

        this.loadGrid_Data();
       } 

       this.Show_More_filter = false;
    });
      
    
    this.getEnachStatusList();

  }

  ngOnInit(): void {
    this.Column_type_defaultShow = ColumnDefaultShow[this.getCurrentUser.activeRole];
    this.showStatus_FilterList = allStatus_FilterList_byRole[this.getCurrentUser.activeRole];
    
  }

  

  loadTeamListByParent() { 

    if(this.allTeamList.length>0){
      return
    }
    let dataOption:any = { 
     parent_id:this.getCurrentUser.id
   }
    this.commonService.post('userProfile/getTeamListByParent',dataOption).subscribe((res:any) => {
      //debugger
      this.allTeamList = res.data;  
    })
 }

  
ngAfterViewInit(): void {
  

  fromEvent(this.textSearch_main.nativeElement, 'keyup').pipe(debounceTime(250),distinctUntilChanged(),tap(() => {
    //debugger
    this.paginator.pageIndex = 0,
     this.loadGrid_Data();
  })
).subscribe();



    // reset the paginator after sorting
 this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);

 // on sort or paginate events, load a new page
 merge(this.sort.sortChange, this.paginator.page)
 .pipe(
     tap(() => this.loadGrid_Data())
 )
 .subscribe();
}

loadGrid_Data() {
  //debugger
 
  
  let json = JSON.stringify(this.filter_fieldData.filter_Status);
  let masterStatues =  JSON.parse(json);
  let ops_verified;

  if(this.getCurrentUser.activeRole == "ops"){
    if(masterStatues.includes('ops_verified')){      
      const index = masterStatues.indexOf('ops_verified');
      if (index > -1) {
        masterStatues.splice(index, 1);
      } 
      ops_verified = 'yes'
    }

    if(masterStatues.includes(2)){    
      ops_verified = 'no'
    }
  
  }
  
 
   this.filterApiDataOption = {
    search: this.filter_Search,
    status: masterStatues, 
    product: this.filter_fieldData.filter_Product,
    short_key: this.sort?this.sort.active:"",
    short_order: this.sort?this.sort.direction:"",
    page: this.paginator?this.paginator.pageIndex:0,
    perpage: this.paginator?this.paginator.pageSize:20,
    sales_from_date: this.filter_fieldData.filter_sales_date.start_date ? moment(this.filter_fieldData.filter_sales_date.start_date).format('YYYY-MM-DD') : '', 
    sales_to_date: this.filter_fieldData.filter_sales_date.end_date ? moment(this.filter_fieldData.filter_sales_date.end_date).format('YYYY-MM-DD') : '',

    from_date: this.filter_fieldData.filter_action_date.start_date ? moment(this.filter_fieldData.filter_action_date.start_date).format('YYYY-MM-DD') : '', 
    to_date: this.filter_fieldData.filter_action_date.end_date ? moment(this.filter_fieldData.filter_action_date.end_date).format('YYYY-MM-DD') : '',

    payment_from_date: this.filter_fieldData.filter_payment_date.start_date ? moment(this.filter_fieldData.filter_payment_date.start_date).format('YYYY-MM-DD') : '', 
    payment_to_date: this.filter_fieldData.filter_payment_date.end_date ? moment(this.filter_fieldData.filter_payment_date.end_date).format('YYYY-MM-DD') : '',
    
    enach_sign_skip_from_date: this.filter_fieldData.filter_enach_date.start_date ? moment(this.filter_fieldData.filter_enach_date.start_date).format('YYYY-MM-DD') : '',
    enach_sign_skip_to_date: this.filter_fieldData.filter_enach_date.end_date ? moment(this.filter_fieldData.filter_enach_date.end_date).format('YYYY-MM-DD') : '',


    counsellors:this.filter_fieldData.filter_Counsellor,  
    access_ids :this.filter_fieldData.filter_access_ids,
    secrets_categories :this.filter_fieldData.filter_secrets_categories,
    team_id:this.team_Params,
    ops_verified:ops_verified,
    center:this.filter_fieldData.filter_Center,
    financial_planing:this.filter_fieldData.filter_financial_planing,
    enach:this.filter_fieldData.filter_Enach,
    lead_origin_id:this.filter_fieldData.filter_lead_origin_id,

    share_data_filter:this.filter_fieldData.filter_share_data_filter,
    is_pmp_service:this.filter_fieldData.is_pmp_service_filter,
    identifier_id:this.filter_fieldData.identifier_id_filter
  }

      
 

  this.serviceFactory.loadingStart("body","Please wait while loading...","");
  this.commonService.post('sales/getSalesDataList',this.filterApiDataOption).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res:any) => {
    if(res.status){
      this.storedAllData = res.data;
      this.bindGridData(res.data.dataobject);
    }else{
      this.storedAllData = undefined;
      this.bindGridData([]);
    }

  })

 
  this.filter_ApplyedCount = this.serviceFactory.getFilterAppliedCount(this.filter_fieldData);
 
 

}

bindGridData(data:any) {
  this.gridDataSource = new MatTableDataSource(data);
  this.gridDataSource.sort = this.sort;
  this.bindTableGridWidth();
}

 
 
changeColumnFilter(event: any,elm:any){
    //debugger 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");  
    setTimeout(() => {
      let selected:any = []; 
      elm.options._results.forEach((element:any) => {
        if(element.selected){
           selected.push(element.value)
        }
      });
      this.Column_type_defaultShow = selected;
      this.serviceFactory.loadingStop("body","");
       //debugger
    }, 200);

    setTimeout(() => {
      this.bindTableGridWidth();
    }, 700);
    
  }
  
 
onFilterGrid() {
  this.paginator.pageIndex = 0,
    this.loadGrid_Data();
}
onFilter_PaymentDateRange_Grid(data:any){ 
  if(data.value){
    this.onFilterGrid()
  }
}
 
onFilter_SalesDateRange_Grid(data:any){ 
  if(data.value){
    this.onFilterGrid()
  }
}
 
onFilter_DateRange_Grid(data:any){ 
  if(data.value){
    this.onFilterGrid()
  }
}

bindTableGridWidth() {

  let w = 0;
  let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
  for (let i = 0; i < children.length; i++) {
    let header = children[i].style.minWidth;
    let string = header.replace("px", "");
    var number = string.replace("%", "");
    w = w + Number(number);
  }

  if (this.data_table._elementRef.nativeElement) {
    this.data_table._elementRef.nativeElement.style.minWidth = w + 'px';
    
    document.querySelector<any>('.Grid_No_data').style.minWidth = w + 'px';

  }

}

// Preserve original property order
originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
  return 0;
}

textMask(type: any, value: any) {
  //
  if (type == 'phone' && value) {
    var part1, part2;
    part1 = value.slice(0, 3);
    part2 = value.toString().substr(-2);
    return part1 + "********" + part2;
  } else if (type == 'email' && value) {

    var avg, splitted, part1, part2;
    splitted = value.split("@");
    part1 = splitted[0];
    part1 = part1.slice(0, 3);
    part2 = splitted[1].substr(-4);
    return part1 + "*******@****" + part2;
  } else {
    return value
  }
}

openDialogUserInfo(element:any){
  //debugger
  const dialogRef = this.dialog.open(ViewUserInfoComponent, {
    height: 'auto',
    width: '610px',
    data: {
      name:element.customer_name,
      email:element.customer_email_id,
      phone:element.customer_phone_no
    },
  });

  dialogRef.beforeClosed().subscribe((result: any) => {
    if (result) {
      this.loadGrid_Data();
    }
  })

}


refreshGrid(mode:any) {
  //debugger
  this.Column_type_defaultShow = ColumnDefaultShow[this.getCurrentUser.activeRole];
  if(this.paginator){
    this.paginator.pageIndex = 0;  
    this.sort.active = "";
    this.sort.direction = ""; 
    
    this.filter_Search="";
    this.filter_fieldData = JSON.parse(JSON.stringify(filterForm));
    this.filter_fieldData.filter_Counsellor = this.getCurrentUser.activeRole=="counsellor"?[this.getCurrentUser.id]:[];
  }
 

  /*
  if(this.sort){ 
    this.sort.sort({id: '', start: 'asc',  disableClear: false});
  }
  */

if(mode=="reset"){
  this.loadGrid_Data();
}
  

}

jsonP(data:any){
  return data?JSON.parse(data):[] 
   
 
}

jsonS(data:any){
  return data?JSON.stringify(data):""    

}

showRejectHistory(element:any,templateRef: TemplateRef<any>){
 
  //debugger 
  let dialogRef; 
 
  this.commonService.post('sales/getRejectReasonBySales',{salesId:element.id}).subscribe((res:any) => {  
    //debugger 
    if(res.status){
        dialogRef = this.dialog.open(templateRef, {
          height: 'auto',
          width: '900px',
          data: res.data, 
        });
    }else{
      this.serviceFactory.notification(res.message,res.status); 
    }
    

  }) 


   
}
getNumber(val:any){
  return Number(val);
 }

 

onClickdeleteSalesUser(id: any){ 
  //debugger 

    Swal.fire({ 
      title: 'Delete This Form',
      html: 'Are you sure you want to delete this form?',
      
      imageUrl:'assets/images/Delete_icon.png',
      customClass: { 
        container: 'modal-yes-no Modal_Delete',
        confirmButton: 'mat-raised-button mat-button-base mat-warn',
        cancelButton: 'mat-raised-button mat-button-base mat-accent',
        actions: 'modal-btn-yes-no mb-4',
        image: 'modal-icon-top',
      },
      width: '36em',
      showCloseButton: false,
      buttonsStyling: false,
      showCancelButton: true,
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel', 
      preConfirm: (preStatus) => {
        //debugger
        return new Promise((resolve) => {
          this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
          this.commonService.post('sales/deleteSalesForm ',{sales_id:id}).pipe( 
            finalize(() => {  
              this.serviceFactory.loadingStop("body","");
              resolve(true) ;  
            })
          ).subscribe((res:any) => { 
            this.serviceFactory.notification(res.message,res.status); 
            if(res.status){
              this.loadGrid_Data();
            } 
          }); 
        
      })

      },  
  }).then((result) => {
    //debugger 
    
  }) 
    
} 

loadAgreementFile_Data(element:any){   
  //debugger  
  this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
  this.commonService.post('miscellaneous/opsAgreementFile',{ 
    sales_id:element.id
  }).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body","");
    })
  ).subscribe((res:any) => {  
    //debugger 
    if(res.status){
      let data =res.data;  
      var a = document.createElement('a');
      a.href = data.agreement_file_name; 
      document.body.appendChild(a); 
      a.click();    
      a.remove(); 
    }else{
      this.serviceFactory.notification(res.message,res.status); 
    }
   
     
   })   
}


downloadPdf(){
  //debugger 
  let stringify = JSON.stringify(this.Column_type_defaultShow);
  let parse = JSON.parse(stringify);

  
  let colShow:any = []
    parse.forEach((element:any) => {
      colShow.push({name:element,label:this.allColumnsForShow[element]})
    });

 
    let stringify_dataOption = JSON.stringify(this.filterApiDataOption);
    let dataOption = JSON.parse(stringify_dataOption);  

    let endPoint = 'sales/getSalesDataList';


    let cellW = [];
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number = string.replace("%", ""); 
     cellW.push(Number(number))
    }


      const dialogRef = this.dialog.open(DownloadComponent, {
      width:'600px',
      autoFocus:false, 
      data:{
        endPoint:endPoint,
        fileName:'Sales Form',
        dataOption:dataOption,
        colShow:colShow,
        cellW:cellW
      },
    });
 
}

onSendCancelRequest(elm:any){
  //debugger 
   
  elm['sales_id'] = elm.id;

  if(this.getCurrentUser.activeRole=='ops'){
    elm['action_mode'] = 'new'; 
  }


  let dialogRef = this.dialog.open(EnachCancelRequestComponent,{ 
    width:'820px',  
    autoFocus:false,
    restoreFocus:false,
    disableClose: false,
    data:elm, 
  });
  
  dialogRef.beforeClosed().subscribe((result: any) => {
    if(result){
      //debugger 
      this.loadGrid_Data(); 
    }       
  }) 

} 

paymentHistory(elm:any){
  //debugger
  let dialogRef = this.dialog.open(ViewPaymentHistoryComponent,{ 
    width:'1100px',  
    autoFocus:false,
    restoreFocus:false,
    disableClose: false,
    data:elm, 
  });
  
  dialogRef.beforeClosed().subscribe(result => {
    if(result){
      //debugger 
      //this.loadGrid_Data(); 
    }       
  }) 
}


updateLeadOrigin(elm:any){
  //debugger
  let dialogRef = this.dialog.open(UpdateLeadOriginComponent,{ 
    width:'800px',  
    autoFocus:false,
    restoreFocus:false,
    disableClose: false,
    data:elm, 
  });
  
  dialogRef.beforeClosed().subscribe((result: any) => {
    if(result){
      //debugger 
      //this.loadGrid_Data(); 
    }       
  }) 
}

getEnachStatusList(){
  //debugger 
  this.commonService.get('autopayment/getEnachMasterStatus').subscribe((res:any) => {
    //debugger
    this.enachStatus_List = res.data;  
  })
}

getGST(val: any){
  ////debugger
   var get_GST = (Number(val) * 18)/100;
   return Number(get_GST.toFixed())
}



showDialog_BulkUpload(){
  debugger   
        const dialogRef = this.dialog.open(BulkUploadComponent,{ 
          width:'1000px',
          data:{
            title:'Upload Verified Customer Sales',
            api:'sales/bulkVerifySalesByOPS',
            keyName:'bulk_verify_sales',
            template:'./assets/bulk_sales_verify_by_ops.xlsx'
          }   
        });
      dialogRef.beforeClosed().subscribe(result => {
        if(result){
          debugger 
          this.loadGrid_Data(); 
        }       
      }) 
} 
}

 