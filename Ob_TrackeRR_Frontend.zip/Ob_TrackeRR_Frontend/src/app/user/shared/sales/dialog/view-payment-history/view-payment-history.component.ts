import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-view-payment-history',
  templateUrl: './view-payment-history.component.html',
  styleUrls: ['./view-payment-history.component.scss']
})
export class ViewPaymentHistoryComponent implements OnInit {
  selectedRowIndex:any;
  getCurrentUser: any ={};
  ob_type:any;
  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}
  paymentDataList:any = {
    tranches:{
      adv_installment:[]
    }
    
  };
  payment_status_color:any = {
    "Received":"#34a853",
    "Due":"#0000ff",
    "Failed":"#cc0000",
  }
  product_color:any= {}
  product_label:any= {} 
  constructor(
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private dialogRef: MatDialogRef<ViewPaymentHistoryComponent>,
    private dialog: MatDialog,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    
  ) { 
    this.ob_type = dialogData.access_name;
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon;  
    this.product_label = this.dataFactory.all_product_label;
    this.product_color = this.dataFactory.all_product_color;

    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('sales/getPaymentDtlBySalesId',{sales_id:dialogData.id}).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body",""); 
      })
    ).subscribe((res:any) => {  
      debugger 
       this.paymentDataList = res.data
   
    }) 
  }

  ngOnInit(): void {
  }


  markPaymentDone(elm:any){ 
    debugger
   
  }

ordinal_suffix_of(i:any) {
    i = Number(i);
    var j = i % 10,
        k = i % 100;
    if (j == 1 && k != 11) {
        return i + "<sup>st</sup>";
    }
    if (j == 2 && k != 12) {
        return i + "<sup>nd</sup>";
    }
    if (j == 3 && k != 13) {
        return i + "<sup>rd</sup>";
    }
    return i + "<sup>th</sup>";
}
jsonS(data:any){
  return data?JSON.stringify(data):""    

}
}
