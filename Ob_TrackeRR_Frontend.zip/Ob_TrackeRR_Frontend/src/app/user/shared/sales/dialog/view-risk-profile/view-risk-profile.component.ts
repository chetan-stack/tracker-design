import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
 

@Component({
  selector: 'app-view-risk-profile',
  templateUrl: './view-risk-profile.component.html',
  styleUrls: ['./view-risk-profile.component.scss']
})
export class ViewRiskProfileComponent implements OnInit {
  getCurrentUser: any ={};  
  riskProfileData:any = {} 
  constructor(
    @Inject(MAT_DIALOG_DATA) private componentData: any, 
  ) { 
    this.riskProfileData =componentData
   }
  ngOnInit(): void {
  }
 
}
