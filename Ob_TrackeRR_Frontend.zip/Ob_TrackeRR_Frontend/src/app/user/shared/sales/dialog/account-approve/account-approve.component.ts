import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-account-approve',
  templateUrl: './account-approve.component.html',
  styleUrls: ['./account-approve.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}},
   ],
})
export class AccountApproveComponent implements OnInit {
  getCurrentUser: any ={}; 
  moment = moment;
  accountFormData:any = {}
  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<AccountApproveComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
  ) {
    this.getCurrentUser = this.commonService.getCurrentUser();
    let stringify = JSON.stringify(this.AddEditData);
    this.accountFormData = JSON.parse(stringify)
  }
  ngOnInit(): void {
  }

  
  paymentDialogclose(SF_form:any){
    debugger
    if (SF_form.invalid) {
      return;
   } 

    let myDictionary  = SF_form.value; 
    myDictionary['sales_id'] = this.accountFormData.sales_id; 
    myDictionary['salestype'] = this.accountFormData.salestype; 
    myDictionary['action'] = "approve"; 
    myDictionary["account_id"] = this.getCurrentUser.id; 

    myDictionary['payment_file'] = this.serviceFactory.getFileNameByPath(myDictionary['payment_file']);
    myDictionary['payment_received_date'] = moment(myDictionary['payment_received_date']).format('YYYY-MM-DD'); 

 
   this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
   this.commonService.post('sales/saveSalesData',myDictionary).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body",""); 
    })
  ).subscribe((res:any) => {
    debugger  
   this.serviceFactory.notification(res.message,res.status); 
   if(res.status){ 
     this.dialogRef.close(res);
   }

 }) 

    
  }


  async handleFileInput(event:any,ngModel:any){ 
    debugger  
   let validFile =  await this.serviceFactory.fileFalidation(event.target.files[0],5,['png','jpg','jpeg','pdf']); 
   debugger
   if(!validFile){
    debugger
     event.target.value = "";  
   }else{  
        var formData = new FormData();
        formData.append(ngModel, event.target.files[0]);   
        this.commonService.post('sales/saveSalesFormFile',formData).subscribe((res:any) => {  
          debugger 
          this.serviceFactory.notification(res.message,res.status); 
          if(res.status){ 
            this.accountFormData[ngModel] = res.data[ngModel];  
          }
      
         })  
   } 
  }
 
  
}
