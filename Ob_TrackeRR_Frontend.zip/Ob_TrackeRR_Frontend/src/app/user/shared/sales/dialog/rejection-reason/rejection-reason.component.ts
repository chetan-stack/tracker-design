import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-rejection-reason',
  templateUrl: './rejection-reason.component.html',
  styleUrls: ['./rejection-reason.component.scss']
})
export class RejectionReasonComponent implements OnInit {
  getCurrentUser: any ={};
  pageTypeMode:string;
  
salesType_list:any; 
rejection_list:any = []
  
rejectform_data:any = {}
@ViewChild('rejectform') public rejectform: NgForm;
  constructor(
    @Inject(MAT_DIALOG_DATA) private AddEditData: any,
    private dialogRef: MatDialogRef<RejectionReasonComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
  ) {
    this.getCurrentUser = this.commonService.getCurrentUser();
   // this.pageTypeMode = AddEditData.type;
   this.rejectform_data = AddEditData;

    this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
    this.commonService.post('sales/rejectReason',{}).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body",""); 
      })
    ).subscribe((res:any) => {  
      debugger 
      this.rejection_list = res.data;   
   
    }) 
    
  }
 
  
  ngOnInit(): void {

  }

  ngAfterViewInit(){
   
  }

  rejectDialogclose(R_form:any){
    debugger
   

     if(R_form.value.reject_reason_id.length==0){
      this.serviceFactory.notification("Please select Reason of Rejection.",false); 
      return
     }

    if (R_form.invalid) {
      return;
   } 
    
   let myDictionary  = R_form.value;


   myDictionary['sales_id'] = this.AddEditData.sales_id; 
   myDictionary['salestype'] = this.AddEditData.salestype;
 


   this.serviceFactory.loadingStart("body","Please wait while loading...",""); 
   this.commonService.post('sales/reject',myDictionary).pipe( 
    finalize(() => {  
      this.serviceFactory.loadingStop("body",""); 
    })
  ).subscribe((res:any) => {
    debugger  
   this.serviceFactory.notification(res.message,res.status); 
   if(res.status){ 
     this.dialogRef.close(res);
   }

 }) 

    
  }
}
