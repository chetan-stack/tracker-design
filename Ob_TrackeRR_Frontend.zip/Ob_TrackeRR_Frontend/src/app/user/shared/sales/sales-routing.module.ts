import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { SalesComponent } from './sales.component';

import { SalesListComponent } from './sales-list/sales-list.component';
import { SalesformComponent } from './salesform/salesform.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';

const routes: Routes = [ 
  {
    path: '', component: SalesComponent,  
    data:{pageType:'sales'},   
     children: [    
            {path: '', component: SalesListComponent ,data:{title: 'Sales Form Management'}},
            {path: 'add/:sale_source_id', component: SalesformComponent ,data:{type:"Add", title: 'Sales Form Management'}},
            {path: 'view/:id', component: SalesformComponent ,data:{type:"View", title: 'Sales Form Management'}},


             {path: 'edit/:id', component: SalesformComponent ,data:{type:"Edit", title: 'Sales Form Management'}},
             {path: 'view/:id', component: SalesformComponent ,data:{type:"View", title: 'Sales Form Management'}},
          
          
             {path: 'edit', redirectTo: ''},
             {path: 'view', redirectTo: ''},

             {path: 'customer/edit/:id', component: CustomerDetailsComponent ,data:{type:"Edit", title: 'OPS Dashboard'}}, 
             {path: 'customer/view/:id', component: CustomerDetailsComponent ,data:{type:"View", title: 'OPS Dashboard'}}, 
             {path: 'customer', redirectTo: ''},
        ],  
     }, 
       
];  

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalesRoutingModule { }
export const SalesModuleConst = [  
  SalesComponent,
  SalesListComponent,
  SalesformComponent,
  CustomerDetailsComponent  
];
