import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IncentiveComponent } from './incentive.component';
import { AccountHistoryLiveComponent } from './page/account-history-live/account-history-live.component';
import { AccountHistoryComponent } from './page/account-history/account-history.component';
import { CounsellorHistoryComponent } from './page/counsellor-history/counsellor-history.component';
import { LeadManagementComponent } from './page/lead-management/lead-management.component';
import { ManagerHistoryLiveComponent } from './page/manager-history-live/manager-history-live.component';
import { ManagerHistoryComponent } from './page/manager-history/manager-history.component';

const routes: Routes = [
 
  {
     path: '', component: IncentiveComponent,  
     data:{pageType:'ic'},
     children: [   
      {path: 'counsellor-history', component: CounsellorHistoryComponent ,data:{pageType:'ic', title: 'My Incentive Details'}}, 
      {path: 'manager-history', component: ManagerHistoryComponent ,data:{pageType:'ic',title: 'Team Incentive Details'}}, 
      {path: 'account-history', component: AccountHistoryComponent ,data:{pageType:'ic', title: 'Team Incentive Details - Retail'}},
      {path: 'manager-history-live', component: ManagerHistoryLiveComponent ,data:{pageType:'ic',title: 'Team Incentive - Live (Current Month)'}},
      {path: 'account-history-live', component: AccountHistoryLiveComponent ,data:{pageType:'ic',title: 'Live Incentive - Retail (Current Month)'}},
      {path: 'lead-management', component: LeadManagementComponent ,data:{pageType:'ic',title: 'Lead Management'}}, 
    ], 
   
     },   
        
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IncentiveRoutingModule { }

export const OnboardingModuleConst = [
  CounsellorHistoryComponent,
  ManagerHistoryComponent,
  AccountHistoryComponent
];