import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-incentive',
  templateUrl: './incentive.component.html',
  styleUrls: ['./incentive.component.scss']
})
export class IncentiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
