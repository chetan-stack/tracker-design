import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { EditDialogComponent } from '../../dialog/edit-dialog/edit-dialog.component';
import { IncentiveDetailsComponent } from '../../dialog/incentive-details/incentive-details.component';
import { RejectDialogComponent } from '../../dialog/reject-dialog/reject-dialog.component';
import { ActivatedRoute } from '@angular/router';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ReasionComponent } from '../../dialog/reasion/reasion.component';

@Component({
  selector: 'app-manager-history',
  templateUrl: './manager-history.component.html',
  styleUrls: ['./manager-history.component.scss'],
})
export class ManagerHistoryComponent implements OnInit {
  isLive: string;
  displayedColumns: string[] = ['counsellor_name','month', 'total_sales' , 'workable_count' , 'non_workable_count' , 'Revenue' , 'ARPA-Bonus' , 'Process-Adherence' , 'Incentive-Amount' , 'Rate-Bonus' , 'arpa' , 'action' ];
  dataSource: any
  user_id: any
  counselorIncentive: any
  counselor_list: any = []


  counsellor_count: any;
    total_incentive: any = 0;
    tt_manager: Array<string> = [];
    tt_accounts: Array<string> = [];
    tt_staging: Array<string> = [];

  @ViewChild("content", { static: false }) content: ElementRef;
  onClickDownload(event: any) {
    console.log("onClickDownload starting");
    //this.downloadPDF();
  }

  
 
  


  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('search') input: ElementRef;

  

  constructor(
    private dialog: MatDialog,
    private route: ActivatedRoute,
    // private serviceFactory: ServiceFactoryService,
    private incentiveService: IncentiveService,
    private commonService: CommonService,
    private dataFactory: DataFactoryService,
  ) { 
    this.user_id = this.commonService.getCurrentUser().id;
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }

  ngOnInit(): void {

    this.route.queryParams
    .subscribe(params => {
      console.log(params); 
      this.isLive = params.isLive;
      console.log(this.isLive); 
      }
    );
    
    if(this.isLive === 'Yes') {
      this.displayedColumns = ['counsellor_name', 'total_sales' , 'workable_count' , 'non_workable_count' , 'Revenue' , 'ARPA-Bonus' , 'Process-Adherence' , 'Incentive-Amount' , 'Rate-Bonus' , 'action' ];
    }

    this.counsellor_incentive();
    this.counsellor_list();
  }


  
  onSubmit(form: any) {
    debugger

    let counsellor_id = form.value.coonselor_list
    let stage = form.value.incentive_stage
    let approve = form.value.aproval_reject
    let month = form.value.month
    let year = form.value.selectedYear
    
    console.log(month);
    
      
      this.incentiveService.manager_filter({
        "coonselor_list": counsellor_id?counsellor_id: null,
      "month": month?month: null,
      "incentive_stage": stage?Number(stage): null,
      "aproval_reject": approve?approve: null,
      "user_id": this.user_id,
      "year": year?year:null
      }).subscribe((data: any)=> {
        this.getNumbers(data.result)
        this.counselorIncentive = data.result;
        this.bind_userlist_Data(data.result);
        
      })
     
    

    // this.initialDatePicker = year + '-' + month + '-' + "01";

    // this.commonService.counsellorPerformance(this.initialDatePicker).subscribe((data)=> {
    //   this.counselorList = data.result;
    //   this.bind_userlist_Data(data.result['sales_data']);
    // })
  }

  clear(counsellorForm: any) {
    debugger
    counsellorForm.reset();
    this.counsellor_incentive();

  }

  approve(id : any, data: any ){
    debugger
   
    let app_rej = data.emp_code
  
    this.incentiveService.approve_reject({
      "user_id": this.user_id,
      "approval_reject": id,
      "emp_code": app_rej,
      "id": data.id
     
    }).subscribe((data: any)=> {
      this.counsellor_incentive();
      
    })

  }


  reject(id : any, data: any){
    debugger
  
      const dialogRef = this.dialog.open(RejectDialogComponent, {
        width: '40%',
        autoFocus: false,
        disableClose: true,
        data: {data: data, id: id}
      });
      dialogRef.beforeClosed().subscribe(result => {
        if (result) {
          // this.serviceFactory.notification(result['result'], result['status']);
          this.counsellor_incentive();
        }
      })
  }


  edit(data: any){
    debugger
    const dialogRef = this.dialog.open(EditDialogComponent, {
      width: '500px',
      height: '400px',
      autoFocus: false,
      disableClose: true,
      data: {data: data, isLive:this.isLive}
    });
    dialogRef.beforeClosed().subscribe(result => {
      if (result) {
        // this.serviceFactory.notification(result['result'], result['status']);
        this.counsellor_incentive();
      }
    })

      

  }


  viewdetails(data: any){
    debugger
  
      const dialogRef = this.dialog.open(IncentiveDetailsComponent, {
        width: '60%',
        height: 'auto',
        autoFocus: false,
        disableClose: true,
        data: {data: data, type: 'table', islive: 'No'}
      });
  }


  pdf(){
    debugger

  }

  searchAPI() {
    debugger
  }


  counsellor_incentive(){
    debugger

    if(this.isLive === "Yes") {
      this.incentiveService.liveinCentive({
        "user_id": this.user_id
      }).subscribe((data: any)=> {
        this.getNumbers(data.result)
        this.counselorIncentive = data.result;
        this.bind_userlist_Data(data.result);
      })
    } else {
      this.incentiveService.incentive_details({
        "user_id": this.user_id
      }).subscribe((data: any)=> {
        this.getNumbers(data.result)
        this.counselorIncentive = data.result;
        this.bind_userlist_Data(data.result);
      })
    }
  }
  bind_userlist_Data(data: any) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    
  }

  getNumbers(data: any) {
    debugger
    this.counsellor_count = data.length
    this.total_incentive = 0;

    this.tt_manager = [];
    this.tt_accounts = [];
    this.tt_staging = [];

    data.forEach((element:any) => {
      console.log(element);
      this.total_incentive += element.net_incentive;

      this.tt_manager.push(element.manager_status==0?"Manager Approval Pending":(element.manager_status==1?"Manager Approved":"Manager Rejected. Click to see reason."))
      this.tt_accounts.push(element.account_status==0?"Accounts Approval Pending":(element.account_status==1?"Accounts Approved":"Accounts Rejected. Click to see reason."))
      this.tt_staging.push(element.status_staging==0?"No Action":(element.status_staging==1?"Disbursal Pending":"Disbursed"))
    });
  }

  reason(reject_status: any , data: any, index: any){
    debugger
  
    if(reject_status!=2){
      return false
    }
    const dialogRef = this.dialog.open(ReasionComponent, {
      width: '40%',
      autoFocus: false,
      disableClose: true,
      data: {data: data, type: index}
    });
    }
  
  counsellor_list(){
    debugger
    this.incentiveService.counselor_list({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.counselor_list = data.result;
      
    })
   
  }
}
