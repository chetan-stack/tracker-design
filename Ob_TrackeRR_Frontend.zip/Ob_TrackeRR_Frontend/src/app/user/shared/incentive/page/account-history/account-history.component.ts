import { TitleCasePipe } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { IncentiveDetailsComponent } from '../../dialog/incentive-details/incentive-details.component';
import { ReasionComponent } from '../../dialog/reasion/reasion.component';
import { RejectDialogComponent } from '../../dialog/reject-dialog/reject-dialog.component';


@Component({
  selector: 'app-account-history',
  templateUrl: './account-history.component.html',
  styleUrls: ['./account-history.component.scss']
})
export class AccountHistoryComponent implements OnInit {
  displayedColumns: string[] = ['sNo' , 'total_revenue', 'counsellor_name',  'total_sales' , 'workable_count' , 'arpa' , 'incentive_stage' , 'action' ];
    
  inStageValue = "two"
    counselorIncentive: any
    user_id: any
    dataSource: any
    counselor_list: any = []
    manager_list1: any = []

    counsellor_count: any;
    total_incentive: any = 0;
    tt_manager: Array<string> = [];
    tt_accounts: Array<string> = [];
    tt_staging: Array<string> = [];

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('search') input: ElementRef;

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    // private titlecasePipe:TitleCasePipe,
    private dialog: MatDialog,
    private incentiveService: IncentiveService,
    private commonService: CommonService
  ) { 
    this.user_id = this.commonService.getCurrentUser().id;
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }

  convertString(data: any) {
    return data.toString();
  }

  ngOnInit(): void {
    this.counsellor_incentive();
    this.counsellor_list();
    this.manager_list();
  }
  clear(counsellorForm: any) {
    debugger
    counsellorForm.reset();
    this.counsellor_incentive();

  }


  counsellor_incentive(){
    debugger
    this.incentiveService.incentive_details({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.getNumbers(data.result)
      this.counselorIncentive = data.result;
      this.bind_userlist_Data(data.result);
    })
   
  }
  bind_userlist_Data(data: any) {

    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    
  }

  getNumbers(data: any) {
    debugger
    this.counsellor_count = data.length
    this.total_incentive = 0;

    this.tt_manager = [];
    this.tt_accounts = [];
    this.tt_staging = [];

    data.forEach((element:any) => {
      console.log(element);
      this.total_incentive += element.net_incentive;

      this.tt_manager.push(element.manager_status==0?"Manager Approval Pending":(element.manager_status==1?"Manager Approved":"Manager Rejected. Click to see reason."))
      this.tt_accounts.push(element.account_status==0?"Accounts Approval Pending":(element.account_status==1?"Accounts Approved":"Accounts Rejected. Click to see reason."))
      this.tt_staging.push(element.status_staging==0?"No Action":(element.status_staging==1?"Disbursal Pending":"Disbursed"))
    });
  }

  reason(reject_status: any , data: any, index: any){
    debugger
  
    if(reject_status!=2){
      return false
    }
    const dialogRef = this.dialog.open(ReasionComponent, {
      width: '40%',
      autoFocus: false,
      disableClose: true,
      data: {data: data, type: index}
    });
    }


  counsellor_list(){
    debugger
    this.incentiveService.counselor_list({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.counselor_list = data.result;
      
    })
   
  }
  
  manager_list(){
    debugger
    this.incentiveService.manager_list({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.manager_list1 = data.result;
      
    })
   
  }
  onSubmit(form: any) {
    debugger

    let counsellor_id = form.value.coonselor_list
    let stage = form.value.incentive_stage
    let approve = form.value.aproval_reject
    let month = form.value.month
    let year = form.value.selectedYear
    let manager = form.value.manager_list
    let branch = form.value.branch
    console.log(month);

    this.incentiveService.manager_filter({
      "coonselor_list": counsellor_id?counsellor_id: null,
      "month": month?month: null,
      "incentive_stage": stage?Number(stage): null,
      "aproval_reject": approve?approve: null,
      "user_id": this.user_id,
      "year": year?year:null,
      "manager_id": manager?Number(manager): null,
      "branch_id": branch?branch: null
    }).subscribe((data: any)=> {
      this.getNumbers(data.result)
      this.counselorIncentive = data.result;
      this.bind_userlist_Data(data.result);
      
    })

   
    // this.incentiveService.manager_filter(form.value).subscribe((data: any)=> {
    //   this.counselorIncentive = data.result;
    //   this.bind_userlist_Data(data.result);
      
    // })
  }

  approve(id : any, data: any ){
    debugger
   
    let app_rej = data.emp_code

  
    this.incentiveService.approve_reject({
      "user_id": this.user_id,
      "approval_reject": id,
      "emp_code": app_rej,
      "id": data.id
     
    }).subscribe((data: any)=> {
      this.counsellor_incentive();
    })

  }


  staging(status: any, data: any){
    debugger
  
    this.incentiveService.Account_staging({
      "user_id": this.user_id,
      "status_staging": status,
      "emp_code": data.emp_code,
      "id":data.id
     
    }).subscribe((data: any)=> {
      this.counsellor_incentive();
    })
  }




  // reject(id : any, data: any){
  //   debugger
  
  //     const dialogRef = this.dialog.open(RejectDialogComponent, {
  //       width: '500px',
  //       height: '400px',
  //       autoFocus: false,
  //       disableClose: true,
  //     });
  // }

  searchAPI() {
    debugger

    // if(form.value.filter_type == "monthly") {
    //   let month = form.value.month
    //   let year = form.value.year
    //   this.selected_month = year + '-' + month + '-' + "01";
    //   this.commonService.salesDetails({
    //     "filter_type": "monthly",
    //     "selected_month": this.selected_month,
    //     "search": event.target.value
    //   }).subscribe((data)=> {
    //     this.commentList = data.result;
    //     this.bind_userlist_Data(data.result);
    //     this.dataSource.sort = this.sort;
    //   })
    // } else if(form.value.filter_type == "date_range"){
    //   this.commonService.salesDetails({
    //     "filter_type": "date_range",
    //     "from_date": moment(form.value.from_date).format('YYYY-MM-DD'),
    //     "to_date": moment(form.value.to_date).format('YYYY-MM-DD'),
    //     "search": event.target.value
    //   }).subscribe((data)=> {
    //     this.commentList = data.result;
    //     this.bind_userlist_Data(data.result);
    //     this.dataSource.sort = this.sort;
    //   })
    // } else {
    //   this.commonService.salesDetails({
    //     "search": event.target.value
    //   }).subscribe((data)=> {
    //     this.commentList = data.result;
    //     this.bind_userlist_Data(data.result);
    //     this.dataSource.sort = this.sort;
    //   })
    // }
  }

  pdf(){
    debugger

  }
  viewdetails(data: any){
    debugger
  
    const dialogRef = this.dialog.open(IncentiveDetailsComponent, {
      width: '60%',
      autoFocus: false,
      disableClose: true,
      data: {data: data, type: 'table'}
    });
    dialogRef.beforeClosed().subscribe(result => {
      if (result) {
        
        this.counsellor_incentive();
      }
    })
  }
  // reject(){
  //   debugger
  
  //     const dialogRef = this.dialog.open(RejectaccComponent, {
  //       width: '750px',
  //       height: '500px',
  //       autoFocus: false,
  //       disableClose: true,
  //     });
  // }

  reject(id : any, data: any){
    debugger
  
      const dialogRef = this.dialog.open(RejectDialogComponent, {
        width: '40%',
        autoFocus: false,
        disableClose: true,
        data: {data: data, id: id}
      });
      dialogRef.beforeClosed().subscribe(result => {
        if (result) {
          // this.serviceFactory.notification(result['result'], result['status']);
          this.counsellor_incentive();
        }
      })
  }
}
