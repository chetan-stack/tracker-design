import { keyframes } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';


@Component({
  selector: 'app-lead-management',
  templateUrl: './lead-management.component.html',
  styleUrls: ['./lead-management.component.scss']
})
export class LeadManagementComponent implements OnInit {

  displays_column = []
  all_column: any = []
  leadData = []
  leadSize = 0
  user_id : any
  dataSource: any
  countRecords: any
  totalleads: 0
  timeout: any

  constructor(
    private route: ActivatedRoute,
    // private serviceFactory: ServiceFactoryService,
    private incentiveService: IncentiveService,
    private commonService: CommonService,
    private dataFactory: DataFactoryService,
  ) { 
    this.user_id = this.commonService.getCurrentUser().id;
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }

  ngOnInit(): void {
    this.lead_size_management();
  }
  

  updateleadSize(counsellor_Id: any , event: any, month: any){
    debugger
    let value = event.target.value;
    
    let getmonth = month
    clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      this.incentiveService. lead_update({
        "user_id": this.user_id,
        "couns_id": counsellor_Id.id,
        "month_date": getmonth,
        "lead_size": value? value: 0
      }).subscribe((data: any)=> {
        this.lead_size_management();
      })
    }, 2000);
  }


  lead_size_management(){
    debugger
      this.incentiveService.lead_management({
        "user_id": this.user_id
      }).subscribe((data: any)=> {
        this.leadData = data.result;
        this.all_column = []
        Object.entries(this.leadData[0]).forEach(([key, value])=> {
          this.all_column.push({
            lead_name: key,
            // label: key == 'name' ? 'Counsellor' : key,
          })
        });

        this.all_column.unshift({"lead_name": 'S. No.'});
        this.all_column = this.all_column.filter(function(f:any) { return f.lead_name != 'id' })
        // this.all_column = delete this.all_column['id'];
        this.displays_column = this.all_column.map((item: { lead_name: any; }) => item.lead_name);
         this.totalleads = data.total;
        
        this.bind_userlist_Data(data.result);
        this.getCarrentMonth(data.result);
      })
  }
  bind_userlist_Data(data: any) {
    this.dataSource = new MatTableDataSource(data);
  }


  getCarrentMonth(data: any){
    this.countRecords = data.length
   }

  

}
