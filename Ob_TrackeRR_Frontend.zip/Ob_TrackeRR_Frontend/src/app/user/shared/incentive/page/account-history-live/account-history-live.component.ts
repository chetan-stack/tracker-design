import { TitleCasePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { IncentiveDetailsComponent } from '../../dialog/incentive-details/incentive-details.component';
import { RejectDialogComponent } from '../../dialog/reject-dialog/reject-dialog.component';


@Component({
  selector: 'app-account-history-live',
  templateUrl: './account-history-live.component.html',
  styleUrls: ['./account-history-live.component.scss']
})
export class AccountHistoryLiveComponent implements OnInit {
  branch: string;
  displayedColumns: string[] = ['sNo' , 'total_revenue', 'counsellor_name',  'total_sales' , 'workable_count' , 'action' ];
    
  inStageValue = "two"
    counselorIncentive: any
    user_id: any
    dataSource: any
    counselor_list: any = []

    counsellor_count: any;
    total_incentive: any = 0;
    tt_manager: Array<string> = [];
    tt_accounts: Array<string> = [];
    tt_staging: Array<string> = [];

    @ViewChild(MatSort) sort: MatSort;

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    // private titlecasePipe:TitleCasePipe,
    private dialog: MatDialog,
    private incentiveService: IncentiveService,
    private commonService: CommonService
  ) { 
    this.user_id = this.commonService.getCurrentUser().id;
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }

  convertString(data: any) {
    return data.toString();
  }

  ngOnInit(): void {
    this.getRouteData();
    this.counsellor_list();
  }

  update() {
    this.getRouteData(); 
  }

  getRouteData() {
    this.route.queryParams
    .subscribe(params => {
      console.log(params); 
      this.branch = params.branch;
      console.log("hello there: "+this.branch); 
      this.counsellor_incentive_live();
      }
    );
  }    


  counsellor_incentive_live(){
    debugger
    this.incentiveService.liveinCentive({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      debugger
     
      if(this.branch === "LP") {
        this.counselorIncentive = data.result;
        this.getNumbers(this.counselorIncentive)
        
      }
       else {
        this.counselorIncentive = data.result_2;
        this.getNumbers(this.counselorIncentive)
      }
      this.bind_userlist_Data(this.counselorIncentive);
    })
   
  }

  bind_userlist_Data(data: any) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    
  }

  getNumbers(data: any) {
    debugger
    this.counsellor_count = data.length
    this.total_incentive = 0;

    this.tt_manager = [];
    this.tt_accounts = [];
    this.tt_staging = [];

    data.forEach((element:any) => {
      console.log(element);
      this.total_incentive += element.net_incentive;

      this.tt_manager.push(element.manager_status==0?"Manager Approval Pending":(element.manager_status==1?"Manager Approved":"Manager Rejected. Click to see reason."))
      this.tt_accounts.push(element.account_status==0?"Accounts Approval Pending":(element.account_status==1?"Accounts Approved":"Accounts Rejected. Click to see reason."))
      this.tt_staging.push(element.status_staging==0?"No Action":(element.status_staging==1?"Disbursal Pending":"Disbursed"))
    });
  }


  counsellor_list(){
    debugger
    this.incentiveService.counselor_list({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.counselor_list = data.result;
      
    })
   
  }
  onSubmit(form: any) {
    debugger

    let counsellor_id = form.value.coonselor_list
    let stage = form.value.incentive_stage
    let approve = form.value.aproval_reject
    let month = form.value.month
    let year = form.value.selectedYear
    console.log(month);

    this.incentiveService.manager_filter({
      "coonselor_list": counsellor_id?counsellor_id: null,
      "month": month?month: null,
      "incentive_stage": stage?Number(stage): null,
      "aproval_reject": approve?approve: null,
      "user_id": this.user_id,
      "year": year?year:null
    }).subscribe((data: any)=> {
      this.counselorIncentive = data.result;
      this.bind_userlist_Data(data.result);
      
    })

  }



  pdf(){
    debugger

  }
  viewdetails(data: any){
    debugger
    const dialogRef = this.dialog.open(IncentiveDetailsComponent, {
      width: '60%',
      autoFocus: false,
      disableClose: true,
      data: {data: data, type: 'table',islive: 'Yes'}
    });
    dialogRef.beforeClosed().subscribe(result => {
      if (result) {
        
        this.counsellor_incentive_live();
      }
    })
  }


}
