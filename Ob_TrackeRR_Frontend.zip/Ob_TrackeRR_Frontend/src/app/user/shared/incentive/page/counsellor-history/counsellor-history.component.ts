import { AutofillMonitor } from '@angular/cdk/text-field';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { IncentiveDetailsComponent } from '../../dialog/incentive-details/incentive-details.component';
import { ReasionComponent } from '../../dialog/reasion/reasion.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-counsellor-history',
  templateUrl: './counsellor-history.component.html',
  styleUrls: ['./counsellor-history.component.scss'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],

})
export class CounsellorHistoryComponent implements OnInit {

  displayedColumns: string[] = ['counsellor_name', 'total_revenue', 'total_sales' , 'workable_count' , 'non_workable_count' , 'Revenue' , 'ARPA-Bonus' , 'arpa' , 'combos_sold' ];
  dataSource: any
  date1 = new FormControl(moment());
  date2 = new FormControl(moment());
  manager_approve=true
  ac_approve=true
  diss=false
  counselorIncentive: any

  user_id: any

  counsellor_count: any;
    total_incentive: any = 0;

  tt_manager: Array<string> = [];
    tt_accounts: Array<string> = [];
    tt_staging: Array<string> = [];

  @ViewChild(MatSort) sort: MatSort;



  constructor(
    private dialog: MatDialog,
    // private serviceFactory: ServiceFactoryService,
    private incentiveService: IncentiveService,
    private commonService: CommonService,
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
  ) { 
    this.user_id = this.commonService.getCurrentUser().id;
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle});
  }

  ngOnInit(): void {
    this.counsellor_incentive();
  }

  reason(reject_status: any , data: any, index: any){
  debugger

  if(reject_status!=2){
    return false
  }
  const dialogRef = this.dialog.open(ReasionComponent, {
    width: '40%',
    autoFocus: false,
    disableClose: true,
    data: {data: data, type: index}
  });
  }

  onSubmit(form: any) {
    debugger
    let from = form.value.selectedMonth1 + "-" + form.value.selectedYear1
    let to = form.value.selectedMonth2 + "-" + form.value.selectedYear2
    this.incentiveService.counsellor_search({
      "start_month": from,
      "end_month": to,
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.counselorIncentive = data.result;
      this.bind_userlist_Data(data.result);
    })
    

  }


  chosenMonthHandler1(normalizedMonth: moment.Moment, datepicker: MatDatepicker<moment.Moment>){
    const ctrlValue = this.date2.value;
    ctrlValue.month(normalizedMonth.month());
    ctrlValue.day(1)
    this.date1.setValue(ctrlValue);
    datepicker.close();

  }

  chosenMonthHandler2 (normalizedMonth: moment.Moment, datepicker: MatDatepicker<moment.Moment>){
    const ctrlValue = this.date2.value;
    ctrlValue.month(normalizedMonth.month());
    this.date2.setValue(ctrlValue);
    datepicker.close();
  
  }

  chosenYearHandler1(normalizedYear: moment.Moment){
  
    const ctrlValue1 = this.date1.value;
    ctrlValue1.year(normalizedYear.year());
    this.date1.setValue(ctrlValue1);
  }

  chosenYearHandler2(normalizedYear: moment.Moment){
    const ctrlValue = this.date2.value;
    ctrlValue.year(normalizedYear.year());
    this.date2.setValue(ctrlValue);
  }

  clear(monthrange: any) {
    debugger
    monthrange.reset();
    this.counsellor_incentive();

  }



  

  viewdetails(data: any){
    debugger
  
      const dialogRef = this.dialog.open(IncentiveDetailsComponent, {
        width: '60%',
        height: 'auto',
        autoFocus: false,
        disableClose: true,
        data: {data: data, type: 'table'}
      });
      // dialogRef.beforeClosed().subscribe(result => {
      //   if (result) {
      //     this.serviceFactory.notification(result['result'], result['status']);
      //     this.counsellor_incentive();
      //   }
      // })
  }


  counsellor_incentive(){
    debugger
    this.incentiveService.incentive_details({
      "user_id": this.user_id
    }).subscribe((data: any)=> {
      this.counselorIncentive = data.result;
      this.getNumbers(this.counselorIncentive)
      this.bind_userlist_Data(data.result);
    })
   
  }

  bind_userlist_Data(data: any) {
    this.dataSource = new MatTableDataSource(data);
    this.dataSource.sort = this.sort;
    
  }

  getNumbers(data: any) {
    debugger
    this.counsellor_count = data.length
    this.total_incentive = 0;

    this.tt_manager = [];
    this.tt_accounts = [];
    this.tt_staging = [];

    data.forEach((element:any) => {
      console.log(element);
      this.total_incentive += element.net_incentive;

      this.tt_manager.push(element.manager_status==0?"Manager Approval Pending":(element.manager_status==1?"Manager Approved":"Manager Rejected. Click to see reason."))
      this.tt_accounts.push(element.account_status==0?"Accounts Approval Pending":(element.account_status==1?"Accounts Approved":"Accounts Rejected. Click to see reason."))
      this.tt_staging.push(element.status_staging==0?"No Action":(element.status_staging==1?"Disbursal Pending":"Disbursed"))
    });
  }


}
