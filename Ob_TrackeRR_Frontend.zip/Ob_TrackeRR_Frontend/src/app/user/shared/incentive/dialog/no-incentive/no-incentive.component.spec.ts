import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NoIncentiveComponent } from './no-incentive.component';

describe('NoIncentiveComponent', () => {
  let component: NoIncentiveComponent;
  let fixture: ComponentFixture<NoIncentiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NoIncentiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NoIncentiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
