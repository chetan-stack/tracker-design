import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';

@Component({
  selector: 'app-reject-dialog',
  templateUrl: './reject-dialog.component.html',
  styleUrls: ['./reject-dialog.component.scss']
})
export class RejectDialogComponent implements OnInit {
  userData: {}

  accoundData: any
  user_id: any
  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RejectDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private commonService: CommonService,
    private incentiveService: IncentiveService,
  ) { 
    debugger
    this.user_id = this.commonService.getCurrentUser().id;
    this.accoundData = dialogData
  }

  ngOnInit(): void {
  }


  onsubmit(form: any){
    debugger
    
    let app_rej = this.accoundData.data.emp_code
    let approve_rej = this.accoundData.id
    let mass = form.value.reassion
    console.log(mass);
    this.incentiveService.approve_reject({
      "user_id": this.user_id,
      "approval_reject": approve_rej,
      "emp_code": app_rej,
      "comments": mass,
      "id":this.accoundData.data.id
     
    }).subscribe((data: any)=> {
      this.dialogRef.close(data);
      
      
    })
  }

}
