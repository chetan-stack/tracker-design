import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-incentive',
  templateUrl: './no-incentive.component.html',
  styleUrls: ['./no-incentive.component.scss']
})
export class NoIncentiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
