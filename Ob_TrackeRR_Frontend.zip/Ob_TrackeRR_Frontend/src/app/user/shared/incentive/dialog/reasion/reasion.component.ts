import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-reasion',
  templateUrl: './reasion.component.html',
  styleUrls: ['./reasion.component.scss']
})
export class ReasionComponent implements OnInit {
  // userData: {}

  constructor(
    public dialogRef: MatDialogRef<ReasionComponent>,
    @Inject(MAT_DIALOG_DATA) public dailogdata: any
  ) {
    let userData = dailogdata.data.manager_reject_reason;
    console.log(userData);
   }

  ngOnInit(): void {
  }

}
