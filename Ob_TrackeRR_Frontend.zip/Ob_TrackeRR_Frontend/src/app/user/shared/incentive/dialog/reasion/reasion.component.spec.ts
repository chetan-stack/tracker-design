import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReasionComponent } from './reasion.component';

describe('ReasionComponent', () => {
  let component: ReasionComponent;
  let fixture: ComponentFixture<ReasionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReasionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReasionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
