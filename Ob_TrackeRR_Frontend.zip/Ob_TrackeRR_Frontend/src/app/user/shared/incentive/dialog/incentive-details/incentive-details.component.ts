import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { EditDialogComponent } from '../edit-dialog/edit-dialog.component';
import { InfoDialogComponent } from '../info-dialog/info-dialog.component';
import { ReasionComponent } from '../reasion/reasion.component';
import { RejectDialogComponent } from '../reject-dialog/reject-dialog.component';

@Component({
  selector: 'app-incentive-details',
  templateUrl: './incentive-details.component.html',
  styleUrls: ['./incentive-details.component.scss']
})
export class IncentiveDetailsComponent implements OnInit {
  i: any
  incentiveData: any ={}
  month_year: any
  user_id: any
  login_type: any
  emp_code: any
  incentive_type: any = "No"
  tt_manager: any;
  tt_accounts: any;
  tt_staging: any;

  constructor(
    private incentiveService: IncentiveService,
    private router: Router,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<IncentiveDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private commonService: CommonService
    ){
      debugger
      if(dialogData.type == 'piggy' ) {
        this.incentive_type = 'Yes';
        this.incentiveData = dialogData.data[0];

        this.tt_manager = dialogData.data[0].manager_status==0?"Manager Approval Pending":(dialogData.data[0].manager_status==1?"Manager Approved":"Manager Rejected. Click to see reason.")
        this.tt_accounts = dialogData.data[0].account_status==0?"Accounts Approval Pending":(dialogData.data[0].account_status==1?"Accounts Approved":"Accounts Rejected. Click to see reason.")
        this.tt_staging = dialogData.data[0].status_staging==0?"No Action":(dialogData.data[0].status_staging==1?"Disbursal Pending":"Disbursed")
  

      } else {
        this.month_year= dialogData.data['created_on'];
        this.emp_code = dialogData.data['emp_code']
        this.user_id = this.commonService.getCurrentUser().id;
        // this.monthly_incentive();
        this.incentiveData = dialogData.data;
        this.tt_manager = dialogData.data.manager_status==0?"Manager Approval Pending":(dialogData.data.manager_status==1?"Manager Approved":"Manager Rejected. Click to see reason.")
        this.tt_accounts = dialogData.data.account_status==0?"Accounts Approval Pending":(dialogData.data.account_status==1?"Accounts Approved":"Accounts Rejected. Click to see reason.")
        this.tt_staging = dialogData.data.status_staging==0?"No Action":(dialogData.data.status_staging==1?"Disbursal Pending":"Disbursed")

        
      }
      debugger
      this.login_type = this.commonService.getCurrentUser().activeRole;
      if(dialogData.islive === "Yes") {
        this.incentive_type = "Yes";
      }
    }
    
  ngOnInit(): void {
    
  }

  edit(data: any){
    debugger
  
      const dialogRef = this.dialog.open(EditDialogComponent, {
        width: '500px',
        height: '400px',
        autoFocus: false,
        disableClose: true,
        data: {data: data}
      });
      dialogRef.beforeClosed().subscribe(result => {
        if (result) {
          // this.serviceFactory.notification(result['result'], result['status']);
        }
      })

  }
  reason(reject_status: any , data: any, index: any){
    debugger
  
    if(reject_status!=2){
      return false
    }
    const dialogRef = this.dialog.open(ReasionComponent, {
      width: '40%',
      autoFocus: false,
      disableClose: true,
      data: {data: data, type: index}
    });
    }

  approve1(id : any, data: any) {
    debugger
    let app_rej = data.emp_code
  
    this.incentiveService.approve_reject({
      "user_id": this.user_id,
      "approval_reject": id,
      "emp_code": app_rej
     
    }).subscribe((data: any)=> {
      this.dialogRef.close(data);
    })
  }

  reject1(id : any, data: any) {
    debugger
    const dialogRef = this.dialog.open(RejectDialogComponent, {
      width: '60%',
      autoFocus: false,
      disableClose: true,
      data: {data: data, id: id}
    });
    dialogRef.beforeClosed().subscribe(result => {
      if (result) {
        // this.serviceFactory.notification(result['result'], result['status']);
       
      }
    })

    
  }

  history_table(){
    debugger
    if(this.login_type === 'counsellor'){
      this.router.navigate(['counsellor/ic/counsellor-history'])
      window.scrollTo(0,0);

    }
    else if(this.login_type ==='manager'){
      this.router.navigate(['manager/ic/manager-history'])
      window.scrollTo(0,0);

    }
    else{
      this.router.navigate(['account/ic/account-history'])
      window.scrollTo(0,0);

    }

  }
  // manager_history_table(){
  //   this.router.navigate(['manager/ic/manager-history'])
  //   window.scrollTo(0,0);

  // }
  // account_history_table(){
  //   this.router.navigate(['account/ic/account-history'])
  //   window.scrollTo(0,0);

  // }

  // history_table(){
  //   this.router.navigate(['counsellor/ic/counsellor-history'])
  //     window.scrollTo(0,0);

  // }



  viewDialog(dialogId: any): void {

    switch (dialogId) {

      case 1:
        let dialogRefMA = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: MomentumAnalysis }
        });
        break;

      case 2:
        let dialogRefFANB = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: NoOfSales }
        });
        break;

      case 3:
        let dialogRefFANBG = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: Revenue }
        });
        break;

      case 4:
        let dialogRefFAB = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: ARPA }
        });
        break;

      case 5:
        let dialogRefFABG = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: TotalInitial }
        });
        break;

      case 6:
        let dialogRefBreakup = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: ARPABonus }
        });
        break;

      case 7:
        let dialogRefSectoralPerf = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: ARPADeficit }
        });
        break;

      case 8:
        let dialogRefStocksPerf = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: Process  }
        });
        break;

      case 9:
        let dialogRefSectoralDraw = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: TotalDeficits }
        });
        break;

      case 10:
        let dialogRefStocksDraw = this.dialog.open(InfoDialogComponent, {
          width: '60%',
          data: { component: Leads }
        });
        break;

        case 11:
        let dialogRefMomPerformance = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: ConversionRate }
        });
        break;

      case 12:
        let dialogRefStrongBuyVsNifty = this.dialog.open(InfoDialogComponent, {
          width: '40%',
          data: { component: ConversionRateBonus }
        });
        break;

      default:
        let dialogRefDef = this.dialog.open(InfoDialogComponent, {
          width: '700px'
        });
        break;
    }

  }

  monthly_incentive(){
    this.incentiveService.monthly_incentive_details({
      "month": this.month_year,
      "user_id": this.emp_code,
      
    }).subscribe((data:any)=> {
      this.incentiveData = data.result[0];
      debugger    
    })
  }

}

@Component({
  selector: 'app-viewdetail',
  template: `
  <div class="text">
  Incentive Eligibility Revenue is your <b>"Monthly CTC * 4"</b>.
  </div>
  `
})
export class MomentumAnalysis {

}

@Component({
  selector: 'app-viewdetail',
  template: `
  <div>Total of this month Sale's amount excluding GST</div>
  `,
styles: ['.header-text { font-weight: 600; font-style: italic }']
})
export class Revenue {

}


@Component({
  selector: 'app-viewdetail',
  template: `
  <div>Total no. of accounts delivered in this month</div>
  `,
styles: ['.header-text { font-weight: 600; font-style: italic }']
})
export class NoOfSales {

}

@Component({
  selector: 'app-viewdetail',
  template: `
  <div>Average Revenue Per Sale = <b>Total Revenue (Net of GST) / No. of Sales</b></div>
  `,
styles: ['.header-text { font-weight: 600; font-style: italic }']
})
export class ARPA {

}

@Component({
  selector: 'app-viewdetail',
  template: `
  <div>Incentive earned on the basis of revenue.
  <div class="cont"><b>A.</b>15% Incentive on revenue up to "6 times" of monthly CTC</div> 
  <div class="cont"><b>B.</b>20% Incentive on revenue more than "6 times" of monthly CTC </div> 
  <div class="cont"><b> Initial Incentive Amount = A + B</b></div>
  </div>
  `,
styles: ['.cont { margin-top: 10px; }']
})
export class TotalInitial {

}



@Component({
  selector: 'app-viewdetail',
  template: `
  <div><b>25%</b> bonus on Initial Incentive Amount if ARPA is greater than <b>₹ 14,000</b>
  </div>
  <div><b>Note</b> There will not be any ARPA Bonus or deficits if ARPA is between <b>₹ 13,000 to ₹ 14,000 </b>
  </div>
  `,
styles: ['.cont { margin-top: 10px; }']
})
export class ARPABonus {

}

@Component({
  selector: 'app-viewdetail',
  template: `
  <div><b>25%</b> deficit on Initial Incentive Amount if ARPA is less than <b>₹ 13,000 </b>.
  </div>
  <div><b>Note:</b> There will not be any ARPA Bonus or deficits if ARPA is between <b>₹ 13,000 to ₹ 14,000 </b>
  </div>
  `,
styles: ['.cont { margin-top: 10px; }']
})
export class ARPADeficit {

}


@Component({
  selector: 'app-viewdetail',
  template: `
  <div><b>10%</b> deficit on Incentive Amount <b>(A+B)</b> if processes set by management have not been followed. 
  </div>
  <div><b>Note:</b> There will not be any ARPA Bonus or deficits if ARPA is between <b>₹ 13,000 to ₹ 14,000 </b>.
  </div>
  `,
styles: ['.cont { margin-top: 10px; }']
})
export class Process {

}


@Component({
  selector: 'app-viewdetail',
  template: `
  <div> Sum of ARPA Deficit amount and Process Adherence Deficit Amount on Incentive Amount <b>(A+B)</b>
  </div>
  `,
styles: ['.cont { margin-top: 10px; }']
})
export class TotalDeficits {

}   


@Component({
  selector: 'app-viewdetail',
  template: `
  <div><b>10%</b>  bonus on Incentive Amount <b>(A+B-C)</b> if Conversation Rate is greater than <b>5% </b> and less than <b> 7%</b>
  </div>
  <div><b>25%</b>  bonus on Incentive Amount <b>(A+B-C)</b> if Conversation Rate is greater than <b>7%</b>
  </div>
  `,
styles: ['.cont { margin-top: 20px; }']
})
export class ConversionRateBonus {

}  


@Component({
  selector: 'app-viewdetail',
  template: `
  <div>Total Leads received this month in the Lead Sqaured
  </div>
  `,
styles: ['.cont { margin-top: 20px; }']
})
export class Leads {

}  

@Component({
  selector: 'app-viewdetail',
  template: `
  <div> Conversion Rate = <b>No. of Sales / No. of Leads </b>
  </div>
  `,
styles: ['.cont { margin-top: 20px; }']
})
export class ConversionRate {

}

