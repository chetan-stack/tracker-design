import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { RejectDialogComponent } from '../reject-dialog/reject-dialog.component';

@Component({
  selector: 'app-edit-dialog',
  templateUrl: './edit-dialog.component.html',
  styleUrls: ['./edit-dialog.component.scss']
})
export class EditDialogComponent implements OnInit {

  user_id: any
  accoundData: any
  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<RejectDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: any,
    private commonService: CommonService,
    private incentiveService: IncentiveService,
  ) { 
    debugger
    this.user_id = this.commonService.getCurrentUser().id;
    this.accoundData = dialogData
  }

  ngOnInit(): void {
  }


  onsubmit(form: any){

  }
  edit_manger(form: any){
    debugger
    
    let app_rej = this.accoundData.data.emp_code
    
    let record_id = this.accoundData.data.id
    let lead_size  = form.value.lead_size
    let process_adh = form.value.process_adh
    
    this.incentiveService.manager_edit({
      "user_id": this.user_id,
      "emp_code": app_rej,
      "lead_size": lead_size,
      "process_adherence": process_adh,
      "isLive":this.accoundData.isLive,
      "id":record_id
     
    }).subscribe((data: any)=> {
      this.dialogRef.close(data);
      
      
    })
  }

}
