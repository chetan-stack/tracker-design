import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IncentiveRoutingModule } from './incentive-routing.module';
import { IncentiveComponent } from './incentive.component';
import { IncentiveDetailsComponent } from './dialog/incentive-details/incentive-details.component';
import { NoIncentiveComponent } from './dialog/no-incentive/no-incentive.component';
import { CounsellorHistoryComponent } from './page/counsellor-history/counsellor-history.component';
import { ManagerHistoryComponent } from './page/manager-history/manager-history.component';
import { AccountHistoryComponent } from './page/account-history/account-history.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared.module';
import { DemoMaterialModule } from 'src/app/material-module';
import { RejectDialogComponent } from './dialog/reject-dialog/reject-dialog.component';
import { EditDialogComponent } from './dialog/edit-dialog/edit-dialog.component';
import { InfoDialogComponent } from './dialog/info-dialog/info-dialog.component';
import { ReasionComponent } from './dialog/reasion/reasion.component';
import { ManagerHistoryLiveComponent } from './page/manager-history-live/manager-history-live.component';
import { AccountHistoryLiveComponent } from './page/account-history-live/account-history-live.component';
import { LeadManagementComponent } from './page/lead-management/lead-management.component';


@NgModule({
  declarations: [
    IncentiveComponent,
    IncentiveDetailsComponent,
    NoIncentiveComponent,
    CounsellorHistoryComponent,
    ManagerHistoryComponent,
    AccountHistoryComponent,
    RejectDialogComponent,
    EditDialogComponent,
    InfoDialogComponent,
    ReasionComponent,
    ManagerHistoryLiveComponent,
    AccountHistoryLiveComponent,
    LeadManagementComponent
  ],
  imports: [
    CommonModule,
    IncentiveRoutingModule,
    ReactiveFormsModule,
    FormsModule, 
    SharedModule, 
    DemoMaterialModule,  
  ]
})
export class IncentiveModule { }
