import { Component, ElementRef, OnInit, TemplateRef, ViewChild } from '@angular/core'; 
import { MatTableDataSource } from '@angular/material/table';
import {MatSort, Sort} from '@angular/material/sort'; 
 
import { ActivatedRoute } from '@angular/router';
 
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2'; 
import { MatDialog } from '@angular/material/dialog'; 
import { CommonService } from 'src/services/api/common.service';  
import { debounceTime, distinctUntilChanged, finalize, tap } from 'rxjs/operators'; 
import { MatPaginator } from '@angular/material/paginator';
import { fromEvent, merge } from 'rxjs';
import { BreakpointObserver } from '@angular/cdk/layout'; 
import { ViewUserInfoComponent } from '../../dialog/view-user-info/view-user-info.component';
import { EnachSkipRequestComponent } from '../../dialog/enach-skip-request/enach-skip-request.component';
import { RemarkHistoryComponent } from '../../dialog/remark-history/remark-history.component';
import { KeyValue } from '@angular/common';
import * as moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DownloadComponent } from '../../dialog/download/download.component';
import { EnachCancelRequestComponent } from '../../dialog/enach-cancel-request/enach-cancel-request.component';
import { MarkEnachPaymentComponent } from '../../dialog/mark-enach-payment/mark-enach-payment.component';
 
const columns_show:any = { 
  'id': 'S No.',
  'customer_name': 'Customer Name', 
  'leadId': 'Lead No.', 
  'customer_email_id':'Email',
  'customer_phone_no':'Phone',
  'payment_received_date':'Payment Rec. Date', 
  'sales_date':'Sales Date',
  'revenue':'Revenue',
  'lead_origin':'Lead Origin',
  'action': 'Actions'  
}
 
const ColumnDefaultShow:any  =  [
    "id",
    "customer_name",
    "leadId",
    "customer_email_id",
    "customer_phone_no",
    "payment_received_date",
    "sales_date",
    "revenue",
    "lead_origin",  
    "action"
]
const filterForm:any = {  
   team_id:[], 
   center_ids:[],  
   lead_origin_id:[],
   identifier_id:[],  
   payment_date:{
    start_date:null,
    end_date:null,
  }, 
}

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-bible-details',
  templateUrl: './bible-details.component.html',
  styleUrls: ['./bible-details.component.scss']
})
export class BibleDetailsComponent implements OnInit {
  
  selectedRowIndex:any;
  getCurrentUser:any = {}; 
  pageType:string;
  moment = moment;

  gridDataSource = new MatTableDataSource();
  allColumnsForShow:any = {}
  Column_type_defaultShow:any = []


  filter_Search:string = ""; 
  
  filter_fieldData:any = JSON.parse(JSON.stringify(filterForm));
  filter_ApplyedCount:any = 0;

  
  
 
 

  Status_Name:any = {}
  Status_Color:any = {}
  Status_Icon:any = {}  
  product_label:any={};
  product_color:any = {};
 
  storedAllData: any; 
  filterApiDataOption:any = {};

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('data_table') private data_table: any;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('textSearch_main') textSearch_main: ElementRef;

  constructor(
    private route:ActivatedRoute,
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    public mediaQ: BreakpointObserver, 
    private dialog: MatDialog ,
  ) {
    debugger

    this.pageType = route.snapshot.data['type'];  

    this.getCurrentUser = this.commonService.getCurrentUser();
    let PageTitle = route.snapshot.data['title'];
    this.dataFactory.setPageTitle({PageTitle: PageTitle}); 
       

    this.Status_Name = this.dataFactory.All_Status_Name;
    this.Status_Color = this.dataFactory.All_Status_Color;
    this.Status_Icon = this.dataFactory.All_Status_Icon;
    this.product_color = this.dataFactory.all_product_color;
    this.product_label = this.dataFactory.all_product_label;
    

    this.allColumnsForShow = columns_show;

    route.queryParams.subscribe(p => {   
      this.refreshGrid("route"); 

debugger
      

      const countFilteredData = p.sales_countFiltered?JSON.parse(atob(p.sales_countFiltered)):null;
      if(countFilteredData?.search){   
        this.filter_Search = countFilteredData['search'];
     }
        

     if(countFilteredData?.team_id){   
      this.filter_fieldData.team_id = countFilteredData['team_id']; 
     }

     if(countFilteredData?.center_ids){   
      this.filter_fieldData.center_ids = countFilteredData['center_ids']; 
     }

     if(countFilteredData?.lead_origin_id){   
      this.filter_fieldData.lead_origin_id = countFilteredData['lead_origin_id']; 
     }

      if(countFilteredData?.identifier_id){   
        this.filter_fieldData.identifier_id = countFilteredData['identifier_id']; 
      }
      
      if(countFilteredData?.filter_payment_date){   
        this.filter_fieldData.payment_date.start_date = countFilteredData['filter_payment_date'].from_date;
        this.filter_fieldData.payment_date.end_date = countFilteredData['filter_payment_date'].to_date;
      }
      
       
    


      
      this.dataFactory.set_data('countFilteredData',null);

      this.loadGrid_Data();
     });

   }
 
  ngOnInit(): void {
    this.Column_type_defaultShow = ColumnDefaultShow;
  }
  ngAfterViewInit(): void {
  

    fromEvent(this.textSearch_main.nativeElement, 'keyup').pipe(debounceTime(250),distinctUntilChanged(),tap(() => {
      debugger
      this.paginator.pageIndex = 0,
       this.loadGrid_Data();
    })
  ).subscribe();
  
  
  
      // reset the paginator after sorting
   this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
  
   // on sort or paginate events, load a new page
   merge(this.sort.sortChange, this.paginator.page)
   .pipe(
       tap(() => this.loadGrid_Data())
   )
   .subscribe();
  }
 

 
  
  loadGrid_Data() { 

    this.filterApiDataOption = {
      short_key: this.sort?this.sort.active:"",
      short_order: this.sort?this.sort.direction:"",
      page: this.paginator?this.paginator.pageIndex:0,
      perpage: this.paginator?this.paginator.pageSize:20,

 

      search: this.filter_Search, 
      team_id:this.filter_fieldData.team_id, 
      center_ids:this.filter_fieldData.center_ids,  
      lead_origin_id:this.filter_fieldData.lead_origin_id,  
      identifier_id:this.filter_fieldData.identifier_id, 
      payment_from_date: this.filter_fieldData.payment_date.start_date ? moment(this.filter_fieldData.payment_date.start_date).format('YYYY-MM-DD') : '',
      payment_to_date: this.filter_fieldData.payment_date.end_date ? moment(this.filter_fieldData.payment_date.end_date).format('YYYY-MM-DD') : '',
     }

   let apiUrl = 'sales/getSalesBibleFilterList';
   
  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post(apiUrl,this.filterApiDataOption).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      if(res.status){
        this.storedAllData = res.data;
        this.bindGridData(res.data.dataobject);
      }else{
        this.storedAllData = undefined;
        this.bindGridData([]);
      }
  
    })

    this.filter_ApplyedCount = this.serviceFactory.getFilterAppliedCount(this.filter_fieldData);
  }

   
  bindGridData(data:any) {
    this.gridDataSource = new MatTableDataSource(data);
    this.gridDataSource.sort = this.sort;
    this.bindTableGridWidth();
  }
 
  changeColumnFilter(event: any,elm:any){
    debugger 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");  
    setTimeout(() => {
      let selected:any = []; 
      elm.options._results.forEach((element:any) => {
        if(element.selected){
           selected.push(element.value)
        }
      });
      this.Column_type_defaultShow = selected;
      this.serviceFactory.loadingStop("body","");
       debugger
    }, 200);

    setTimeout(() => {
      this.bindTableGridWidth();
    }, 700);
    
  }
 
  onFilterGrid() {
    this.paginator.pageIndex = 0,
      this.loadGrid_Data();
  }

  onFilter_PaymentDateRange_Grid(data:any){ 
    if(data.value){
      this.onFilterGrid()
    }
  }

  refreshGrid(mode:any) {

    let stringifyColumn:any = JSON.stringify(ColumnDefaultShow);
    this.Column_type_defaultShow = JSON.parse(stringifyColumn)[this.pageType];


    if(this.paginator){
      this.paginator.pageIndex = 0;  
      this.sort.active = "";
      this.sort.direction = ""; 
      
      this.filter_Search="";
      this.filter_fieldData = JSON.parse(JSON.stringify(filterForm));
    }
 

    if(mode=="reset"){
      this.loadGrid_Data();
    }
    
  
  }

  bindTableGridWidth(){
    debugger 
    let w = 0;  
    let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
    for (let i = 0; i < children.length; i++) {
      let header = children[i].style.minWidth;
      let string = header.replace("px", "");
      var number  = string.replace("%", ""); 
      w = w + Number(number);
    } 
 
    if(this.data_table._elementRef.nativeElement){
      this.data_table._elementRef.nativeElement.style.minWidth = w+'px';
      document.querySelector<any>('.Grid_No_data').style.minWidth = w+'px';
       
    }  
  }


  /****************/
 
 

    // Preserve original property order
    originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
      return 0;
    }


    downloadPdf(){
      debugger 
      let stringify = JSON.stringify(this.Column_type_defaultShow);
      let parse = JSON.parse(stringify);
    
      
      let colShow:any = []
        parse.forEach((element:any) => {
          colShow.push({name:element,label:this.allColumnsForShow[element]})
        });
    
     
        let stringify_dataOption = JSON.stringify(this.filterApiDataOption);
        let dataOption = JSON.parse(stringify_dataOption);  
    
  
    
        let cellW = [];
        let children = this.data_table._elementRef.nativeElement.firstElementChild.children;
        for (let i = 0; i < children.length; i++) {
          let header = children[i].style.minWidth;
          let string = header.replace("px", "");
          var number = string.replace("%", ""); 
         cellW.push(Number(number))
        }
    

        
        
        let apiUrl = 'sales/getSalesBibleFilterList';
        let fileName='Sales Bible';
      

    
       const dialogRef = this.dialog.open(DownloadComponent, {
          width:'600px',   
          autoFocus:false, 
          data:{
            endPoint:apiUrl,
            fileName:fileName,
            dataOption:dataOption,
            colShow:colShow,
            cellW:cellW
          },
        });
     
    }

    /******************* */

    openDialogUserInfo(element:any){
      debugger
      const dialogRef = this.dialog.open(ViewUserInfoComponent, {
        height: 'auto',
        width: '610px',
        data: {
          name:element.customer_name,
          email:element.customer_email_id,
          phone:element.customer_phone_no
        },
      });
    
      dialogRef.beforeClosed().subscribe((result: any) => {
        if (result) {
          this.loadGrid_Data();
        }
      })
    
    }
    
    getBtoa(data:string){
      return btoa(data);
      }
      jsonP(data:any){
        return data?JSON.parse(data):[]  
      }
      
      jsonS(data:any){
        return data?JSON.stringify(data):""    
      } 
 
}
