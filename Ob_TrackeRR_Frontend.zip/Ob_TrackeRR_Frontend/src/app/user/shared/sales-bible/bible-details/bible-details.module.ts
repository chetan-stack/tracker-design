import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BibleDetailsRoutingModule } from './bible-details-routing.module';
import { BibleDetailsComponent } from './bible-details.component';
import { DownloadModule } from '../../dialog/download/download.module';
import { ViewUserInfoModule } from '../../dialog/view-user-info/view-user-info.module';
import { SharedModule } from '../../shared.module';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';


@NgModule({
  declarations: [
    BibleDetailsComponent
  ],
  imports: [
    CommonModule,
    BibleDetailsRoutingModule,
    DownloadModule,
    NgxMatSelectSearchModule,
    SharedModule,   
    ViewUserInfoModule,
  ]
})
export class BibleDetailsModule { }
