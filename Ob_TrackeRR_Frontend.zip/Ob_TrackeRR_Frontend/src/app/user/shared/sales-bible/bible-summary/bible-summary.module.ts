import { NgModule } from '@angular/core';
import { CommonModule, TitleCasePipe } from '@angular/common';
import { BibleSummaryComponent } from './bible-summary.component';
import { SharedModule } from '../../shared.module';
import { BibleSummaryRoutingModule } from './bible-summary-routing.module';



@NgModule({
  declarations: [
    BibleSummaryComponent
  ],
  imports: [
    CommonModule, 
    SharedModule,
    BibleSummaryRoutingModule     
  ],
  exports:[BibleSummaryComponent],
  providers: [TitleCasePipe]
})
export class BibleSummaryModule { }
