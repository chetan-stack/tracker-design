import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router'; 
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as echarts from 'echarts';  
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import * as moment from 'moment';
import { CookieService } from 'ngx-cookie-service';

 

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 
 

@Component({
  selector: 'app-bible-summary',
  templateUrl: './bible-summary.component.html',
  styleUrls: ['./bible-summary.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    //{provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}}
  ],
}) 
export class BibleSummaryComponent implements OnInit {
  getCurrentUser: any ={};  
  currentMonth:any ={
    from_date:this.getStartEndDays(new Date().toISOString()).start,
    to_date:this.getStartEndDays(new Date().toISOString()).end, 
  }; 
 
  moment = moment; 
  storeAllData:any=[]; 
  storeSalesPerformanceData:any=[]; 
  filteredMonth:any
  centerColor:any ={}; 
  teamColor:any; 
  all_team_color_light:any= {
    1:"#d7e8fa",
    2:"#fbedd2",
    3:"#d1eee2",  
    4:"#eeddf4", 
  }
  salesType_list:any={}; 
  
@ViewChild('prevTemplate') prevTemplate: TemplateRef<any>; 
prevTemplateRef:any;



chartViewShow:any = "details"; 
DivIDSalesPerformanceChart:any;

  constructor( 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    private cookieService: CookieService, 
    private router: Router,
    private route:ActivatedRoute,
    private dialog: MatDialog
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
 


    this.centerColor = this.dataFactory.all_centerColor;
    this.teamColor = this.dataFactory.all_team_color; 
    this.salesType_list = this.dataFactory.salesType_list; 
    

    const ifDateCount = this.cookieService.get('filtered_date_SalesBible');
    debugger
    if(ifDateCount){
     const parsCount = JSON.parse(ifDateCount)
     this.currentMonth.from_date = parsCount.from_date;
     this.currentMonth.to_date = parsCount.to_date;   
    }

    this.lodeSalesPerformance();
  }

  dateInputChange(val:any){{
    if(val){ 
      this.cookieService.set( 'filtered_date_SalesBible', JSON.stringify({
        from_date:this.currentMonth.from_date,
        to_date:this.currentMonth.to_date,
      }),1,'/');  
      this.lodeSalesPerformance()  
    }
  }
    
  }

  
  lodeSalesPerformance(){ 
     //debugger   
   

    if(!this.currentMonth.to_date){
      return
    }

    let dataOpt:any ={
      from_date:moment(this.currentMonth.from_date).format('YYYY-MM-DD'),
      to_date:moment(this.currentMonth.to_date).format('YYYY-MM-DD'),
    }; 

    if(this.getCurrentUser.activeRole!='account' && this.getCurrentUser.activeRole!='ops'){
      dataOpt["center_id"] = this.getCurrentUser.center_id;
      dataOpt["team_id"] = this.getCurrentUser.team_id;
    }


    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('sales/getSalesBibleDashboardData',dataOpt).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
        if(res.status){
        let data = JSON.stringify(res.data);
        this.storeAllData =JSON.parse(data);    
  
        this.onChangeView('graph');
      

       
       }else{
         this.storeAllData =[]; 
       }
    })
     
  

  }

  onChangeView(event:any){
    //debugger
    if(event=='graph'){
      setTimeout(()=>{  
        //this.bindTreeGraphData();
       },200);

     
    }
    
  }


  bindTreeGraphData(){
    debugger 
        let forThis = this;
 
        let SData = JSON.stringify(this.storeAllData);
        let allData =JSON.parse(SData); 
  
 
     
      let allChartData:any = []
  
     allData.forEach(function(team:any,i:any) {  
      //debugger
      let centerData:any=[];
      let total_team_achment = 0;
      let source_dtl:any=[];
   
       team.center_data.forEach((center:any) => {
        
        total_team_achment = total_team_achment+center.lead_origin_dtl.total_achievment;
       
        
        center.lead_origin_dtl.source_dtl.forEach((element: any) => {
         
          const index = source_dtl.findIndex((dtl:any) => dtl['source'] === element.source);

          if (index > -1) {
           // debugger
            source_dtl[index].achievment = source_dtl[index].achievment+element.achievment;
          //  source_dtl[element.source] = source_dtl[element.source]+element.achievment
          }else{
            source_dtl.push(element);
          }
        });

         centerData.push({
           name: center.center_name,
           value:center.lead_origin_dtl.total_achievment,
           source_dtl:source_dtl,
           itemStyle: {
             color: forThis.teamColor[team.team_id]
           } 
         });
 
       }); 

        
       allChartData.push({  // Team Chart Data
         name: team.team_name,
         value:total_team_achment,
         source_dtl:source_dtl,
         itemStyle: {
           color: forThis.teamColor[team.team_id]
         },
         children:centerData // Center Chart Data
       });
 
        // console.log(team.team_name+" ==============")
        //  console.log(source_dtl)
     })
 
   
 
   
   this.DivIDSalesPerformanceChart = echarts.init((document.getElementById('DivIDSalesPerformanceChart')) as any);
   
     let option =  {
       tooltip: {
         trigger: 'item',
         triggerOn: 'mousemove'
       },
       series: [
         {
           type: 'tree', 
           label: {
            formatter: (params:any) => {
              debugger
             let source = ''
              if(params.dataIndex!=1){
                params.data.source_dtl.forEach((s:any) => {
                  source = source+`{list|${s.source}} \n`
               });
              }
             //return `{title|${params.data.name}}{abg|} \n {hr|}\n ${source}`
              return [`{title|${params.data.name}}{abg|}`,`{weatherHead|Source}{valueHead|Achievment}{rateHead|Revenue (In Lacs)}`].join('\n')
            }, 

            // formatter: [
            //   '{title|{b}}{abg|}',
            //   '  {weatherHead|Weather}{valueHead|Days}{rateHead|Percent}',
            //   '{hr|}',
            //   '  {Sunny|}{value|202}{rate|55.3%}',
            //   '  {Cloudy|}{value|142}{rate|38.9%}',
            //   '  {Showers|}{value|21}{rate|5.8%}'
            // ].join('\n'),
            backgroundColor: '#eee',
            borderColor: '#777',
            borderWidth: 1,
            borderRadius: 4,
            rich: {
              title: {
                color: '#eee',
                align: 'center'
              },
              abg: {
                backgroundColor: '#333',
                width: '100%',
                align: 'right',
                height: 25,
                borderRadius: [4, 4, 0, 0]
              },
              Sunny: {
                height: 30,
                align: 'left',
                backgroundColor: {
                 // image: weatherIcons.Sunny
                }
              },
              Cloudy: {
                height: 30,
                align: 'left',
                backgroundColor: {
                 // image: weatherIcons.Cloudy
                }
              },
              Showers: {
                height: 30,
                align: 'left',
                backgroundColor: {
                 // image: weatherIcons.Showers
                }
              },
              weatherHead: {
                color: '#333',
                height: 24,
                align: 'left'
              },
              hr: {
                borderColor: '#777',
                width: '100%',
                borderWidth: 0.5,
                height: 0
              },
              value: {
                width: 20,
                padding: [0, 20, 0, 30],
                align: 'left'
              },
              valueHead: {
                color: '#333',
               // width: 20,
                padding: [0, 20, 0, 30],
                align: 'center'
              },
              rate: {
                width: 40,
                align: 'right',
                padding: [0, 10, 0, 0]
              },
              rateHead: {
                color: '#333',
               // width: 40,
                align: 'center',
                padding: [0, 10, 0, 0]
              }
            }
           }, 
           data: [{
               name: "flare",
               children:allChartData 
             }], 
          top: '0%',
          bottom: '0%',
         // layout: 'radial',
          symbol: 'emptyCircle',
          symbolSize: 7,
          initialTreeDepth: 3,
           animationDurationUpdate: 750, 
           emphasis: {
             focus: 'descendant'
           }
         }
       ]
     }
   
   
    
   this.DivIDSalesPerformanceChart.setOption(option,true);
 
  
 
 }


  bindGraphData(){
    debugger 
        let forThis = this;
  
        let SData = JSON.stringify(this.storeAllData);
        let allData =JSON.parse(SData); 
  
  
        let teamData:any = []
   
        allData.forEach(function(team:any,i:any) {  
         debugger
         let centerData:any=[];
         let total_achievment_team = 0;
      
          team.center_data.forEach((center:any) => {
           
            total_achievment_team = total_achievment_team+center.lead_origin_dtl.total_achievment

            centerData.push({
              name: center.center_name,
              value:20,
              itemStyle: {
                color: forThis.teamColor[team.team_id]
              }, 
            });
    
          });
    
           
          teamData.push({
            name: team.team_name,
            value:total_achievment_team,
            itemStyle: {
              color: forThis.teamColor[team.team_id]
            },
            children:centerData
          });
    
        })
  
   
   this.DivIDSalesPerformanceChart = echarts.init((document.getElementById('DivIDSalesPerformanceChart')) as any);
   
     let option = {
       tooltip: {
         trigger: 'item',
         formatter: '{a} <br/>{b}: {c} ({d}%)'
       },
       legend: {
       // orient: 'vertical',
       // left: 'left'
      },
       series: [ 
         {
           name: 'Access From',
           type: 'pie',
           radius: [0, '50%'],
           height: 500,
           top:'top',
           left: 'left',
           width:'60%',
           labelLine: {
             length: 30
           },
           label: {
             formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
             backgroundColor: '#F6F8FC',
             borderColor: '#8C8D8E',
             borderWidth: 1,
             borderRadius: 4,
             rich: {
               a: {
                 color: '#6E7079',
                 lineHeight: 22,
                 align: 'center'
               },
               hr: {
                 borderColor: '#8C8D8E',
                 width: '100%',
                 borderWidth: 1,
                 height: 0
               },
               b: {
                 color: '#4C5058',
                 fontSize: 14,
                 fontWeight: 'bold',
                 lineHeight: 33
               },
               per: {
                 color: '#fff',
                 backgroundColor: '#4C5058',
                 padding: [3, 4],
                 borderRadius: 4
               }
             }
           },
           data:teamData
         } 
       ]
     };
   
   
    
   this.DivIDSalesPerformanceChart.setOption(option,true);
  
  
  
  }

  
 

  refreshData(){
    this.currentMonth  ={
      from_date:this.getStartEndDays(new Date().toISOString()).start,
      to_date:this.getStartEndDays(new Date().toISOString()).end, 
    };
    
    this.cookieService.delete('filtered_date_SalesBible','/');   
    this.lodeSalesPerformance(); 
  }


  ngOnInit(): void {
  }
  getStartEndDays(date:any){   
    return this.serviceFactory.getStartEndDays(date);
  }

 
  fullscreen(){
    if(this.prevTemplateRef){
      this.prevTemplateRef.close();
      this.prevTemplateRef = undefined
      return
    } 
    this.prevTemplateRef = this.dialog.open(this.prevTemplate, { 
        height: 'calc(100vh - 10px)',
        maxHeight: 'calc(100vh - 10px)',
        width: 'calc(100vw - 10px)', 
        maxWidth: 'calc(100vw - 10px)',
        autoFocus:false,
        restoreFocus:false, 
        //scrollStrategy: new NoopScrollStrategy(),
        panelClass: "fullscreen-modal",
        data:{fullscreen:true}
    });
    this.prevTemplateRef.beforeClosed().subscribe((result: any) => {
      if (result) { 
      }
    })
  }
  
  jsonS(data:any){
    return data?JSON.stringify(data):""    
  
  }
  getBtoa(data:string){
    return btoa(data);
    }

}
