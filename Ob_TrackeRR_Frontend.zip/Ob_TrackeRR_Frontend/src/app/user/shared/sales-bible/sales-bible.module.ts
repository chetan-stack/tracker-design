import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalesBibleModuleConst, SalesBibleRoutingModule } from './sales-bible-routing.module';
 


@NgModule({
  declarations: [
    SalesBibleModuleConst
  ],
  imports: [
    CommonModule,
    SalesBibleRoutingModule, 
  ]
})
export class SalesBibleModule { }
