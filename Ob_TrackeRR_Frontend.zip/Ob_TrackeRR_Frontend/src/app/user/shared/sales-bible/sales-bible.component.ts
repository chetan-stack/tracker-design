import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-bible',
  templateUrl: './sales-bible.component.html',
  styleUrls: ['./sales-bible.component.scss']
})
export class SalesBibleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
