import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'; 
import { SalesBibleComponent } from './sales-bible.component';
 

const routes: Routes = [ 
  {
    path: '', component: SalesBibleComponent,  
    data:{pageType:'SalesBible'},   
     children: [    
              { path: 'summary', loadChildren: () => import(`./bible-summary/bible-summary.module`).then(m => m.BibleSummaryModule)},
              { path: 'bible-details', loadChildren: () => import(`./bible-details/bible-details.module`).then(m => m.BibleDetailsModule)},

              {path: '', redirectTo: 'summary', pathMatch: 'full'},  
        ],   
     }, 
        
];   

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalesBibleRoutingModule { }
export const SalesBibleModuleConst = [  
  SalesBibleComponent,   
];