import { Component, ElementRef, Inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Component({
  selector: 'app-change-email',
  templateUrl: './change-email.component.html',
  styleUrls: ['./change-email.component.scss']
})
export class ChangeEmailComponent implements OnInit {
  getCurrentUser: any ={};
 

  @ViewChild('ngElmSendRequest') public ngElmSendRequest: NgForm;
 
  

  constructor(
    @Inject(MAT_DIALOG_DATA) public AddEditData: any,
    private dialogRef: MatDialogRef<ChangeEmailComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService,  
  ) {
    debugger
    this.getCurrentUser = this.commonService.getCurrentUser(); 
 
  }
 
  
  ngOnInit(): void {

  }


  ngAfterViewInit(){ 
   
  } 
 
 
 

  
onSubmit(Form_Group:any){
    debugger 
     
      
    // stop here if form is invalid 
    if (Form_Group.invalid) {
        return;
    }
    let elmForm = Form_Group.value; 
    elmForm['old_email'] = this.AddEditData.email;
 
    

 
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('admin/updateCustomerEmail',elmForm).pipe(  
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){
        this.dialogRef.close(res); 
      } 
     }) 
     
  
     
     
 }
 
}
