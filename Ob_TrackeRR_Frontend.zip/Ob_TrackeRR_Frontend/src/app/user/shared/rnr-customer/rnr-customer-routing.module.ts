import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'; 
import { CustomerListComponent } from './customer-list/customer-list.component';
import { RnrCustomerComponent } from './rnr-customer.component';

const routes: Routes = [ 
  {
    path: '', component: RnrCustomerComponent,  
    data:{pageType:'RnrCustomer'},   
     children: [    
              {path: 'list', component: CustomerListComponent ,data:{title: 'RNR Customers'}}, 
              {path: '', redirectTo: 'list', pathMatch: 'full'},  
        ],   
     }, 
        
];   

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RnrCustomerRoutingModule { }
export const RnrCustomerModuleConst = [  
  RnrCustomerComponent,  
  CustomerListComponent
];