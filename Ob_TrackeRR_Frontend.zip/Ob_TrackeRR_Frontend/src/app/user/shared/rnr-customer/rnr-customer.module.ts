import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
 import { SharedModule } from '../shared.module';
import { RnrCustomerModuleConst, RnrCustomerRoutingModule } from './rnr-customer-routing.module';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { DownloadModule } from '../dialog/download/download.module';
import { FilePreviewModule } from '../dialog/file-preview/file-preview.module';
import { ViewUserInfoModule } from '../dialog/view-user-info/view-user-info.module'; 
import { ChangeEmailComponent } from './change-email/change-email.component';


@NgModule({
  declarations: [
    RnrCustomerModuleConst,
    ChangeEmailComponent 
  ],
  imports: [
    CommonModule,
    SharedModule, 
    RnrCustomerRoutingModule,  
    ViewUserInfoModule,
    FilePreviewModule,
    DownloadModule, 
    NgxMatSelectSearchModule, 
  ]
}) 
export class RnrCustomerModule { }
