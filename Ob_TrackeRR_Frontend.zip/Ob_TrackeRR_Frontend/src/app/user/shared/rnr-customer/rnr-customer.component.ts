import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rnr-customer',
  templateUrl: './rnr-customer.component.html',
  styleUrls: ['./rnr-customer.component.scss']
})
export class RnrCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
