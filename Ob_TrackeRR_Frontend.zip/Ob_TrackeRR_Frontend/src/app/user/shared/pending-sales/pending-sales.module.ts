import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
 
import { SharedModule } from '../shared.module';   
import { PendingSalesModuleConst, PendingSalesRoutingModule } from './pending-sales-routing.module';
import { PendingListComponent } from './pending-list/pending-list.component'; 
import { BulkUploadModule } from '../dialog/bulk-upload/bulk-upload.module';

 
 

@NgModule({
  declarations: [
    PendingSalesModuleConst
   ],
  imports: [
    CommonModule, 
    SharedModule,   
    PendingSalesRoutingModule,
    BulkUploadModule  
  ], 
})
export class PendingSalesModule { }
