import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-sales',
  templateUrl: './pending-sales.component.html',
  styleUrls: ['./pending-sales.component.scss']
})
export class PendingSalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
