import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';     
import { PendingListComponent } from './pending-list/pending-list.component';
import { PendingSalesComponent } from './pending-sales.component';

 
  
 
const routes: Routes = [ 
  {
    path: '', component: PendingSalesComponent,  
    data:{pageType:'PendingSales'},   
     children: [    
              {path: 'list', component: PendingListComponent ,data:{title: 'Pending Sales'}}, 
              {path: '', redirectTo: 'list', pathMatch: 'full'},  
        ],   
     }, 
        
];   

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PendingSalesRoutingModule { }
export const PendingSalesModuleConst = [  
  PendingSalesComponent,  
  PendingListComponent
];