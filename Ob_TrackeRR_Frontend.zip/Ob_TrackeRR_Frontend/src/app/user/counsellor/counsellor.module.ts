import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { CounsellorModuleConst, CounsellorRoutingModule } from './counsellor-routing.module';
import { CoreModule } from '../core/core.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';



@NgModule({
  declarations: [CounsellorModuleConst],
  imports: [
    CommonModule,  
    CounsellorRoutingModule, 
    CoreModule,
    MatSidenavModule, 
    MatToolbarModule   
  ]
})
export class CounsellorModule { }
