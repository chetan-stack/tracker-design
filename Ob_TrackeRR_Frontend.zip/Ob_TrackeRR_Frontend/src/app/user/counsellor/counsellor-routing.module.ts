import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/auth/auth.guard'; 
import { CounsellorComponent } from './counsellor.component';



const routes: Routes = [ 
  {
     path: '', component: CounsellorComponent, 
     canActivate: [AuthGuard],
     data: { roles: "counsellor"},  
     children: [  
          {path: 'home', loadChildren: () => import(`../shared/home/home.module`).then(m => m.HomeModule)},
          {path: '', redirectTo: 'home', pathMatch: 'full'},   
          {path: 'onboarding', loadChildren: () => import(`../shared/onboarding/onboarding.module`).then(m => m.OnboardingModule)},  
          {path: 'sales', loadChildren: () => import(`../shared/sales/sales.module`).then(m => m.SalesModule)},
          {path: 'share-leads', loadChildren: () => import(`../shared/share-leads/share-leads.module`).then(m => m.ShareLeadsModule)},  
          {path: 'secrets', loadChildren: () => import(`../shared/secrets/secrets.module`).then(m => m.SecretsModule)},
          {path: 'pmp-pending', loadChildren: () => import(`../shared/pending-pmp/pending-pmp.module`).then(m => m.PendingPmpModule)},

          //  {path: 'dashboard', component: DashboardComponent ,data:{title: 'Manager Dashboard'}},
          //  {path: 'salesform', component: SalesformComponent ,data:{type:"Add", title: 'Sales Form Management'}},           
          //  {path: 'salesform/edit/:id', component: SalesformComponent ,data:{type:"Edit", title: 'Sales Form Management'}},
          //  {path: 'salesform/view/:id', component: SalesformComponent ,data:{type:"View", title: 'Sales Form Management'}},
          //  {path: 'salesform/edit', redirectTo: 'dashboard', },
          //  {path: 'salesform/view', redirectTo: 'dashboard', },
          {path: 'ic', loadChildren: () => import(`../shared/incentive/incentive.module`).then(m => m.IncentiveModule)}, 
          
     ], 
     },  
       
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CounsellorRoutingModule { }

export const CounsellorModuleConst = [  
  CounsellorComponent,  
];