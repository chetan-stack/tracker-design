import { Component, OnInit } from '@angular/core';
import {MatBottomSheet, MatBottomSheetRef} from '@angular/material/bottom-sheet';
import { WebsocketService } from 'src/services/api/web-socket.service ';
import { ChatComponent } from '../dialog/chat/chat.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
 onlineUserCount:any = 0;
  constructor(
    private bottomSheet: MatBottomSheet,
   // private websocket: WebsocketService, 
  ) {
   
   }

  ngOnInit() {
    // this.websocket.getOnlineVisitors.subscribe((res: any) => {
    //   this.onlineUserCount = Object.keys(res).length; 
    // });
    // this.websocket.setupSocketConnection();
  }
  
  ngOnDestroy() {
   // this.websocket.disconnect();
  }
   

 onOpenChat(){
    this.bottomSheet.open(ChatComponent,{
      panelClass: 'chat-box-container'
    });
  }
}
