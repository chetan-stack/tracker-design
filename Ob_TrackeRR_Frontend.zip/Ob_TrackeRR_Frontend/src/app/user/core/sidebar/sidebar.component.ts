import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { SidebarService } from './sidebar.service';
import { CommonService } from 'src/services/api/common.service';
import { environment } from 'src/environments/environment';
import { DataFactoryService } from 'src/services/factory/data-factory.service'; 
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import { KeyValue } from '@angular/common';
import { ActivatedRoute, Router, RouterLinkActive } from '@angular/router';
import { ProfileComponent } from '../profile/profile.component';
import { MatDialog } from '@angular/material/dialog';
 
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('slide', [
      state('up', style({ height: 0 })),
      state('down', style({ height: '*' })),
      transition('up <=> down', animate(200))
    ])
  ]
})
export class SidebarComponent implements OnInit {
  spMenuProductVersion:any;
  getCurrentUser:any = {};
  getUserProfile:any = {};
  salesType_list:any = {};

  rnr_domain:any;
  
 
activeDropdownMenu:any;
@ViewChild(RouterLinkActive) private routerLinkActive: any; 

menuLink:any = []
 

   constructor(
    public sidebarservice: SidebarService,
    public commonService: CommonService,
    public dataFactory: DataFactoryService,
    public serviceFactory: ServiceFactory, 
    public router: Router,
    public route: ActivatedRoute,
    private dialog: MatDialog , 
    ) { 
     // debugger
    this.spMenuProductVersion = environment.appVersion; 


    this.getCurrentUser = this.commonService.getCurrentUser(); 
    this.menuLink = this.sidebarservice.getMenuList(this.getCurrentUser);
  
     

    this.dataFactory.get_Profile().subscribe(res => {
      this.getUserProfile = res;
   })
   

   }
 
  ngOnInit() {
   // this.liveincentive();
    }
  ngAfterViewInit() { 
    setTimeout(()=>{  
      
      let getactive =  document.querySelector<any>('.active[routerlinkactive="active"]');  
      if(getactive && getactive.dataset?.menusid){ 
        this.toggle(this.menuLink[getactive.dataset.menusid]) 
      }  
    },200);

  }
  getBtoa(data:string){
  return btoa(data);
  }
  jsonP(data:any){
    return data?JSON.parse(data):[]  
  }
  
  jsonS(data:any){
    return data?JSON.stringify(data):""    
  }  
 
  logoutUser(url: any) {   
    this.commonService.logoutByClick(url); 
   }
   originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
    return 0;
  }
  
 
 

  showDialog_Profile(){
    debugger  
    const dialogRef = this.dialog.open(ProfileComponent,{ 
      width:'1000px', 
     // disableClose: true, 
        data:{ 
        }, 
    });
    dialogRef.beforeClosed().subscribe(result => {
    if(result){  
      
    }       
  }) 
  }
 




  /******************************************/

toggle(currentMenu:any) { 
  this.menuLink.forEach((element:any) => {
    if (element === currentMenu) {
      currentMenu.active = !currentMenu.active;
    } else {
      element.active = false;
    }
  });
}

getState(currentMenu:any) { 
  if (currentMenu.active) {
    return 'down';
  } else {
    return 'up';
  }
}
 
}


