import { BreakpointObserver } from '@angular/cdk/layout';
import { Injectable } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';

@Injectable({
  providedIn: 'root'
})
export class SidebarService {
 
  salesType_list:any = {};

  
  public sidenav: any;

  public sideNavToggleSubject: BehaviorSubject<any> = new BehaviorSubject(null);
 
  constructor(
    private router: Router,
    public mediaQ: BreakpointObserver,
    public commonService: CommonService,
    public dataFactory: DataFactoryService,
    public serviceFactory: ServiceFactory, 
    ) { 
      this.salesType_list = this.dataFactory.salesType_list; 

     

    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd && mediaQ.isMatched('(max-width: 991px)')) {
        // this.toggle(event.urlAfterRedirects);
        if(this.sidenav) this.sidenav.close();  
      }
    });
 
  }
  

  public toggle(event: any) {
    debugger
    if(this.sidenav){ 
        if(this.sidenav.opened){
          this.close()
        }else{
          this.open()
        }
        
    } 
  } 

 
  close(){
    this.sidenav.close();
  }
 
  open(){
    this.sidenav.open();
  }
 

  /*********************** */

  getMenuList(user:any) {
     debugger
  let forThis = this;
  let menuLink:any = [
    {
      title:'Dashboard',  
      url:'./home', 
      icon:'rr-home',
      active: true  
    }  
  ]

  if(user.activeRole=='counsellor' || user.activeRole=='manager' || user.activeRole=='admin'){
  
    let generateLink:any = [];
    let historyLink:any = [];

    user.sales_type.forEach((item:any) => {
        generateLink.push({
          title:forThis.salesType_list[item.access_name],
          url:(item.access_name=='pmp_lt' || item.access_name=='dwn_lt')?'./onboarding/generate-pmp':'./onboarding/generate', 
          params:{salestype: item.access_name}
        })
       historyLink.push({
        title:forThis.salesType_list[item.access_name],
        url:'./onboarding/history', 
        params:{salestype: item.access_name}
       })
    });

    if(user.activeRole!='admin'){
      menuLink.push({
        title:'Generate URL', 
        url:undefined,
        icon:'rr-file-list',
        active: false, 
        type: 'dropdown', 
        submenus:generateLink
      })
    }


    menuLink.push({
      title:'OB History', 
      url:undefined,
      icon:'rr-file-list',
      active: false, 
      type: 'dropdown', 
      submenus:historyLink
    })
   
  }


if(user.activeRole=='counsellor' || user.activeRole=='manager' || user.activeRole=='saleshead'){
  menuLink.push({
    title:'Sales Form', 
    url:'./sales',
    icon:'rr-cog',
    active: false,  
  })
}

if(user.activeRole=='counsellor' || user.activeRole=='manager'){
  menuLink.push({
    title:'PMP Pending', 
    url:'./pmp-pending',
    icon:'account-switch',
    active: false,  
  })
}


if(user.activeRole=='account' || user.activeRole=='ops' || user.activeRole=='admin'){ 
menuLink.push({
  title:'Sales Team', 
  url:undefined,
  icon:'rr-users',
  active: false, 
  type: 'dropdown', 
  submenus:[]
})
}
 

if(user.activeRole=='manager' && user.team_id==1){
  menuLink.push({
    title:'Lead Mgmt', 
    url:'./ic/lead-management',
    icon:'clipboard-list-outline',
    active: false,  
  })
}


if(user.activeRole=='saleshead' || user.activeRole=='manager'){
  menuLink.push({
    title:'My Team', 
    url:'./team',
    icon:'rr-team-hand',
    active: false,  
  })
}


if(user.activeRole=='saleshead' || user.activeRole=='manager'){
  menuLink.push({
    title:'Target', 
    url:'./target',
    icon:'rr-goal-target',
    active: false,  
  })
}    
 

if((this.getMap(user.sales_type,'access_name').includes('retail_renewal') || this.getMap(user.sales_type,'access_name').includes('dwn_renewal')) && (user.activeRole=='counsellor' || user.activeRole=='manager')){
  menuLink.push({
    title:'Portfolio Request', 
    url:'./onboarding/portfolio-request',
    icon:'monitor-dashboard',
    active: false,  
    params:{salestype: this.getMap(user.sales_type,'access_name').includes('retail_renewal')?'retail_renewal':'dwn_renewal'}
  })
}

if(user.activeRole=='counsellor' || user.activeRole=='manager' || user.activeRole=='saleshead'){
  menuLink.push({
    title:'Share Leads', 
    url:'./share-leads/list',
    icon:'rr-share',
    active: false,  
  }) 
}


if(user.activeRole=='ops' || (user.activeRole=='manager' && this.getMap(user.sales_type,'access_name').includes('pmp_lt')) || (user.activeRole=='counsellor' && user.secrets_calling_access)){
  menuLink.push({
    title:'Secrets', 
    url:'./secrets',
    icon:'account-lock-open-outline',
    active: false,  
  }) 
}


if(user.activeRole=='account' || user.activeRole=='ops' || user.activeRole=='admin'){
  let enachLink:any = []; 

  if(user.activeRole=='account'){
    enachLink.push({
      title:'Skip Requests',
      url:'./enach/skip-list',  
     })
  }

  enachLink.push({
    title:'Payment List',
    url:'./enach/tranch-list',  
   })

  if(user.activeRole!='admin'){
    enachLink.push({
      title:'Cancellation Requests',
      url:'./enach/cancel-list',  
     })
  }

   

  menuLink.push({
    title:'Enach', 
    url:undefined,
    icon:'bank-check',
    active: false, 
    type: 'dropdown', 
    submenus:enachLink
  })
}


if((user.activeRole=='manager' && user.team_id==1) || (user.activeRole=='manager' && user.team_id==4) || (user.activeRole=='manager' && user.team_id==2)){
  menuLink.push({
    title:'RegisteRR', 
    url:'./register',
    icon:'notebook-edit-outline',
    active: false,  
  }) 
}


if(user.activeRole=='manager' || user.activeRole=='ops' || user.activeRole=='account'){
  menuLink.push({
    title:'Refund', 
    url:'./refund',
    icon:'cash-refund',
    active: false,  
  }) 
}

if(user.activeRole=='account'){
  menuLink.push({
    title:'Pending Sales', 
    url:'./pending-sales',
    icon:'account-switch',
    active: false,  
  }) 
}


if(user.activeRole=='account' || user.activeRole=='ops' || user.activeRole=='admin'){
  

  menuLink.push({
    title:'RNR Team', 
    url:'./team',
    icon:'rr-team-hand',
    active: false,  
  })

  menuLink.push({
    title:'RNR Customers', 
    url:'./rnr-customer',
    icon:'account-group',
    active: false,  
  }) 

}


/*****************************************/
this.dataFactory.get_TeamList().subscribe(res => { 
  let teamLink:any = []; 

  res.forEach((item:any) => { 
    teamLink.push({
      title:item.team_name,
      url:'./sales', 
      params:{team:[item.id].join(',')}
     }) 
  });

  const index = menuLink.findIndex((m:any) => m.title === 'Sales Team');

  if (index > -1) {
    menuLink[index].submenus = teamLink
  }

})


    return menuLink;
  }

  getMap(data:any,key:any){
    if(data && data.length>0){
      return data.map((x:any) => x[key]);
    }else{
      return []
    }
    
  }
 
}