import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common'; 
import { RouterModule } from '@angular/router'; 

 



/****** component *****/
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component'; 
import { SharedModule } from '../shared/shared.module';
import { IcComponent } from './ic/ic.component';
import { ProfileComponent } from './profile/profile.component';  
import { ImageCropperModule } from 'ngx-image-cropper';
import { NotificationsComponent } from './dialog/notifications/notifications.component';
import { ChatComponent } from './dialog/chat/chat.component'; 
import { WebsocketService } from 'src/services/api/web-socket.service ';


@NgModule({
    declarations: [
        HeaderComponent,
        FooterComponent,
        SidebarComponent,
        IcComponent,
        ProfileComponent,
        NotificationsComponent,
        ChatComponent,
    ],
    imports: [
        CommonModule,
        RouterModule,
        ImageCropperModule,
        SharedModule,
    ],
    exports: [
        HeaderComponent,
        FooterComponent,
        SidebarComponent,
        IcComponent,
        ProfileComponent
    ],
    //providers: [WebsocketService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CoreModule { }
