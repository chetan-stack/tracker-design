import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Dimensions, ImageCroppedEvent, ImageTransform, base64ToFile } from 'ngx-image-cropper';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as moment from 'moment'; 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'D MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  providers: [ 
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
   // {provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: {useUtc: true}},
    
  ],
})
export class ProfileComponent implements OnInit {
  getCurrentUser: any ={};
  getUserProfile:any = {};
  pageTypeMode:string;
  
   salesType_list:any;

  leadIdData:any = {
    lead_data:{},
    lead_share_with:{},
  };
  
    imageChangedEvent: any = '';
    croppedImage: any;
    canvasRotation = 0; 
    rotation = 0;
    scale = 1;
    showCropper = false;
    containWithinAspectRatio = false;
    transform: ImageTransform = {};
 
@ViewChild('elm_phone_no') public elm_phone_no: any;   
  constructor(
    @Inject(MAT_DIALOG_DATA) private AddEditData: any,
    private dialogRef: MatDialogRef<ProfileComponent>,
    private dialog: MatDialog, 
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
  ) {
    
    this.getCurrentUser = this.commonService.getCurrentUser();
    this.pageTypeMode = AddEditData.type; 

    this.dataFactory.get_Profile().subscribe(res => {
      this.getUserProfile = res; 
   })

   
  }
  
  ngOnInit(): void {

  }

  
  
imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64; 
}
imageLoaded() {
  this.showCropper = true; 
}
cropperReady(sourceImageDimensions: Dimensions) {
  console.log('Cropper ready', sourceImageDimensions);
}
loadImageFailed() {
  console.log('Load failed');
}

zoomOut() {
  this.scale -= .1;
  this.transform = {
      ...this.transform,
      scale: this.scale
  };
}

zoomIn() {
  this.scale += .1;
  this.transform = {
      ...this.transform,
      scale: this.scale
  };
} 

resetImage() {
  this.scale = 1;
  this.rotation = 0;
  this.canvasRotation = 0;
  this.transform = {};
}


Save(form_elm:any){
  debugger 
  if (form_elm.invalid) {
    return;
}

  let form_Value = form_elm.value;    
  var file:any = null;
   if(this.croppedImage){
    let blob = base64ToFile(this.croppedImage);  
      file = new File([blob], "RNR_eSigned_Agreement.png", {
      type: "image/png",
     });
   }

   

    var formData = new FormData();
    formData.append('profile_img', file); 
    
    formData.append('name',form_Value.name);
    formData.append('designation',form_Value.designation);
    formData.append('date_of_joining',moment(form_Value.date_of_joining).format('YYYY-MM-DD'));
    formData.append('phone_no',form_Value.phone_no); 
    formData.append('gender',form_Value.gender);
    formData.append('password',form_Value.password?form_Value.password:null); 
 
     
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.commonService.post('userProfile/uploadProfileImage',formData).pipe( 
       finalize(() => {  
         this.serviceFactory.loadingStop("body","");
       })
     ).subscribe((res:any) => {  
      debugger 
      this.serviceFactory.notification(res.message,res.status); 
      if(res.status){ 
        setTimeout(()=>{   
          this.commonService.loadProfile(this.getCurrentUser.id);
          this.dialogRef.close(res);
        },1000);  
        
      }
  
     })  

   console.log(file)
}


 
_URL = window.URL || window.webkitURL;

  async fileChangeEvent(event:any){ 
    debugger  
   let validFile =  await this.fileFalidation(event.target.files[0]); 
 
   debugger
   if(!validFile){
    debugger
     event.target.value = "";  
   }else{ 
    this.imageChangedEvent = event;
    
   } 
  }

  async fileFalidation(file:any){ 
   debugger 
   let validFile = true;   
   const fileSize = file.size/1024/1024;	  
   const exts = ["png","jpg","jpeg"];


  if(fileSize > 5){
      this.serviceFactory.msgPop('Maximum file size should be 1 MB.','error'); 
      validFile = false
      return
   }



   if (file) {
     var get_ext = file.name.split('.'); 
       get_ext = get_ext.reverse();  
       if (! exts.some(function(el){ return el === get_ext[0]})){
        //this.serviceFactory.msgPop('File format is not supported. <br>Please select &nbsp; (.png, .jpg, .jpeg) &nbsp; file  only.','error');
        this.serviceFactory.notification('File format is not supported. <br>Please select &nbsp; (.png, .jpg, .jpeg) &nbsp; file  only.',false);
        validFile = false
        return 
     } 
   }


   let contentBuffer = await this.readFileAsync(file);
   debugger
    if(!contentBuffer){ 
      validFile = false
      return
    }
  
    return validFile
   
}

readFileAsync(file:any) {
  debugger
  const max_height = 5000;
  const max_width = 5000;
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e: any) => {
      const image = new Image();
      image.src = e.target.result;
      image.onload = (rs:any) => {
        const img_height = rs.currentTarget['height'];
        const img_width = rs.currentTarget['width'];
        console.log(img_height, img_width);
 
        if (img_height > max_height  || img_width > max_width) {
          this.serviceFactory.notification('Maximum dimentions allowed ' + max_height + '*' + max_width + 'px',false);
        // this.serviceFactory.msgPop('Maximum dimentions allowed ' + max_height + '*' + max_width + 'px','error'); 
         resolve(false); 
        }else{
          resolve(true);
        }

        
        
      }
    }
    reader.readAsDataURL(file);
  })
}
 
hasErrorPhone(ngModel:any,hasAction:any){ 
  debugger
 if(!hasAction){
   ngModel.control.setErrors({'incorrect': true}); 
 }else{
   ngModel.control.setErrors({'incorrect': false});
 } 
}


setInputVal(ngModel:any,value:string){ 
  debugger
  if(ngModel.value=="" || ngModel.value==null || ngModel.value==undefined){
    ngModel.control.setValue(value);
  }
   
}

}
