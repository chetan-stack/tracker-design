import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/services/api/common.service';
import { WebsocketService } from 'src/services/api/web-socket.service ';
import { DataFactoryService } from 'src/services/factory/data-factory.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss'],
 
})
export class ChatComponent implements OnInit {
  getCurrentUser:any = {};  
  getContactList:any = {}; 
  onlineUser: any = {}; 
  constructor(
    public commonService: CommonService, 
    public websocket: WebsocketService,   
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser();
      
  }

  async ngOnInit() {
    this.getContactList = await this.websocket.getEmit('getContactList'); 

    this.websocket.getOnlineVisitors.subscribe((res: any) => {
      this.onlineUser = res
    });


    
   
    
  }
  
  ngOnDestroy() { 
  }

  getNumber(val:any){
    return Number(val);
   }
 

}
