import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import * as moment from 'moment'; 
import { KeyValue } from '@angular/common';
import { finalize } from 'rxjs/operators';
import { SwPush } from '@angular/service-worker';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {
  moment = moment;
  getCurrentUser: any ={};
  getUserProfile:any = {}; 

  getNotifiactionCount:number = 0;
  getNotifiactionData:any={};
  constructor(
    private dataFactory: DataFactoryService, 
    private serviceFactory: ServiceFactory, 
    private commonService: CommonService, 
    private swPush: SwPush,
  ) { 
    this.getCurrentUser = this.commonService.getCurrentUser(); 

    this.dataFactory.get_Profile().subscribe(res => {
      this.getUserProfile = res; 
   })

   this.loadAdminNotifiaction({});
   }

  ngOnInit(): void {

    this.swPush.messages.subscribe((res:any) => {
      if(res['notification'] && res['notification'].body){ 
        this.getNotifiactionCount = this.getNotifiactionCount+1;
      }

    }) 
  }

  notificationMenuOpened(){
    this.loadAdminNotifiaction({action_type:'click'});
  }

  loadAdminNotifiaction(dataOpt:any){
    //debugger 
   let showByDays:any = {}
   showByDays[moment().format('DD MMMM YYYY')] = 'Today';
   showByDays[moment().subtract(1, 'days').format('DD MMMM YYYY')] = 'Yesterday';

   this.serviceFactory.loadingStart("body","Please wait while loading...","");

    this.commonService.post('miscellaneous/getAdminNotifiaction',dataOpt).pipe( 
      finalize(() => {  
        this.serviceFactory.loadingStop("body","");
      })
    ).subscribe((res:any) => {
      if(!dataOpt['action_type']){
        this.getNotifiactionCount = res.data.total_count;
      }else{ 
        this.getNotifiactionCount = 0;  
         let dataByDate:any = {};
          res.data.forEach((elm:any) => {
            let dateFormat = moment(elm.created_at).format('DD MMMM YYYY');
            let bindByDate = showByDays[dateFormat]?showByDays[dateFormat]:dateFormat

            if(!dataByDate[bindByDate]){
               dataByDate[bindByDate] = [];
            }
            dataByDate[bindByDate].push(elm);
            
          });

          this.getNotifiactionData = dataByDate;
      }
      
      
     })   
 }
 

 onClickNotifiaction(elm:any){
   debugger
 }

 originalOrder = (a: KeyValue<number,string>, b: KeyValue<number,string>): number => {
  return 0;
}
}
