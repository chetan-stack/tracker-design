import { BreakpointObserver } from '@angular/cdk/layout';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { Component, HostListener, Inject, OnInit, PLATFORM_ID, ViewChild} from '@angular/core';  
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { SwPush } from '@angular/service-worker';
import { CookieService } from 'ngx-cookie-service';
import { finalize, take } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { CommonService } from 'src/services/api/common.service';
import { DataFactoryService } from 'src/services/factory/data-factory.service';
import { ServiceFactory } from 'src/services/factory/service-factory.service';
import Swal from 'sweetalert2';
import { ProfileComponent } from '../profile/profile.component';
import { SidebarService } from '../sidebar/sidebar.service';

 
 
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'] 
})
  
export class HeaderComponent implements OnInit {
  Page_Title:string;
  getCurrentUser:any = {};
  getUserProfile:any = {}; 
  salesType_list:any = {};
   RoleIsSaleshead:boolean = true; 
   pushIsSubscribed = false;
   pushDisabled:boolean = false;
   deferredPrompt:any;
   appInstalled:boolean = true;
   appInstalledBtnShow:boolean = true;
   pushVoice:any = false;
   deniedDate:any = false; 
  constructor(
    private sidebarService: SidebarService,
    public commonService: CommonService, 
    private dataFactory: DataFactoryService,  
    private serviceFactory: ServiceFactory,
    public mediaQ: BreakpointObserver, 
    private router: Router,
    private route:ActivatedRoute, 
    private dialog: MatDialog , 
    private cookieService: CookieService,
    @Inject(PLATFORM_ID) private platformId: object,
    @Inject(DOCUMENT) private document: Document
 
    ) { 

   
      this.deniedDate = new Date().getDate()>4;
      
      // if(environment.production){ 
      //   this.deniedDate = new Date().getDate()>4;
      // }

      let forThis = this;
      this.getCurrentUser = this.commonService.getCurrentUser();  
      this.salesType_list = this.dataFactory.salesType_list; 
       this.dataFactory.getPageTitle().subscribe(title => {
        this.Page_Title = title.PageTitle;
       })

     if(this.getCurrentUser.activeRole=='saleshead'){
      this.RoleIsSaleshead=true;
     }else{
      this.RoleIsSaleshead=false;
     }

     this.dataFactory.get_Profile().subscribe(res => {
        this.getUserProfile = res; 
     })

     this.appInstalledBtnShow = !window.matchMedia('(display-mode: standalone)').matches;
     
      let ifPushVoice = this.cookieService.get('pushVoice');
      if(ifPushVoice){ 
        this.pushVoice = JSON.parse(ifPushVoice)
      }



      this.commonService.requestPermission('reload'); 

      this.dataFactory.get_pushIsSubscribed().subscribe(res => {
         this.pushIsSubscribed = res;
     })

    
      
      // navigator.serviceWorker.ready.then(function(reg) {
      //   reg.pushManager.getSubscription().then(function(push:any) {
      //     console.log("++++++++++++++++ subscription")
      //     console.log(push); 
      //     if(push){ 
      //       forThis.pushIsSubscribed = true;
      //     }else{
      //       forThis.pushIsSubscribed = false; 
      //       forThis.commonService.requestPermission(); 
      //     }
          
      //   })
      // }); 
    
  }

  clickMenu(event: any) { 
    debugger
    this.sidebarService.toggle(event);
  }
 
 
ngOnInit() {   
 
}
 
logoutUser(url: any) {   
  this.commonService.logoutByClick(url); 
 }

 onRMToggleChange(){ 
  this.onTabChange(this.RoleIsSaleshead?'saleshead':'manager');
}

onTabChange(mode:any) {
  debugger 
  this.commonService.changeActiveRole(mode);
}

showDialog_Profile(){
  debugger  
  const dialogRef = this.dialog.open(ProfileComponent,{ 
    width:'1000px', 
   // disableClose: true, 
      data:{ 
      }, 
  });
  dialogRef.beforeClosed().subscribe(result => {
  if(result){  
    
  }       
}) 
}

toggleVoicePush(){
  debugger;  
  setTimeout(()=>{  
    this.serviceFactory.loadingStart("body","Please wait while loading...","");
    this.cookieService.set( 'pushVoice',JSON.stringify(this.pushVoice),365,'/');
    this.document.location.reload(); 
 },200); 
 
 }


installPwa(){
  debugger; // window.matchMedia('(display-mode: standalone)').matches; https://web.dev/customize-install/#detect-launch-type
  this.appInstalled = true;
  this.deferredPrompt.prompt();
  this.deferredPrompt.userChoice.then((choiceResult:any) => {
    if (choiceResult.outcome === 'accepted') {
      console.log('User accepted the A2HS prompt');
    } else {
      console.log('User dismissed the A2HS prompt');
    }
    this.deferredPrompt = null;
  });
}


toggleSwPush(){
 debugger;  
 setTimeout(()=>{   
  if(this.pushIsSubscribed){ 
    this.commonService.requestPermission('click'); 
  }else{
   this.commonService.unsubscribe('click'); 
  }
},200); 

}

 

 
 

@HostListener('window:beforeinstallprompt', ['$event'])
  onbeforeinstallprompt(e:any) {
    console.log("beforeinstallprompt================")
    console.log(e)
    e.preventDefault();
    this.deferredPrompt = e;
    this.appInstalled = false;  
  }

}
 

// let enableUrl = {
//   "edge":"edge://settings/content/siteDetails?site="+environment.hostName+"trackerr",
//   "opera":"opera://settings/content/siteDetails?="+environment.hostName+"trackerr",
//   "chrome":"chrome://settings/content/siteDetails?site="+environment.hostName+"trackerr",
//   "ie":"ms-settings:notifications?activationSource=SMC-IA-4028678",
//   "firefox":"about:preferences#privacy",
//   "safari":"",
//   "other":"" 
// }