import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CommonService } from 'src/services/api/common.service';
import { IncentiveService } from 'src/services/api/informed.service';
import { IncentiveDetailsComponent } from '../../shared/incentive/dialog/incentive-details/incentive-details.component';
import { NoIncentiveComponent } from '../../shared/incentive/dialog/no-incentive/no-incentive.component';

@Component({
  selector: 'app-ic',
  templateUrl: './ic.component.html',
  styleUrls: ['./ic.component.scss']
})
export class IcComponent implements OnInit {

  currentUser : any
  login_type: any
  incentiveData: any ={}
  center: any
  constructor(
    private dialog: MatDialog,
    private router: Router,
    private incentiveService: IncentiveService,
    private commonService: CommonService
  ) {
    this.currentUser = this.commonService.getCurrentUser();
    this.login_type = this.commonService.getCurrentUser().role_name;
    this.center = this.commonService.getCurrentUser().center_id;
    

    
   }

  ngOnInit(): void {
    this.liveincentive();
  }


  viewdetails(data: any){
    debugger
  
      const dialogRef = this.dialog.open(IncentiveDetailsComponent, {
        width: '60%',
        height: 'auto',
        autoFocus: false,
        disableClose: true,
        data: {data: data, type: 'piggy'}
      });
  }


  sad(){
    debugger
  
      const dialogRef = this.dialog.open(NoIncentiveComponent, {
        width: '45%',
        // height: '60%',
        autoFocus: false,
        disableClose: true,
      });
  }



  comming(){
    debugger
  
      // const dialogRef = this.dialog.open(CommingsoonComponent, {
      //   width: '20%',
      //   // height: '60%',
      //   autoFocus: false,
      //   disableClose: true,
      // });
  }


  // incentive_structure(){
  //   this.router.navigate(['/incentive-structure'])
  //   window.scrollTo(0,0);
  

  // }

  // counsellorTble(){
  //   this.router.navigate(['/account-counsellor-detail'])
  //   window.scrollTo(0,0);
  // }


  incentiveHistory() {
    debugger
    this.router.navigate(['counsellor/ic/counsellor-history'])
    window.scrollTo(0,0);
  }

  managerHistoryLive() {
    debugger
    this.router.navigate(['manager/ic/manager-history-live'], { queryParams: { isLive: 'Yes' } })
    window.scrollTo(0,0);
  }

  managerHistory() {
    debugger
    this.router.navigate(['manager/ic/manager-history'], { queryParams: { isLive: 'No' } })
    window.scrollTo(0,0);
  }

  accountHistory() {
    debugger
    this.router.navigate(['account/ic/account-history'])
    window.scrollTo(0,0);
  }

  liveincentive() {
    console.log("Role Center ID & Team ID:"+ " " + this.currentUser.activeRole + this.currentUser.center_id + " " + this.currentUser.team_id)
    if((this.currentUser.center_id<3 && this.currentUser.team_id==1) || this.currentUser.activeRole == "account") {
      this.incentiveService.liveinCentive({
        "user_id": this.currentUser.id
      }).subscribe((data)=> {
        this.incentiveData = data;
        //console.log(this.incentiveData);
             
      })
    }
  }

  account_History(){
    debugger
    this.router.navigate(['account/ic/account-history'])
    window.scrollTo(0,0);
  }
  account_history_live(type: any){
    debugger
    if(type == 1) {
      this.router.navigate(['account/ic/account-history-live'], { queryParams: { branch: 'Noida' }})
    } else {
      this.router.navigate(['account/ic/account-history-live'], { queryParams: { branch: 'LP' }})
    }
    window.scrollTo(0,0);
  }



}
