import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminModuleConst, AdminRoutingModule } from './admin-routing.module';
import { CoreModule } from '../core/core.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';



@NgModule({
  declarations: [AdminModuleConst],
  imports: [
    CommonModule, 
    AdminRoutingModule,
    CoreModule,
    MatSidenavModule, 
    MatToolbarModule 
  ]
})
export class AdminModule { }
