import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router'; 
import { UserComponent } from './user.component';  
   
import { AuthGuard } from '../auth/auth.guard'; 
  

const routes: Routes = [
 
  {
     path: '', component: UserComponent, 
     canActivate: [AuthGuard],
     data: { roles: "user"},  
     children: [   
           { path: 'counsellor', loadChildren: () => import(`./counsellor/counsellor.module`).then(m => m.CounsellorModule)},
           { path: 'manager', loadChildren: () => import(`./manager/manager.module`).then(m => m.ManagerModule)}, 
           { path: 'saleshead', loadChildren: () => import(`./saleshead/saleshead.module`).then(m => m.SalesheadModule)},
           { path: 'admin', loadChildren: () => import(`./admin/admin.module`).then(m => m.AdminModule)},                    
           { path: 'account', loadChildren: () => import(`./account/account.module`).then(m => m.AccountModule)},
           { path: 'ops', loadChildren: () => import(`./ops/ops.module`).then(m => m.OpsModule)},
         // { path: 'offer', loadChildren: () => import(`./offer/offer.module`).then(m => m.OfferModule)},
        ],
  
     },   
        
];
 
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
}) 
export class UserRoutingModule { }


export const UserModuleConst = [
   UserComponent, 
  
 
];
