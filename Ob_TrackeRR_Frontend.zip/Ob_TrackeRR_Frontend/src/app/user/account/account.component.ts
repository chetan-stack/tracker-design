 
import { BreakpointObserver } from '@angular/cdk/layout';
import {Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav'; 
import { DataFactoryService } from 'src/services/factory/data-factory.service'; 
import { SidebarService } from '../core/sidebar/sidebar.service';
 

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss'] 
})
export class AccountComponent implements OnInit {  
  @ViewChild('sidenav') public sidenav: MatSidenav;
  constructor( 
    public sidebarservice: SidebarService, 
    private dataFactory: DataFactoryService,
    public mediaQ: BreakpointObserver 
  ) {  
    this.dataFactory.setHeaderType('account');
   }
 
   ngOnInit(): void {  
    
  }
  
  ngAfterViewInit() {
    this.sidebarservice.sidenav = this.sidenav;
  }
  
 }


 
