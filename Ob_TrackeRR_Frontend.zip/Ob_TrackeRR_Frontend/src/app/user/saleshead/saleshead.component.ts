 
import { BreakpointObserver } from '@angular/cdk/layout';
import {Component, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav'; 
import { DataFactoryService } from 'src/services/factory/data-factory.service'; 
import { SidebarService } from '../core/sidebar/sidebar.service';
 

@Component({
  selector: 'app-saleshead',
  templateUrl: './saleshead.component.html',
  styleUrls: ['./saleshead.component.scss']
})
export class SalesheadComponent implements OnInit {
  @ViewChild('sidenav') public sidenav: MatSidenav;
  constructor( 
    public sidebarservice: SidebarService, 
    private dataFactory: DataFactoryService,
    public mediaQ: BreakpointObserver 
  ) {  
    this.dataFactory.setHeaderType('saleshead');
   }
 
   ngOnInit(): void {  
    
  }
  
  ngAfterViewInit() {
    this.sidebarservice.sidenav = this.sidenav;
  }
  
 }
