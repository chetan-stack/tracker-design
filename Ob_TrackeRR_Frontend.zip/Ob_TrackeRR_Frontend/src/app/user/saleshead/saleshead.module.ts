import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesheadModuleConst, SalesheadRoutingModule } from './saleshead-routing.module';
import { CoreModule } from '../core/core.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';



@NgModule({
  declarations: [SalesheadModuleConst],
  imports: [
    CommonModule, 
    SalesheadRoutingModule,
    CoreModule,
    MatSidenavModule, 
    MatToolbarModule 
  ]
})
export class SalesheadModule { }
