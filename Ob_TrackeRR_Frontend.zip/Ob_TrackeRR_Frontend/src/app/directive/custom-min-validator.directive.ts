import { Directive, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl } from '@angular/forms';

@Directive({
  selector: '[customMin]',
  providers: [{provide: NG_VALIDATORS, useExisting: CustomMinDirective, multi: true}]
})
export class CustomMinDirective implements Validator {
  @Input()
  customMin: any;
  
  validate(c: FormControl){
      let v = c.value;
      //debugger
      return ( v < Number(this.customMin))? {"customMin": true} : null;
  }
} 