import { ChangeDetectorRef, Component, ElementRef, EventEmitter, forwardRef, Inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgModel, NG_VALUE_ACCESSOR } from '@angular/forms';  
import { MatSelect } from '@angular/material/select';
import { fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged, tap } from 'rxjs/operators';

@Component({
  selector: 'app-select-search',
  template: `
      <input #search class="mat-select-search-input"/>
  `,
  styles: [''],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => SelectSearchComponent),
      multi: true
    }
  ],
})
export class SelectSearchComponent implements OnInit {
  @Input() model: MatSelect; 
 
  @ViewChild('search') input: ElementRef;

  constructor(
    //@Inject(MatSelect) public matSelect: MatSelect,
    private changeDetectorRef: ChangeDetectorRef
  ) { 
    debugger
  }

  ngOnInit() {
    debugger
    
  }

  ngAfterViewInit() {
     
  let forThis = this;
    fromEvent(this.input.nativeElement, 'keyup')
      .pipe(
        debounceTime(250),
        distinctUntilChanged(),
        tap(() => {
          debugger
          let gkt = forThis
          
        })
      )
      .subscribe();
  }
 
}
