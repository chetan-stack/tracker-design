import { Directive, HostListener } from '@angular/core';
import {Location} from '@angular/common';
import {  NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs'; 
@Directive({
  selector: '[appLocationBack]'
})
export class LocationBackDirective {
  public urlChanged = new Subject();
  returnUrl: string;
  constructor(
    private location: Location,
    private router: Router, 
  ) {
 debugger
    router.events.subscribe((val:any) => {
      // see also 
      if(val['url']=="/" && val['urlAfterRedirects']=="/"){ 
        return false 
       }
      
   });

  location.onUrlChange((url, state) => {
    this.urlChanged.next({ url, state });
     

    
  });
   } 

   
 
  @HostListener('click', ['$event.target'])
  onClick(event:any) {
    debugger
    this.location.back();
 }

}