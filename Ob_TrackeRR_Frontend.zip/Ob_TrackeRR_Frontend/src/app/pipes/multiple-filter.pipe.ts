// In your pipe:
import { Pipe, PipeTransform } from '@angular/core';
 
@Pipe({
    name: 'multipleFilter',
    pure: false
})
export class MultipleFilterPipe implements PipeTransform {
    transform(items: any, filter: any, isAnd: boolean): any {
        if (filter && items && items.length>0 && Array.isArray(items)) {
          let filterKeys = Object.keys(filter);
          if (isAnd) { 
            return items.filter((item:any) =>
                filterKeys.reduce((memo:any, keyName:any) =>
                    (memo && new RegExp(filter[keyName], 'gi').test(item[keyName])) || filter[keyName] === "", true));
          } else { 
            return items.filter((item:any) => {
              return filterKeys.some((keyName:any) => {
                //console.log(keyName);
                return new RegExp(filter[keyName], 'gi').test(item[keyName]) || filter[keyName] === "";
              });
            });
          }
        } else {
          return items;
        }
      }
    }