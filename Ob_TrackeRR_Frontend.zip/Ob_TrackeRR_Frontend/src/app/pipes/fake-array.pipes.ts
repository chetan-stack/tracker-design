import {PipeTransform, Pipe} from '@angular/core';

@Pipe({
  name: 'fakeArray'
})
export class FakeArrayPipe implements PipeTransform {
  
  transform(value) {
    debugger
    return (new Array(value)).fill(1);
  }
}

 