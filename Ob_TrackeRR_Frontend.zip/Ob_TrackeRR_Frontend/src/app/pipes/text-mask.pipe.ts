import {PipeTransform, Pipe} from '@angular/core';

@Pipe({
  name: 'textMask'
})
export class TextMaskPipe implements PipeTransform {
  transform(type: string, value: any): string {
    debugger 
    return  value;
  }
}