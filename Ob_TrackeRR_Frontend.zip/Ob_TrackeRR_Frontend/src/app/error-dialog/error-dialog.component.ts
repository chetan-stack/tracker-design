import { Component, OnInit, Inject } from '@angular/core';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.css']
})
export class ErrorDialogComponent implements OnInit {
  title = 'Angular-Interceptor';
  errorData:any;
  constructor(
    @Inject(MAT_DIALOG_DATA) public errorDialogData: any,
    private dialogRef: MatDialogRef<ErrorDialogComponent>,
  ) { 
    debugger
    this.errorData = errorDialogData
  }
 
  ngOnInit(): void {
  }

  cancelN(){
    this.dialogRef.close()
  }

}
