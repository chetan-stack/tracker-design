import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ErrorDialogComponent } from './error-dialog.component';

@Injectable({
  providedIn: 'root'
}) 
export class ErrorDialogService {
    dialogRef:any

    constructor(public dialog: MatDialog) { }
    openDialog(data:any): void {
        debugger 

        if(this.dialogRef){
            this.dialogRef.Close()
        }

        this.dialogRef = this.dialog.open(ErrorDialogComponent, {
            width: '700px',
            data: data,
            panelClass: 'custom_ErrorDialog'
        });

        this.dialogRef.afterClosed().subscribe((res: any) => {
            console.log('The dialog was closed');
            let animal;
            animal = res;
            this.dialogRef = undefined
        });
    }
}
