export const environment = {
  production: true,  
  appVersion: require('../../package.json').version, 
  
  baseUrl: 'https://tracker.researchandranking.com/api/',   
  hostName:"https://operations.researchandranking.com/trackerr/",
  onboarding_host:"https://onboarding.researchandranking.com/", 
  rnr_domain:"https://web.researchandranking.com/",  
  rnrCdn:"https://cdn.researchandranking.com/",

  ragisterrUrl: "https://api.rrshort.com/salesTrackerr/", 
  incentiveUrl: "https://api.rrshort.com/salesTrackerr/ic/",
  alphabet: "https://alphabet.researchandranking.com/"
 

};

 
